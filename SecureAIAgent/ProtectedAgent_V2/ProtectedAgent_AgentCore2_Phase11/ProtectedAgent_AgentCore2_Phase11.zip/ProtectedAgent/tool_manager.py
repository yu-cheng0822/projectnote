from tool_registry import ToolDefinition, build_default_tool_registry


class ToolManager:
    """Single execution boundary between Agent Core and registered tools.

    Phase 4 does not add SecurityArchitecture here. This boundary is kept
    generic so an external interception/plugin layer can be attached later
    without making Agent Core depend on that security system.
    """

    def __init__(self, registry=None):
        self.registry = registry if registry is not None else build_default_tool_registry()

    def register_tool(self, definition, replace=False):
        return self.registry.register(definition, replace=replace)

    def unregister_tool(self, name):
        return self.registry.unregister(name)

    def has_tool(self, name, exposed_only=False):
        return self.registry.has(name, exposed_only=exposed_only)

    def available_tool_names(self, exposed_only=True):
        return self.registry.names(exposed_only=exposed_only)

    def tool_catalog(self):
        return self.registry.public_catalog()

    def prompt_catalog(self):
        return self.registry.to_prompt_text()

    def normalize_input(self, tool_name, arguments=None):
        definition = self.registry.get(tool_name)
        if definition is None:
            return arguments

        handler = definition.handler
        serializer = getattr(handler, "to_history_input", None)
        if callable(serializer):
            return serializer(arguments)

        if isinstance(arguments, dict) and set(arguments) == {"expression"}:
            return arguments.get("expression")

        return arguments

    def execute(self, tool_name, arguments=None):
        definition = self.registry.get(tool_name)
        if definition is None:
            return False, "unknown_tool"

        try:
            result = definition.handler(arguments)
        except Exception as exc:
            return False, str(exc)

        if isinstance(result, str) and result in definition.error_results:
            return False, result

        return True, result


__all__ = ["ToolManager", "ToolDefinition"]
