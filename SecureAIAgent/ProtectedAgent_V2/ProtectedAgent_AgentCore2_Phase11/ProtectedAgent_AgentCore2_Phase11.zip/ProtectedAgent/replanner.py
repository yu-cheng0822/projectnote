from models import RecoveryDecision


class FailureRecoveryPlanner:
    """Bounded failure recovery + alternative replanning.

    Phase 6 provided retry/abort. Phase 7 adds two inspectable alternatives:
    - retry_with_arguments: change a failed tool call to a different supported
      identifier when trustworthy evidence already exists.
    - insert_prerequisite: insert supporting plan steps when the current tool
      cannot directly consume the identifier given by the user.
    """

    NON_RETRYABLE_ERRORS = {
        "no_matching_records",
        "invalid_expression",
        "missing_database_query",
        "unknown_database_query",
        "unknown_tool",
    }

    NON_RETRYABLE_PREFIXES = (
        "invalid_",
        "missing_",
        "unknown_",
    )

    def __init__(self, max_attempts_per_step=2, max_replans=3):
        self.max_attempts_per_step = max(1, int(max_attempts_per_step))
        self.max_replans = max(0, int(max_replans))

    def decide(
        self,
        task_plan,
        plan_step,
        error,
        alternative_arguments=None,
        prerequisite_steps=None,
    ):
        error_text = str(error or "tool_failure").strip()
        normalized = error_text.lower()

        if task_plan is None or plan_step is None:
            return RecoveryDecision(
                strategy="abort",
                reason="目前不是可重新規劃的 TaskPlan 步驟。",
                error=error_text,
            )

        if task_plan.replan_count >= self.max_replans:
            return RecoveryDecision(
                strategy="abort",
                reason="已達整體重新規劃次數上限。",
                error=error_text,
            )

        # Alternative plan insertion has priority over the generic
        # missing_* non-retryable rule. This is what lets the agent resolve a
        # user_id -> users -> accounts dependency instead of querying all rows.
        if prerequisite_steps:
            return RecoveryDecision(
                strategy="insert_prerequisite",
                reason=(
                    "目前工具缺少可直接使用的關聯識別資料，先插入支援步驟取得必要證據，"
                    "再回到原步驟重新解析參數。"
                ),
                error=error_text,
                prerequisite_steps=[dict(item) for item in prerequisite_steps],
            )

        # A semantic no-match may be recoverable if the agent already has a
        # trustworthy alternate identifier for the same active entity.
        if normalized == "no_matching_records" and alternative_arguments:
            if plan_step.attempts >= self.max_attempts_per_step:
                return RecoveryDecision(
                    strategy="abort",
                    reason="此步驟已達最大嘗試次數。",
                    error=error_text,
                )

            return RecoveryDecision(
                strategy="retry_with_arguments",
                reason=(
                    "目前查詢沒有符合資料，但已有同一實體的另一個可信識別欄位，"
                    "改用替代參數重試。"
                ),
                error=error_text,
                new_arguments=dict(alternative_arguments),
            )

        if self._is_non_retryable(normalized):
            return RecoveryDecision(
                strategy="abort",
                reason=(
                    "錯誤屬於重試無法改善的結果，停止此步驟以避免無限重試。"
                ),
                error=error_text,
            )

        if plan_step.attempts >= self.max_attempts_per_step:
            return RecoveryDecision(
                strategy="abort",
                reason="此步驟已達最大嘗試次數。",
                error=error_text,
            )

        return RecoveryDecision(
            strategy="retry",
            reason="工具執行錯誤可能是暫時性的，重新執行目前計畫步驟。",
            error=error_text,
            new_arguments=None,
        )

    def _is_non_retryable(self, normalized_error):
        if normalized_error in self.NON_RETRYABLE_ERRORS:
            return True
        return normalized_error.startswith(self.NON_RETRYABLE_PREFIXES)
