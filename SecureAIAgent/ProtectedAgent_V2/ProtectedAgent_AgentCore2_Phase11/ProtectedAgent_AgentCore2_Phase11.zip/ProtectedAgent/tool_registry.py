from dataclasses import dataclass, field
from typing import Any, Callable

from tools import (
    CalculatorTool,
    DatabaseTool,
    FilePlaceholderTool,
    RecoveryPlaceholderTool,
)


@dataclass
class ToolDefinition:
    """Metadata + callable handler for one tool."""

    name: str
    description: str
    input_schema: dict[str, Any]
    handler: Callable[[Any], Any]
    error_results: set[str] = field(default_factory=set)
    exposed_to_agent: bool = True

    def public_metadata(self):
        return {
            "name": self.name,
            "description": self.description,
            "input_schema": self.input_schema,
        }


class ToolRegistry:
    """Runtime registry of tools available to ProtectedAgent."""

    def __init__(self):
        self._tools: dict[str, ToolDefinition] = {}

    def register(self, definition, replace=False):
        if not isinstance(definition, ToolDefinition):
            raise TypeError("definition must be ToolDefinition")

        name = str(definition.name).strip().lower()
        if not name:
            raise ValueError("tool name cannot be empty")

        if name in self._tools and not replace:
            raise ValueError(f"tool already registered: {name}")

        definition.name = name
        self._tools[name] = definition
        return definition

    def unregister(self, name):
        return self._tools.pop(str(name).strip().lower(), None)

    def get(self, name):
        return self._tools.get(str(name).strip().lower())

    def has(self, name, exposed_only=False):
        definition = self.get(name)
        if definition is None:
            return False
        if exposed_only and not definition.exposed_to_agent:
            return False
        return True

    def names(self, exposed_only=False):
        return [
            name
            for name, definition in self._tools.items()
            if not exposed_only or definition.exposed_to_agent
        ]

    def public_catalog(self):
        return [
            definition.public_metadata()
            for definition in self._tools.values()
            if definition.exposed_to_agent
        ]

    def to_prompt_text(self):
        lines = []
        for definition in self._tools.values():
            if not definition.exposed_to_agent:
                continue
            lines.append(f"- {definition.name}: {definition.description}")
            lines.append(f"  input_schema: {definition.input_schema}")

        return "\n".join(lines) if lines else "(no tools registered)"


def build_default_tool_registry():
    registry = ToolRegistry()

    calculator = CalculatorTool()
    database = DatabaseTool()

    registry.register(
        ToolDefinition(
            name="calculator",
            description="Perform basic arithmetic using an expression.",
            input_schema={
                "expression": "string, e.g. 123 * 456",
            },
            handler=calculator,
            error_results={"invalid_expression", "calculation_error"},
            exposed_to_agent=True,
        )
    )

    registry.register(
        ToolDefinition(
            name="database",
            description=(
                "Query the local demo database. Available datasets are users, "
                "accounts, and sensitive_data."
            ),
            input_schema={
                "dataset": "users | accounts | sensitive_data",
                "filters": "object containing supported dataset filters",
            },
            handler=database,
            error_results={"missing_database_query", "unknown_database_query"},
            exposed_to_agent=True,
        )
    )

    # These two names existed in the historical ToolExecutor. They stay
    # executable for compatibility, but the Agent planner cannot choose them.
    registry.register(
        ToolDefinition(
            name="recovery",
            description="Legacy recovery placeholder.",
            input_schema={},
            handler=RecoveryPlaceholderTool(),
            exposed_to_agent=False,
        )
    )

    registry.register(
        ToolDefinition(
            name="file",
            description="Legacy file placeholder.",
            input_schema={},
            handler=FilePlaceholderTool(),
            exposed_to_agent=False,
        )
    )

    return registry
