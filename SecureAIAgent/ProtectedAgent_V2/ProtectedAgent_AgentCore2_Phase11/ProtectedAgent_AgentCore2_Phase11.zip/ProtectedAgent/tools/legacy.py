class RecoveryPlaceholderTool:
    """Legacy placeholder kept only for backward compatibility.

    It is intentionally not exposed to the LLM planner in Phase 4.
    """

    def __call__(self, arguments=None):
        return "recovery_action_completed"


class FilePlaceholderTool:
    """Legacy placeholder kept only for backward compatibility.

    Real file access will be implemented as a separate, explicit tool later.
    """

    def __call__(self, arguments=None):
        return "file_operation_completed"
