"""Built-in tools for ProtectedAgent.

Phase 4 keeps tool implementations independent from Agent Core. Tools are
registered through ToolRegistry/ToolManager rather than hard-coded in Agent.
"""

from .calculator import CalculatorTool
from .database import DatabaseTool
from .legacy import FilePlaceholderTool, RecoveryPlaceholderTool

__all__ = [
    "CalculatorTool",
    "DatabaseTool",
    "FilePlaceholderTool",
    "RecoveryPlaceholderTool",
]
