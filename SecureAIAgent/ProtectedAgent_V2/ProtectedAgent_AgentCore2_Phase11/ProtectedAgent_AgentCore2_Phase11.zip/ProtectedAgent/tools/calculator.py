import ast
import operator


class CalculatorTool:
    """Small arithmetic tool with no access to Python builtins."""

    _BINARY_OPERATORS = {
        ast.Add: operator.add,
        ast.Sub: operator.sub,
        ast.Mult: operator.mul,
        ast.Div: operator.truediv,
    }

    _UNARY_OPERATORS = {
        ast.UAdd: operator.pos,
        ast.USub: operator.neg,
    }

    def __call__(self, arguments=None):
        if isinstance(arguments, dict):
            expression = arguments.get("expression")
        else:
            expression = arguments

        print("\n[DEBUG] Calculator Input:")
        print(repr(expression))

        if expression is None:
            return "invalid_expression"

        expression = str(expression).strip()
        if not expression:
            return "invalid_expression"

        try:
            parsed = ast.parse(expression, mode="eval")
            return self._evaluate(parsed.body)
        except (SyntaxError, TypeError, ValueError, ZeroDivisionError, OverflowError):
            return "calculation_error"

    def _evaluate(self, node):
        if isinstance(node, ast.Constant):
            value = node.value
            if isinstance(value, bool) or not isinstance(value, (int, float)):
                raise ValueError("unsupported_constant")
            return value

        if isinstance(node, ast.BinOp):
            operator_type = type(node.op)
            if operator_type not in self._BINARY_OPERATORS:
                raise ValueError("unsupported_operator")
            left = self._evaluate(node.left)
            right = self._evaluate(node.right)
            return self._BINARY_OPERATORS[operator_type](left, right)

        if isinstance(node, ast.UnaryOp):
            operator_type = type(node.op)
            if operator_type not in self._UNARY_OPERATORS:
                raise ValueError("unsupported_operator")
            operand = self._evaluate(node.operand)
            return self._UNARY_OPERATORS[operator_type](operand)

        raise ValueError("unsupported_expression")
