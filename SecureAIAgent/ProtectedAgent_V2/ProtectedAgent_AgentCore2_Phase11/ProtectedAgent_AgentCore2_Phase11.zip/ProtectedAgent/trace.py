from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Callable
import uuid


@dataclass
class TraceEvent:
    """One normalized observation from an Agent execution."""

    sequence: int
    event_type: str
    timestamp: str
    step: int | None = None
    data: dict[str, Any] = field(default_factory=dict)

    def to_dict(self):
        return {
            "sequence": self.sequence,
            "event_type": self.event_type,
            "timestamp": self.timestamp,
            "step": self.step,
            "data": self.data,
        }


class ExecutionTrace:
    """Structured execution trace for one Agent.run() call.

    The trace is intentionally independent of SecurityArchitecture. External
    components may subscribe through an observer callback without Agent Core
    importing or depending on those components.
    """

    def __init__(
        self,
        agent_id: str,
        session_id: str,
        user_request: str,
        observers: list[Callable[[dict[str, Any]], None]] | None = None,
    ):
        self.trace_id = str(uuid.uuid4())
        self.agent_id = agent_id
        self.session_id = session_id
        self.user_request = user_request
        self.started_at = datetime.now().isoformat(timespec="milliseconds")
        self.finished_at: str | None = None
        self.events: list[TraceEvent] = []
        self._observers = list(observers or [])

    def record(
        self,
        event_type: str,
        *,
        step: int | None = None,
        data: dict[str, Any] | None = None,
    ) -> TraceEvent:
        event = TraceEvent(
            sequence=len(self.events) + 1,
            event_type=str(event_type).strip().upper(),
            timestamp=datetime.now().isoformat(timespec="milliseconds"),
            step=step,
            data=dict(data or {}),
        )
        self.events.append(event)

        event_dict = event.to_dict()
        for observer in list(self._observers):
            try:
                observer(event_dict)
            except Exception:
                # Observation must never be able to break normal Agent
                # execution. External observers are diagnostic/plugin hooks.
                continue

        return event

    def finish(self):
        if self.finished_at is None:
            self.finished_at = datetime.now().isoformat(timespec="milliseconds")

    def add_observer(self, callback):
        if callable(callback):
            self._observers.append(callback)

    def event_types(self):
        return [event.event_type for event in self.events]

    def summary(self):
        counts: dict[str, int] = {}
        for event in self.events:
            counts[event.event_type] = counts.get(event.event_type, 0) + 1

        return {
            "trace_id": self.trace_id,
            "event_count": len(self.events),
            "event_counts": counts,
            "started_at": self.started_at,
            "finished_at": self.finished_at,
        }

    def to_dict(self):
        return {
            "trace_id": self.trace_id,
            "agent_id": self.agent_id,
            "session_id": self.session_id,
            "user_request": self.user_request,
            "started_at": self.started_at,
            "finished_at": self.finished_at,
            "events": [event.to_dict() for event in self.events],
        }

    def compact_lines(self):
        lines = []
        for event in self.events:
            step_text = f" step={event.step}" if event.step is not None else ""
            details = []

            if "tool" in event.data:
                details.append(f"tool={event.data['tool']}")
            if "strategy" in event.data:
                details.append(f"strategy={event.data['strategy']}")
            if "success" in event.data:
                details.append(f"success={event.data['success']}")
            if "status" in event.data:
                details.append(f"status={event.data['status']}")

            suffix = f" ({', '.join(details)})" if details else ""
            lines.append(
                f"[{event.sequence:02d}] {event.event_type}{step_text}{suffix}"
            )
        return lines
