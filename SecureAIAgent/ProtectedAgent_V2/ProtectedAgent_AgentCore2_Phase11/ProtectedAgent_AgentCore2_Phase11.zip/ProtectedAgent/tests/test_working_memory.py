import sys
from pathlib import Path

PROJECT_DIR = Path(__file__).resolve().parents[1]
if str(PROJECT_DIR) not in sys.path:
    sys.path.insert(0, str(PROJECT_DIR))

from agent import Agent
from tool_manager import ToolManager
from tool_registry import ToolDefinition


class QueueLLM:
    def __init__(self, outputs):
        self.outputs = iter(outputs)
        self.prompts = []

    def generate(self, prompt):
        self.prompts.append(prompt)
        try:
            return next(self.outputs)
        except StopIteration:
            return '{"action":"final","answer":"完成"}'


def build_profile_manager():
    manager = ToolManager()

    def profile_lookup(arguments):
        person = str((arguments or {}).get("person", "")).strip()
        return {
            "name": person,
            "score": 95,
            "source": "profile_lookup",
        }

    manager.register_tool(
        ToolDefinition(
            name="profile_lookup",
            description="Look up a small profile by person name.",
            input_schema={"person": "string"},
            handler=profile_lookup,
            exposed_to_agent=True,
        )
    )
    return manager


def test_generic_tool_evidence_becomes_working_memory():
    manager = build_profile_manager()
    llm = QueueLLM([
        '{"action":"tool","tool":"profile_lookup",'
        '"arguments":{"person":"Alice"}}',
    ])
    agent = Agent(llm=llm, tool_manager=manager)

    result = agent.run("請使用 profile_lookup 查 Alice")
    working = result["working_memory"]

    assert working["status"] == "COMPLETE"
    assert working["facts"]["profile_lookup.name"] == "Alice"
    assert working["facts"]["profile_lookup.score"] == 95
    assert working["variables"]["last_tool"] == "profile_lookup"
    assert working["evidence"][-1]["tool"] == "profile_lookup"
    assert working["evidence"][-1]["result"]["score"] == 95


def test_previous_generic_fact_is_visible_to_next_planner_prompt():
    manager = build_profile_manager()
    llm = QueueLLM([
        '{"action":"tool","tool":"profile_lookup",'
        '"arguments":{"person":"Alice"}}',
        '{"action":"final","answer":"剛才的 score 是 95。"}',
    ])
    agent = Agent(llm=llm, tool_manager=manager)

    agent.run("請使用 profile_lookup 查 Alice")
    second = agent.run("剛才的 score 是多少？")

    assert second["answer"] == "剛才的 score 是 95。"
    second_prompt = llm.prompts[1]
    assert "WORKING MEMORY:" in second_prompt
    assert "profile_lookup.score: 95" in second_prompt
    assert "profile_lookup.name: Alice" in second_prompt
    assert "current_goal: 剛才的 score 是多少？" in second_prompt


def test_database_evidence_populates_generic_namespaced_facts():
    class NoCallLLM:
        def generate(self, prompt):
            raise AssertionError("Deterministic database task should not need the LLM")

    agent = Agent(llm=NoCallLLM())
    result = agent.run("請查 Alice 的個人資料")
    working = result["working_memory"]

    assert working["facts"]["users.user_id"] == "U001"
    assert working["facts"]["users.name"] == "Alice"
    assert working["facts"]["users.email"] == "alice@example.com"
    assert working["evidence"][-1]["tool"] == "database"


def test_incomplete_goal_keeps_pending_requirements_in_working_memory():
    manager = build_profile_manager()
    llm = QueueLLM([
        '''{
          "goal":"取得 Alice profile 並完成後續回傳",
          "steps":[
            {
              "description":"取得 Alice profile",
              "tool":"profile_lookup",
              "arguments":{"person":"Alice"},
              "depends_on":[],
              "include_in_answer":true
            }
          ]
        }''',
        '''{
          "status":"incomplete",
          "reason":"仍缺少指定的後續回傳步驟",
          "missing_requirements":["echo the profile score"],
          "additional_steps":[]
        }''',
    ])
    agent = Agent(llm=llm, tool_manager=manager)

    result = agent.run("先用 profile_lookup 取得 Alice，然後完成後續回傳")
    working = result["working_memory"]

    assert working["status"] == "PARTIAL"
    assert working["pending_requirements"] == ["echo the profile score"]
    assert working["goal_history"][-1]["status"] == "PARTIAL"


def test_reset_memory_clears_generic_working_memory():
    manager = build_profile_manager()
    llm = QueueLLM([
        '{"action":"tool","tool":"profile_lookup",'
        '"arguments":{"person":"Alice"}}',
    ])
    agent = Agent(llm=llm, tool_manager=manager)

    agent.run("請使用 profile_lookup 查 Alice")
    assert agent.memory.working.facts
    assert agent.memory.working.evidence

    agent.reset_memory()

    assert agent.memory.working.current_goal is None
    assert agent.memory.working.facts == {}
    assert agent.memory.working.variables == {}
    assert agent.memory.working.evidence == []
    assert agent.memory.working.pending_requirements == []
    assert agent.memory.to_prompt_context() == "(empty)"


if __name__ == "__main__":
    test_generic_tool_evidence_becomes_working_memory()
    test_previous_generic_fact_is_visible_to_next_planner_prompt()
    test_database_evidence_populates_generic_namespaced_facts()
    test_incomplete_goal_keeps_pending_requirements_in_working_memory()
    test_reset_memory_clears_generic_working_memory()
    print("Agent Core 2.0 Phase 11 working memory tests passed.")
