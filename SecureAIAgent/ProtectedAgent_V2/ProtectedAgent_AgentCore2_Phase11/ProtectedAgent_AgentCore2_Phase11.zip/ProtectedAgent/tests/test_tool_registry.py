import sys
from pathlib import Path

PROJECT_DIR = Path(__file__).resolve().parents[1]
if str(PROJECT_DIR) not in sys.path:
    sys.path.insert(0, str(PROJECT_DIR))

from agent import Agent
from tool import ToolExecutor
from tool_manager import ToolManager
from tool_registry import ToolDefinition


class QueueLLM:
    def __init__(self, outputs):
        self.outputs = iter(outputs)
        self.prompts = []

    def generate(self, prompt):
        self.prompts.append(prompt)
        try:
            return next(self.outputs)
        except StopIteration:
            return '{"action":"final","answer":"完成"}'


def test_default_registry_exposes_agent_tools_only():
    manager = ToolManager()

    assert manager.available_tool_names(exposed_only=True) == [
        "calculator",
        "database",
    ]
    assert manager.has_tool("recovery")
    assert not manager.has_tool("recovery", exposed_only=True)
    assert manager.has_tool("file")
    assert not manager.has_tool("file", exposed_only=True)


def test_structured_calculator_execution():
    manager = ToolManager()
    success, result = manager.execute(
        "calculator",
        {"expression": "123 * 456"},
    )

    assert success is True
    assert result == 56088


def test_structured_database_execution():
    manager = ToolManager()
    arguments = {
        "dataset": "users",
        "filters": {"name": "Alice"},
    }

    success, result = manager.execute("database", arguments)

    assert success is True
    assert result[0]["user_id"] == "U001"
    assert manager.normalize_input("database", arguments) == "users | name=Alice"


def test_registry_catalog_is_visible_to_planner_prompt():
    llm = QueueLLM([
        '{"action":"final","answer":"完成"}',
    ])
    agent = Agent(llm=llm)

    agent.run("你好")

    prompt = llm.prompts[0]
    assert "AVAILABLE TOOLS FROM TOOL REGISTRY:" in prompt
    assert "- calculator:" in prompt
    assert "- database:" in prompt
    assert "Legacy recovery placeholder" not in prompt


def test_custom_tool_can_be_registered_without_editing_agent_core():
    manager = ToolManager()

    def echo_tool(arguments):
        text = ""
        if isinstance(arguments, dict):
            text = str(arguments.get("text", ""))
        return text

    manager.register_tool(
        ToolDefinition(
            name="echo",
            description="Return the provided text.",
            input_schema={"text": "string"},
            handler=echo_tool,
            exposed_to_agent=True,
        )
    )

    llm = QueueLLM([
        '{"action":"tool","tool":"echo",'
        '"arguments":{"text":"hello"}}',
    ])
    agent = Agent(llm=llm, tool_manager=manager)

    result = agent.run("請使用 echo 回傳 hello")

    assert result["tool"] == "echo"
    assert result["tool_history"][0]["tool"] == "echo"
    assert result["tool_history"][0]["result"] == "hello"
    assert result["answer"] == "工具 echo 執行結果：hello"
    assert "- echo: Return the provided text." in llm.prompts[0]


def test_unknown_tool_is_rejected_by_manager():
    manager = ToolManager()
    success, result = manager.execute("does_not_exist", {})

    assert success is False
    assert result == "unknown_tool"


def test_legacy_tool_executor_still_works():
    executor = ToolExecutor()

    success, result = executor.execute("calculator", "2 + 3")
    assert success is True
    assert result == 5

    success, result = executor.execute("database", "accounts | username=alice")
    assert success is True
    assert result[0]["account_id"] == "A001"


if __name__ == "__main__":
    test_default_registry_exposes_agent_tools_only()
    test_structured_calculator_execution()
    test_structured_database_execution()
    test_registry_catalog_is_visible_to_planner_prompt()
    test_custom_tool_can_be_registered_without_editing_agent_core()
    test_unknown_tool_is_rejected_by_manager()
    test_legacy_tool_executor_still_works()
    print("Agent Core 2.0 Phase 4 tool registry tests passed.")
