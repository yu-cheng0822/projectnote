import sys
from pathlib import Path

PROJECT_DIR = Path(__file__).resolve().parents[1]
if str(PROJECT_DIR) not in sys.path:
    sys.path.insert(0, str(PROJECT_DIR))

from agent import Agent
from tool_manager import ToolManager
from tool_registry import ToolDefinition
from tools.database import DatabaseTool


class NoCallLLM:
    def generate(self, prompt):
        raise AssertionError("Deterministic task plan should not need the LLM")


class FlakyDatabaseTool:
    """Fail once, then delegate to the real database tool."""

    def __init__(self):
        self.calls = 0
        self.delegate = DatabaseTool()

    def __call__(self, arguments=None):
        self.calls += 1
        if self.calls == 1:
            raise RuntimeError("temporary_failure")
        return self.delegate(arguments)

    def to_history_input(self, arguments=None):
        return self.delegate.to_history_input(arguments)


class AlwaysFailDatabaseTool:
    def __init__(self):
        self.calls = 0
        self.delegate = DatabaseTool()

    def __call__(self, arguments=None):
        self.calls += 1
        raise RuntimeError("temporary_failure")

    def to_history_input(self, arguments=None):
        return self.delegate.to_history_input(arguments)


def replace_database_tool(manager, handler):
    manager.register_tool(
        ToolDefinition(
            name="database",
            description="Test database wrapper.",
            input_schema={
                "dataset": "users | accounts | sensitive_data",
                "filters": "object",
            },
            handler=handler,
            error_results={"missing_database_query", "unknown_database_query"},
            exposed_to_agent=True,
        ),
        replace=True,
    )


def test_transient_failure_is_retried_and_plan_completes():
    manager = ToolManager()
    flaky = FlakyDatabaseTool()
    replace_database_tool(manager, flaky)

    agent = Agent(llm=NoCallLLM(), tool_manager=manager)
    result = agent.run("請查 Alice 的個人資料")

    assert flaky.calls == 2
    assert len(result["tool_history"]) == 2
    assert result["tool_history"][0]["success"] is False
    assert result["tool_history"][0]["result"] == "temporary_failure"
    assert result["tool_history"][1]["success"] is True
    assert result["task_plan"]["status"] == "COMPLETED"
    assert result["task_plan"]["replan_count"] == 1
    assert result["task_plan"]["steps"][0]["attempts"] == 2
    assert result["recovery_history"][0]["strategy"] == "retry"
    assert "user_id: U001" in result["answer"]


def test_retry_is_bounded_and_eventually_aborts():
    manager = ToolManager()
    failing = AlwaysFailDatabaseTool()
    replace_database_tool(manager, failing)

    agent = Agent(llm=NoCallLLM(), tool_manager=manager)
    result = agent.run("請查 Alice 的個人資料")

    assert failing.calls == 2
    assert len(result["tool_history"]) == 2
    assert result["task_plan"]["status"] == "FAILED"
    assert result["task_plan"]["replan_count"] == 1
    assert result["task_plan"]["steps"][0]["attempts"] == 2
    assert [item["strategy"] for item in result["recovery_history"]] == [
        "retry",
        "abort",
    ]
    assert "temporary_failure" in result["answer"]


def test_no_matching_records_is_not_retried():
    agent = Agent(llm=NoCallLLM())
    result = agent.run("請查 David 的個人資料")

    assert len(result["tool_history"]) == 1
    assert result["tool_history"][0]["result"] == "no_matching_records"
    assert result["task_plan"]["status"] == "FAILED"
    assert result["task_plan"]["replan_count"] == 0
    assert result["task_plan"]["steps"][0]["attempts"] == 1
    assert result["recovery_history"][0]["strategy"] == "abort"


def test_mixed_plan_continues_after_recovery():
    manager = ToolManager()
    flaky = FlakyDatabaseTool()
    replace_database_tool(manager, flaky)

    agent = Agent(llm=NoCallLLM(), tool_manager=manager)
    result = agent.run("請查 Alice 的帳號和個人資料，並計算 123 * 456")

    successful_tools = [
        item["tool"]
        for item in result["tool_history"]
        if item["success"]
    ]
    assert successful_tools == ["database", "database", "calculator"]
    assert result["task_plan"]["status"] == "COMPLETED"
    assert result["task_plan"]["replan_count"] == 1
    assert result["tool_history"][-1]["result"] == 56088
    assert "account_id: A001" in result["answer"]
    assert "計算結果：56088" in result["answer"]


if __name__ == "__main__":
    test_transient_failure_is_retried_and_plan_completes()
    test_retry_is_bounded_and_eventually_aborts()
    test_no_matching_records_is_not_retried()
    test_mixed_plan_continues_after_recovery()
    print("Agent Core 2.0 Phase 6 replanning tests passed.")
