import sys
from pathlib import Path

PROJECT_DIR = Path(__file__).resolve().parents[1]
if str(PROJECT_DIR) not in sys.path:
    sys.path.insert(0, str(PROJECT_DIR))

from agent import Agent
from tool_manager import ToolManager
from tool_registry import ToolDefinition


class NoCallLLM:
    def generate(self, prompt):
        raise AssertionError(
            "Deterministic goal completion should not require an LLM evaluation"
        )


class QueueLLM:
    def __init__(self, outputs):
        self.outputs = iter(outputs)
        self.prompts = []

    def generate(self, prompt):
        self.prompts.append(prompt)
        try:
            return next(self.outputs)
        except StopIteration:
            return '''{
              "status":"complete",
              "reason":"fallback complete",
              "missing_requirements":[],
              "additional_steps":[]
            }'''


def build_custom_manager():
    manager = ToolManager()

    def profile_lookup(arguments):
        person = str((arguments or {}).get("person", "")).strip()
        return {"name": person, "source": "profile_lookup"}

    def echo(arguments):
        return str((arguments or {}).get("text", ""))

    manager.register_tool(
        ToolDefinition(
            name="profile_lookup",
            description="Look up a small profile by person name.",
            input_schema={"person": "string"},
            handler=profile_lookup,
            exposed_to_agent=True,
        )
    )
    manager.register_tool(
        ToolDefinition(
            name="echo",
            description="Return the provided text.",
            input_schema={"text": "string"},
            handler=echo,
            exposed_to_agent=True,
        )
    )
    return manager


def test_deterministic_goal_is_verified_without_llm():
    agent = Agent(llm=NoCallLLM())
    result = agent.run("請查 Alice 的帳號和個人資料，並計算 123 * 456")

    assert result["goal_completion"]["status"] == "complete"
    assert result["goal_completion"]["source"] == "deterministic"
    assert result["goal_completion"]["missing_requirements"] == []

    event_types = [
        event["event_type"]
        for event in result["execution_trace"]["events"]
    ]
    assert "GOAL_EVALUATED" in event_types


def test_llm_goal_evaluator_appends_missing_step_and_finishes():
    manager = build_custom_manager()
    llm = QueueLLM([
        # Decomposition intentionally misses the requested echo step.
        '''{
          "goal":"取得 Alice 並回傳她的名字",
          "steps":[
            {
              "description":"取得 Alice profile",
              "tool":"profile_lookup",
              "arguments":{"person":"Alice"},
              "depends_on":[],
              "include_in_answer":false
            }
          ]
        }''',
        # Goal evaluation detects the omission and adds the missing action.
        '''{
          "status":"incomplete",
          "reason":"尚未用 echo 回傳 Alice 的名字",
          "missing_requirements":["echo the profile name"],
          "additional_steps":[
            {
              "description":"用 echo 回傳 profile 名稱",
              "tool":"echo",
              "arguments":{"text":"{{step:1.result.name}}"},
              "depends_on":[1],
              "include_in_answer":true
            }
          ]
        }''',
        # Second evaluation after the supplemental step.
        '''{
          "status":"complete",
          "reason":"profile 已取得且 echo 已完成",
          "missing_requirements":[],
          "additional_steps":[]
        }''',
    ])
    agent = Agent(llm=llm, tool_manager=manager)

    result = agent.run(
        "先用 profile_lookup 取得 Alice，然後用 echo 回傳她的名字"
    )

    assert [item["tool"] for item in result["tool_history"]] == [
        "profile_lookup",
        "echo",
    ]
    assert result["tool_history"][1]["result"] == "Alice"
    assert len(result["goal_evaluation_history"]) == 2
    assert result["goal_evaluation_history"][0]["status"] == "incomplete"
    assert result["goal_evaluation_history"][1]["status"] == "complete"
    assert result["task_plan"]["steps"][1]["origin"] == "goal_completion"
    assert result["answer"] == "工具 echo 執行結果：Alice"

    event_types = [
        event["event_type"]
        for event in result["execution_trace"]["events"]
    ]
    assert "GOAL_REPLAN" in event_types
    assert event_types.count("GOAL_EVALUATED") == 2


def test_invalid_goal_evaluator_output_uses_structural_fallback():
    manager = build_custom_manager()
    llm = QueueLLM([
        '''{
          "goal":"取得 Alice 後回傳",
          "steps":[
            {
              "description":"取得 Alice profile",
              "tool":"profile_lookup",
              "arguments":{"person":"Alice"},
              "depends_on":[],
              "include_in_answer":true
            }
          ]
        }''',
        "not valid evaluator json",
    ])
    agent = Agent(llm=llm, tool_manager=manager)

    result = agent.run("先用 profile_lookup 取得 Alice，然後完成")

    assert result["goal_completion"]["status"] == "complete"
    assert result["goal_completion"]["source"] == "structural_fallback"


if __name__ == "__main__":
    test_deterministic_goal_is_verified_without_llm()
    test_llm_goal_evaluator_appends_missing_step_and_finishes()
    test_invalid_goal_evaluator_output_uses_structural_fallback()
    print("Agent Core 2.0 Phase 10 goal completion tests passed.")
