import sys
from pathlib import Path

PROJECT_DIR = Path(__file__).resolve().parents[1]
if str(PROJECT_DIR) not in sys.path:
    sys.path.insert(0, str(PROJECT_DIR))

from agent import Agent
from tool_manager import ToolManager
from tool_registry import ToolDefinition


class QueueLLM:
    def __init__(self, outputs):
        self.outputs = iter(outputs)
        self.prompts = []

    def generate(self, prompt):
        self.prompts.append(prompt)
        try:
            return next(self.outputs)
        except StopIteration:
            return '{"action":"final","answer":"完成"}'


def build_custom_manager():
    manager = ToolManager()

    def profile_lookup(arguments):
        person = str((arguments or {}).get("person", "")).strip()
        return {"name": person, "source": "profile_lookup"}

    def echo(arguments):
        return str((arguments or {}).get("text", ""))

    manager.register_tool(
        ToolDefinition(
            name="profile_lookup",
            description="Look up a small profile by person name.",
            input_schema={"person": "string"},
            handler=profile_lookup,
            exposed_to_agent=True,
        )
    )
    manager.register_tool(
        ToolDefinition(
            name="echo",
            description="Return the provided text.",
            input_schema={"text": "string"},
            handler=echo,
            exposed_to_agent=True,
        )
    )
    return manager


def test_compound_custom_goal_uses_llm_task_decomposition():
    manager = build_custom_manager()
    llm = QueueLLM([
        '''{
          "goal": "取得 Alice 名稱並回傳",
          "steps": [
            {
              "description": "取得 Alice profile",
              "tool": "profile_lookup",
              "arguments": {"person": "Alice"},
              "depends_on": [],
              "include_in_answer": false
            },
            {
              "description": "回傳 profile 中的名稱",
              "tool": "echo",
              "arguments": {"text": "{{step:1.result.name}}"},
              "depends_on": [1],
              "include_in_answer": true
            }
          ]
        }'''
    ])
    agent = Agent(llm=llm, tool_manager=manager)

    result = agent.run(
        "先用 profile_lookup 取得 Alice，然後用 echo 回傳她的名字"
    )

    assert result["task_plan"]["source"] == "llm_decomposition"
    assert [item["tool"] for item in result["tool_history"]] == [
        "profile_lookup",
        "echo",
    ]
    assert result["tool_history"][1]["input"] == {"text": "Alice"}
    assert result["tool_history"][1]["result"] == "Alice"
    assert result["answer"] == "工具 echo 執行結果：Alice"

    event_types = [
        event["event_type"]
        for event in result["execution_trace"]["events"]
    ]
    assert "GOAL_DECOMPOSED" in event_types


def test_invalid_decomposition_falls_back_to_one_action_path():
    manager = build_custom_manager()
    llm = QueueLLM([
        # First response is for decomposition and is rejected because the tool
        # does not exist.
        '''{
          "goal": "invalid plan",
          "steps": [
            {"description":"bad","tool":"does_not_exist","arguments":{}}
          ]
        }''',
        # Agent then falls back to the established one-action JSON path.
        '{"action":"tool","tool":"echo","arguments":{"text":"hello"}}',
    ])
    agent = Agent(llm=llm, tool_manager=manager)

    result = agent.run("先處理一下，然後用 echo 回傳 hello")

    assert result["task_plan"] is None
    assert result["tool_history"][0]["tool"] == "echo"
    assert result["tool_history"][0]["result"] == "hello"
    assert len(llm.prompts) == 2


def test_future_step_reference_is_not_executed():
    manager = build_custom_manager()
    llm = QueueLLM([
        '''{
          "goal": "bad dependency",
          "steps": [
            {
              "description": "references a future result",
              "tool": "echo",
              "arguments": {"text": "{{step:2.result}}"},
              "depends_on": [],
              "include_in_answer": true
            },
            {
              "description": "later lookup",
              "tool": "profile_lookup",
              "arguments": {"person": "Alice"},
              "depends_on": [],
              "include_in_answer": false
            }
          ]
        }'''
    ])
    agent = Agent(llm=llm, tool_manager=manager)

    result = agent.run(
        "先用 echo 處理後面的結果，然後用 profile_lookup 查 Alice"
    )

    assert result["tool_history"] == []
    assert result["task_plan"]["steps"][0]["status"] == "FAILED"
    assert result["task_plan"]["steps"][0]["error"] == "missing_plan_reference"
    assert result["recovery_history"][0]["strategy"] == "abort"


if __name__ == "__main__":
    test_compound_custom_goal_uses_llm_task_decomposition()
    test_invalid_decomposition_falls_back_to_one_action_path()
    test_future_step_reference_is_not_executed()
    print("Agent Core 2.0 Phase 9 goal decomposition tests passed.")
