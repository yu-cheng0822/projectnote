import sys
from pathlib import Path

PROJECT_DIR = Path(__file__).resolve().parents[1]
if str(PROJECT_DIR) not in sys.path:
    sys.path.insert(0, str(PROJECT_DIR))

from agent import Agent


class NoCallLLM:
    def generate(self, prompt):
        raise AssertionError("Deterministic planned task should not need the LLM")


class GreetingLLM:
    def generate(self, prompt):
        return '{"action":"final","tool":null,"arguments":{},"answer":"你好！"}'


def test_trace_records_plan_action_observation_and_result():
    agent = Agent(llm=NoCallLLM())
    result = agent.run("請計算 123 * 456")

    trace = result["execution_trace"]
    event_types = [event["event_type"] for event in trace["events"]]

    assert event_types == [
        "RUN_STARTED",
        "PLAN_CREATED",
        "STEP_STARTED",
        "ACTION_SELECTED",
        "OBSERVATION",
        "STEP_COMPLETED",
        "GOAL_EVALUATED",
        "FINAL_ANSWER",
        "RUN_FINISHED",
    ]
    assert trace["events"][4]["data"]["result"] == 56088
    assert trace["events"][6]["data"]["status"] == "complete"
    assert result["trace_summary"]["event_count"] == 9
    assert result["trace_summary"]["finished_at"] is not None
    assert agent.get_last_trace().trace_id == trace["trace_id"]


def test_trace_records_replanning_and_updated_plan():
    agent = Agent(llm=NoCallLLM())
    result = agent.run("請查 U001 的帳號")

    event_types = [
        event["event_type"]
        for event in result["execution_trace"]["events"]
    ]

    assert "REPLAN_DECISION" in event_types
    assert "PLAN_UPDATED" in event_types

    replan_event = next(
        event
        for event in result["execution_trace"]["events"]
        if event["event_type"] == "REPLAN_DECISION"
    )
    assert replan_event["data"]["strategy"] == "insert_prerequisite"



def test_trace_records_abort_and_failed_step():
    agent = Agent(llm=NoCallLLM())
    result = agent.run("請查 David 的個人資料")

    events = result["execution_trace"]["events"]
    event_types = [event["event_type"] for event in events]

    assert "OBSERVATION" in event_types
    assert "REPLAN_DECISION" in event_types
    assert "STEP_FAILED" in event_types

    observation = next(
        event for event in events if event["event_type"] == "OBSERVATION"
    )
    assert observation["data"]["success"] is False
    assert observation["data"]["result"] == "no_matching_records"

    replan = next(
        event for event in events if event["event_type"] == "REPLAN_DECISION"
    )
    assert replan["data"]["strategy"] == "abort"


def test_external_observer_receives_events_without_agent_dependency():
    observed = []

    def observer(event):
        observed.append(event)

    agent = Agent(llm=GreetingLLM(), trace_observers=[observer])
    result = agent.run("你好")

    assert observed
    assert observed[0]["event_type"] == "RUN_STARTED"
    assert observed[-1]["event_type"] == "RUN_FINISHED"
    assert len(observed) == result["trace_summary"]["event_count"]



def test_broken_observer_does_not_break_agent_execution():
    def broken_observer(event):
        raise RuntimeError("observer failure")

    agent = Agent(llm=GreetingLLM(), trace_observers=[broken_observer])
    result = agent.run("你好")

    assert result["answer"] == "你好！"
    assert result["decision"] == "FINAL"


if __name__ == "__main__":
    test_trace_records_plan_action_observation_and_result()
    test_trace_records_replanning_and_updated_plan()
    test_trace_records_abort_and_failed_step()
    test_external_observer_receives_events_without_agent_dependency()
    test_broken_observer_does_not_break_agent_execution()
    print("Agent Core 2.0 Phase 8 execution trace tests passed.")
