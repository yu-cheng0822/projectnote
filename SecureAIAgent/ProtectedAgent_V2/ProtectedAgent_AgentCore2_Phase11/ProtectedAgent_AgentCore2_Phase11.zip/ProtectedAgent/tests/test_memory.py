import sys
from pathlib import Path

PROJECT_DIR = Path(__file__).resolve().parents[1]
if str(PROJECT_DIR) not in sys.path:
    sys.path.insert(0, str(PROJECT_DIR))

from agent import Agent


class QueueLLM:
    def __init__(self, outputs):
        self.outputs = iter(outputs)
        self.prompts = []

    def generate(self, prompt):
        self.prompts.append(prompt)
        try:
            return next(self.outputs)
        except StopIteration:
            return '{"action":"final","answer":"完成"}'


def test_pronoun_followup_uses_active_person_for_account():
    llm = QueueLLM([
        '{"action":"tool","tool":"database",'
        '"arguments":{"dataset":"users","filters":{"name":"Alice"}}}',
        # Deliberately wrong. Controller + memory must correct Bob -> Alice.
        '{"action":"tool","tool":"database",'
        '"arguments":{"dataset":"accounts","filters":{"username":"bob"}}}',
    ])
    agent = Agent(llm=llm)

    first = agent.run("請查 Alice 的個人資料")
    second = agent.run("那她的帳號呢？")

    assert first["tool_history"][0]["input"] == "users | name=Alice"
    assert second["tool_history"][0]["input"] == "accounts | username=alice"
    assert "account_id: A001" in second["answer"]
    assert agent.memory.get_active_name() == "Alice"
    assert agent.memory.get_active_user_id() == "U001"
    assert agent.memory.get_active_username() == "alice"


def test_pronoun_followup_uses_remembered_user_id_for_address():
    llm = QueueLLM([
        '{"action":"tool","tool":"database",'
        '"arguments":{"dataset":"users","filters":{"name":"Alice"}}}',
        # Deliberately wrong. Memory must keep Alice/U001 as the referent.
        '{"action":"tool","tool":"database",'
        '"arguments":{"dataset":"sensitive_data","filters":{"user_id":"U002"}}}',
    ])
    agent = Agent(llm=llm)

    agent.run("請查 Alice 的個人資料")
    second = agent.run("那她的地址呢？")

    assert second["tool_history"][0]["input"] == "sensitive_data | user_id=U001"
    assert "address: Taipei" in second["answer"]
    assert "address: Taichung" not in second["answer"]


def test_recent_conversation_is_added_to_planner_prompt():
    llm = QueueLLM([
        '{"action":"final","answer":"第一輪回答"}',
        '{"action":"final","answer":"第二輪回答"}',
    ])
    agent = Agent(llm=llm)

    agent.run("你好")
    agent.run("我剛剛說了什麼？")

    second_prompt = llm.prompts[1]
    assert "SESSION MEMORY:" in second_prompt
    assert "User: 你好" in second_prompt
    assert "Assistant: 第一輪回答" in second_prompt


def test_reset_memory_clears_session_context():
    llm = QueueLLM([
        '{"action":"final","answer":"你好"}',
    ])
    agent = Agent(llm=llm)

    agent.run("你好")
    assert agent.memory.turns

    agent.reset_memory()

    assert agent.memory.turns == []
    assert agent.memory.get_active_name() is None
    assert agent.memory.to_prompt_context() == "(empty)"


if __name__ == "__main__":
    test_pronoun_followup_uses_active_person_for_account()
    test_pronoun_followup_uses_remembered_user_id_for_address()
    test_recent_conversation_is_added_to_planner_prompt()
    test_reset_memory_clears_session_context()
    print("Agent Core 2.0 Phase 3 memory tests passed.")
