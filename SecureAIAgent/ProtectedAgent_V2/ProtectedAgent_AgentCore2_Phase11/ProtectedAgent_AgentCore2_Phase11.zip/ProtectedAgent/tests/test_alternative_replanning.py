import sys
from pathlib import Path

PROJECT_DIR = Path(__file__).resolve().parents[1]
if str(PROJECT_DIR) not in sys.path:
    sys.path.insert(0, str(PROJECT_DIR))

from agent import Agent
from tool_manager import ToolManager
from tool_registry import ToolDefinition
from tools.database import DatabaseTool


class NoCallLLM:
    def generate(self, prompt):
        raise AssertionError("Deterministic alternative plan should not need the LLM")


class NameFailsDatabaseTool:
    """Simulate a source where name lookup fails but user_id works."""

    def __init__(self):
        self.delegate = DatabaseTool()
        self.calls = []

    def __call__(self, arguments=None):
        dataset, filters = self.delegate._normalize_arguments(arguments)
        self.calls.append((dataset, dict(filters)))

        if dataset == "users" and filters.get("name", "").lower() == "alice":
            return []

        return self.delegate(arguments)

    def to_history_input(self, arguments=None):
        return self.delegate.to_history_input(arguments)


def replace_database_tool(manager, handler):
    manager.register_tool(
        ToolDefinition(
            name="database",
            description="Test database wrapper.",
            input_schema={
                "dataset": "users | accounts | sensitive_data",
                "filters": "object",
            },
            handler=handler,
            error_results={"missing_database_query", "unknown_database_query"},
            exposed_to_agent=True,
        ),
        replace=True,
    )


def test_user_id_to_account_inserts_users_prerequisite():
    agent = Agent(llm=NoCallLLM())
    result = agent.run("請查 U001 的帳號")

    assert [item["input"] for item in result["tool_history"]] == [
        "users | user_id=U001",
        "accounts | username=alice",
    ]
    assert result["tool_history"][0]["include_in_answer"] is False
    assert result["tool_history"][1]["include_in_answer"] is True
    assert result["recovery_history"][0]["strategy"] == "insert_prerequisite"
    assert result["task_plan"]["replan_count"] == 1
    assert [step["arguments"]["dataset"] for step in result["task_plan"]["steps"]] == [
        "users",
        "accounts",
    ]
    assert "account_id: A001" in result["answer"]
    assert "email:" not in result["answer"]


def test_name_to_sensitive_data_inserts_users_prerequisite():
    agent = Agent(llm=NoCallLLM())
    result = agent.run("請查 Alice 的地址")

    assert [item["input"] for item in result["tool_history"]] == [
        "users | name=Alice",
        "sensitive_data | user_id=U001",
    ]
    assert result["tool_history"][0]["include_in_answer"] is False
    assert result["recovery_history"][0]["strategy"] == "insert_prerequisite"
    assert "address: Taipei" in result["answer"]
    assert "email:" not in result["answer"]


def test_account_id_to_sensitive_data_inserts_two_step_chain():
    agent = Agent(llm=NoCallLLM())
    result = agent.run("請查 A001 的地址")

    assert [item["input"] for item in result["tool_history"]] == [
        "accounts | account_id=A001",
        "users | name=Alice",
        "sensitive_data | user_id=U001",
    ]
    assert [item["include_in_answer"] for item in result["tool_history"]] == [
        False,
        False,
        True,
    ]
    assert result["task_plan"]["replan_count"] == 1
    assert [step["origin"] for step in result["task_plan"]["steps"]] == [
        "replan_prerequisite",
        "replan_prerequisite",
        "initial",
    ]
    assert "address: Taipei" in result["answer"]
    assert "role:" not in result["answer"]
    assert "email:" not in result["answer"]


def test_no_match_can_retry_with_trusted_alternate_identifier():
    manager = ToolManager()
    database = NameFailsDatabaseTool()
    replace_database_tool(manager, database)

    agent = Agent(llm=NoCallLLM(), tool_manager=manager)
    agent.memory.active_entity.update({
        "name": "Alice",
        "user_id": "U001",
    })

    result = agent.run("請查 Alice 的個人資料")

    assert database.calls == [
        ("users", {"name": "Alice"}),
        ("users", {"user_id": "U001"}),
    ]
    assert result["recovery_history"][0]["strategy"] == "retry_with_arguments"
    assert result["recovery_history"][0]["new_arguments"] == {
        "dataset": "users",
        "filters": {"user_id": "U001"},
    }
    assert result["task_plan"]["replan_count"] == 1
    assert result["task_plan"]["steps"][0]["attempts"] == 2
    assert result["task_plan"]["status"] == "COMPLETED"
    assert "user_id: U001" in result["answer"]


if __name__ == "__main__":
    test_user_id_to_account_inserts_users_prerequisite()
    test_name_to_sensitive_data_inserts_users_prerequisite()
    test_account_id_to_sensitive_data_inserts_two_step_chain()
    test_no_match_can_retry_with_trusted_alternate_identifier()
    print("Agent Core 2.0 Phase 7 alternative replanning tests passed.")
