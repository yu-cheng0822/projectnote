import sys
from pathlib import Path

PROJECT_DIR = Path(__file__).resolve().parents[1]
if str(PROJECT_DIR) not in sys.path:
    sys.path.insert(0, str(PROJECT_DIR))

from agent import Agent
from planner import TaskPlanner


class QueueLLM:
    def __init__(self, outputs):
        self.outputs = iter(outputs)

    def generate(self, prompt):
        try:
            return next(self.outputs)
        except StopIteration:
            return '{"action":"final","answer":"完成"}'


def test_calculator_flow():
    agent = Agent(
        llm=QueueLLM([
            '{"action":"tool","tool":"calculator",'
            '"arguments":{"expression":"123 * 456"}}'
        ])
    )

    result = agent.run("123 * 456 是多少？")

    assert result["answer"] == "計算結果：56088"
    assert result["tool_history"][0]["result"] == 56088


def test_alice_accounts_and_profile_flow():
    agent = Agent(
        llm=QueueLLM([
            '{"action":"tool","tool":"database",'
            '"arguments":{"dataset":"accounts",'
            '"filters":{"username":"alice"}}}',
            '{"action":"tool","tool":"database",'
            '"arguments":{"dataset":"users",'
            '"filters":{"name":"Alice"}}}',
        ])
    )

    result = agent.run("請查 Alice 的帳號和個人資料")

    assert len(result["tool_history"]) == 2
    # Phase 5 uses dependency-aware planning: identify the user first, then
    # derive the account username from verified user data.
    assert result["tool_history"][0]["input"] == "users | name=Alice"
    assert result["tool_history"][1]["input"] == "accounts | username=alice"
    assert "account_id: A001" in result["answer"]
    assert "user_id: U001" in result["answer"]


def test_general_conversation_final_action():
    agent = Agent(
        llm=QueueLLM([
            '{"action":"final","tool":null,"arguments":{},'
            '"answer":"你好！有什麼我可以協助你的嗎？"}'
        ])
    )

    result = agent.run("你好")

    assert result["tool_history"] == []
    assert result["answer"] == "你好！有什麼我可以協助你的嗎？"


def test_json_code_fence_parser():
    planner = TaskPlanner()
    action = planner.parse_action(
        '```json\n'
        '{"action":"tool","tool":"calculator",'
        '"arguments":{"expression":"2 + 3"}}\n'
        '```'
    )

    assert action.action == "tool"
    assert action.tool == "calculator"
    assert action.arguments["expression"] == "2 + 3"


def test_legacy_output_fallback():
    planner = TaskPlanner()
    action = planner.parse_action("DATABASE: users | name=Alice")

    assert action.action == "tool"
    assert action.tool == "database"
    assert action.arguments["dataset"] == "users"
    assert action.arguments["filters"]["name"] == "Alice"


def test_controller_corrects_wrong_database_filter():
    agent = Agent(
        llm=QueueLLM([
            '{"action":"tool","tool":"database",'
            '"arguments":{"dataset":"users",'
            '"filters":{"name":"Bob"}}}'
        ])
    )

    result = agent.run("請查 Alice 的個人資料")

    assert result["tool_history"][0]["input"] == "users | name=Alice"
    assert "user_id: U001" in result["answer"]
    assert "user_id: U002" not in result["answer"]


if __name__ == "__main__":
    test_calculator_flow()
    test_alice_accounts_and_profile_flow()
    test_general_conversation_final_action()
    test_json_code_fence_parser()
    test_legacy_output_fallback()
    test_controller_corrects_wrong_database_filter()
    print("Agent Core 2.0 Phase 2 tests passed.")
