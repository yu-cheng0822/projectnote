import sys
from pathlib import Path

PROJECT_DIR = Path(__file__).resolve().parents[1]
if str(PROJECT_DIR) not in sys.path:
    sys.path.insert(0, str(PROJECT_DIR))

from agent import Agent
from planner import TaskPlanner


class NoCallLLM:
    def generate(self, prompt):
        raise AssertionError("Deterministic task plan should not need the LLM")


class QueueLLM:
    def __init__(self, outputs):
        self.outputs = iter(outputs)

    def generate(self, prompt):
        try:
            return next(self.outputs)
        except StopIteration:
            return '{"action":"final","answer":"完成"}'


def test_database_plan_has_explicit_dependency_order():
    planner = TaskPlanner()
    plan = planner.create_task_plan("請查 Alice 的帳號和個人資料")

    assert plan is not None
    assert [step.tool for step in plan.steps] == ["database", "database"]
    assert [step.arguments["dataset"] for step in plan.steps] == [
        "users",
        "accounts",
    ]
    assert plan.status == "PLANNED"


def test_mixed_database_and_calculator_plan_executes_without_llm():
    agent = Agent(llm=NoCallLLM())

    result = agent.run("請查 Alice 的帳號和個人資料，並計算 123 * 456")

    assert [item["tool"] for item in result["tool_history"]] == [
        "database",
        "database",
        "calculator",
    ]
    assert result["tool_history"][0]["input"] == "users | name=Alice"
    assert result["tool_history"][1]["input"] == "accounts | username=alice"
    assert result["tool_history"][2]["result"] == 56088
    assert "user_id: U001" in result["answer"]
    assert "account_id: A001" in result["answer"]
    assert "計算結果：56088" in result["answer"]
    assert result["task_plan"]["status"] == "COMPLETED"
    assert all(
        step["status"] == "COMPLETED"
        for step in result["task_plan"]["steps"]
    )


def test_calculator_gets_single_step_plan():
    planner = TaskPlanner()
    plan = planner.create_task_plan("123 * 456 是多少？")

    assert plan is not None
    assert len(plan.steps) == 1
    assert plan.steps[0].tool == "calculator"
    assert plan.steps[0].arguments["expression"] == "123 * 456"


def test_ordinary_chat_still_uses_llm_action_path():
    agent = Agent(
        llm=QueueLLM([
            '{"action":"final","answer":"你好！"}',
        ])
    )

    result = agent.run("你好")

    assert result["task_plan"] is None
    assert result["answer"] == "你好！"


def test_empty_database_result_marks_plan_failed():
    agent = Agent(llm=NoCallLLM())

    result = agent.run("請查 David 的個人資料")

    assert result["tool_history"][0]["input"] == "users | name=David"
    assert result["tool_history"][0]["success"] is False
    assert result["tool_history"][0]["result"] == "no_matching_records"
    assert result["task_plan"]["status"] == "FAILED"
    assert result["task_plan"]["steps"][0]["status"] == "FAILED"
    assert "no_matching_records" in result["answer"]


if __name__ == "__main__":
    test_database_plan_has_explicit_dependency_order()
    test_mixed_database_and_calculator_plan_executes_without_llm()
    test_calculator_gets_single_step_plan()
    test_ordinary_chat_still_uses_llm_action_path()
    test_empty_database_result_marks_plan_failed()
    print("Agent Core 2.0 Phase 5 task plan tests passed.")
