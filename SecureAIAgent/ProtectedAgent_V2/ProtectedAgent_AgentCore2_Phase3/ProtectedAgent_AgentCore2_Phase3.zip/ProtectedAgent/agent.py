import json
import re

from llm import LocalLLM
from tool import ToolExecutor
from models import AgentAction, AgentState, ToolResult
from planner import TaskPlanner
from memory import ConversationMemory


class Agent:

    def __init__(
        self,
        agent_id="agent_001",
        llm=None,
        tool_executor=None,
        session_id="session_001",
    ):
        self.agent_id = agent_id
        self.session_id = session_id
        self.llm = llm if llm is not None else LocalLLM()
        self.tool_executor = (
            tool_executor if tool_executor is not None else ToolExecutor()
        )
        self.planner = TaskPlanner()
        self.memory = ConversationMemory(max_turns=8)

    # ==================================================
    # Dataset Planning Helpers
    # ==================================================

    def get_required_datasets(self, user_input):
        return self.planner.get_required_datasets(user_input)

    def get_completed_datasets(self, tool_history):
        return self.planner.get_completed_datasets(tool_history)

    def get_database_records(self, tool_history, dataset):
        records = []

        for record in tool_history:
            if record.get("tool") != "database":
                continue
            if not record.get("success"):
                continue

            query = record.get("input", "")
            current_dataset = query.split("|", 1)[0].strip().lower()

            if current_dataset == dataset:
                result = record.get("result")
                if isinstance(result, list):
                    records.extend(result)

        return records

    def has_successful_query(self, tool_history, query):
        normalized = str(query).strip().lower()

        for record in tool_history:
            if not record.get("success"):
                continue

            old_query = str(record.get("input", "")).strip().lower()
            if old_query == normalized:
                return True

        return False

    # ==================================================
    # Entity / Query Helpers
    # ==================================================

    def extract_person_name(self, user_input):
        known_names = ["alice", "bob", "charlie"]
        lower_text = user_input.strip().lower()

        for name in known_names:
            if name in lower_text:
                return name.capitalize()

        if self.memory.refers_to_active_entity(user_input):
            return self.memory.get_active_name()

        return None

    def extract_user_id(self, user_input):
        match = re.search(r"\bU\d{3}\b", user_input, re.IGNORECASE)
        if match:
            return match.group(0).upper()

        if self.memory.refers_to_active_entity(user_input):
            return self.memory.get_active_user_id()

        return None

    def extract_username(self, user_input):
        person_name = self.extract_person_name(user_input)
        if person_name:
            return person_name.lower()

        if self.memory.refers_to_active_entity(user_input):
            return self.memory.get_active_username()

        return None

    def build_database_query(self, dataset, user_input, tool_history):
        if dataset == "accounts":
            users = self.get_database_records(tool_history, "users")
            if users:
                name = users[0].get("name")
                if name:
                    return "accounts | username=" + str(name).lower()

            username = self.extract_username(user_input)
            if username:
                return "accounts | username=" + username

            return "accounts"

        if dataset == "users":
            accounts = self.get_database_records(tool_history, "accounts")
            if accounts:
                username = accounts[0].get("username")
                if username:
                    return "users | name=" + str(username).capitalize()

            user_id = self.extract_user_id(user_input)
            if user_id:
                return "users | user_id=" + user_id

            name = self.extract_person_name(user_input)
            if name:
                return "users | name=" + name

            return "users"

        if dataset == "sensitive_data":
            users = self.get_database_records(tool_history, "users")
            if users:
                user_id = users[0].get("user_id")
                if user_id:
                    return "sensitive_data | user_id=" + str(user_id)

            user_id = self.extract_user_id(user_input)
            if user_id:
                return "sensitive_data | user_id=" + user_id

            return "sensitive_data"

        return dataset

    def build_database_action(self, dataset, user_input, tool_history):
        query = self.build_database_query(dataset, user_input, tool_history)
        return self.planner.database_query_to_action(query)

    # ==================================================
    # Structured Action Planning
    # ==================================================

    def decide(
        self,
        user_input,
        tool_history=None,
        missing_datasets=None,
        memory_context=None,
    ):
        if tool_history is None:
            tool_history = []
        if missing_datasets is None:
            missing_datasets = []
        if memory_context is None:
            memory_context = self.memory.to_prompt_context()

        history_text = json.dumps(
            tool_history,
            ensure_ascii=False,
            indent=2,
        )

        missing_text = json.dumps(missing_datasets, ensure_ascii=False)

        prompt = f"""
You are the planning component of an autonomous AI assistant.
Choose exactly ONE next action.

Return ONLY one valid JSON object. Do not use Markdown. Do not add explanations.

JSON schema:

For calculator:
{{
  "action": "tool",
  "tool": "calculator",
  "arguments": {{
    "expression": "123 * 456"
  }}
}}

For database:
{{
  "action": "tool",
  "tool": "database",
  "arguments": {{
    "dataset": "users",
    "filters": {{
      "name": "Alice"
    }}
  }}
}}

For a final answer that needs no tool:
{{
  "action": "final",
  "tool": null,
  "arguments": {{}},
  "answer": "Traditional Chinese answer here"
}}

AVAILABLE DATABASE DATASETS:
- users: filters user_id, name
- accounts: filters account_id, username
- sensitive_data: filter user_id

RULES:
1. Use calculator only for real arithmetic.
2. Use database for requests that need database records.
3. Never invent database values.
4. Never use SQL.
5. Query only ONE dataset per action.
6. Do not repeat a successful database query.
7. If MISSING DATASETS is not empty, choose one of those datasets.
8. Do not return final while required data is still missing.
9. For ordinary conversation or knowledge questions that need no tool, return final and put the answer in the answer field.
10. The answer field must be Traditional Chinese when action is final.

USER REQUEST:
{user_input}

TOOL HISTORY:
{history_text}

MISSING DATASETS:
{missing_text}

SESSION MEMORY:
{memory_context}

MEMORY RULES:
- Use SESSION MEMORY only to resolve conversational references such as 她/他/那個人.
- A new explicit name or ID in USER REQUEST overrides the previous active entity.
- Do not invent facts that are not present in USER REQUEST, TOOL HISTORY, or SESSION MEMORY.
"""

        raw_output = self.llm.generate(prompt)
        return self.planner.parse_action(raw_output)

    def validate_action(
        self,
        action,
        user_input,
        missing_datasets,
        tool_history,
    ):
        """Controller-side validation of one structured LLM action."""

        if not isinstance(action, AgentAction):
            action = AgentAction(action="final")

        # Required database information has priority over an invalid/early action.
        if missing_datasets:
            if action.action != "tool" or action.tool != "database":
                return self.build_database_action(
                    missing_datasets[0],
                    user_input,
                    tool_history,
                )

            dataset = str(action.arguments.get("dataset", "")).strip().lower()
            if dataset not in missing_datasets:
                return self.build_database_action(
                    missing_datasets[0],
                    user_input,
                    tool_history,
                )

            # Prefer deterministic identifiers that are already supported by
            # the user request or previous tool results. This prevents the LLM
            # from silently changing Alice -> Bob, U001 -> U002, etc.
            expected_action = self.build_database_action(
                dataset,
                user_input,
                tool_history,
            )
            expected_query = self.planner.action_to_database_query(
                expected_action
            )
            model_query = self.planner.action_to_database_query(action)

            if expected_query != dataset:
                return expected_action

            if model_query == dataset:
                return expected_action

            return action

        if action.action == "tool":
            if action.tool == "calculator":
                expression = str(action.arguments.get("expression", "")).strip()
                return AgentAction(
                    action="tool",
                    tool="calculator",
                    arguments={"expression": expression},
                )

            if action.tool == "database":
                dataset = str(action.arguments.get("dataset", "")).strip().lower()
                if dataset not in self.planner.VALID_DATASETS:
                    return AgentAction(action="final")
                return action

            return AgentAction(action="final")

        return action

    # ==================================================
    # Tool Helpers
    # ==================================================

    def is_valid_calculator_expression(self, expression):
        if not expression:
            return False

        pattern = r"^[0-9+\-*/().\s]+$"
        return bool(re.fullmatch(pattern, expression.strip()))

    def print_action(self, action, step):
        print(f"\n===== Agent Action (Step {step}) =====")
        print(
            json.dumps(
                action.to_dict(),
                ensure_ascii=False,
                indent=2,
            )
        )

    def final_result(self, state, tool=None):
        state.finish(state.final_answer or "")
        self.memory.add_turn(state.user_request, state.final_answer)
        return {
            "decision": "FINAL",
            "tool": tool,
            "tool_history": state.tool_history,
            "answer": state.final_answer,
        }

    def reset_memory(self):
        self.memory.reset()

    # ==================================================
    # Final Answer Generation
    # ==================================================

    def generate_final_answer(self, user_input, tool_history):
        for record in tool_history:
            if record.get("tool") == "calculator" and record.get("success"):
                return f"計算結果：{record.get('result')}"

        answer_parts = []

        accounts = self.get_database_records(tool_history, "accounts")
        users = self.get_database_records(tool_history, "users")
        sensitive_data = self.get_database_records(tool_history, "sensitive_data")

        if accounts:
            answer_parts.append("帳號資訊：")
            for record in accounts:
                for key, value in record.items():
                    answer_parts.append(f"{key}: {value}")

        if users:
            answer_parts.append("個人資料：")
            for record in users:
                for key, value in record.items():
                    answer_parts.append(f"{key}: {value}")

        if sensitive_data:
            answer_parts.append("敏感資料：")
            for record in sensitive_data:
                for key, value in record.items():
                    answer_parts.append(f"{key}: {value}")

        if answer_parts:
            return "\n".join(answer_parts)

        prompt = f"""
You are a helpful AI assistant.

User request:
{user_input}

Answer in Traditional Chinese.
Do not invent facts.
"""
        return self.llm.generate(prompt).strip()

    # ==================================================
    # Main Agent Loop
    # ==================================================

    def run(self, user_input):
        state = AgentState(
            user_request=user_input,
            required_datasets=self.get_required_datasets(user_input),
            max_tool_calls=5,
        )

        for step in range(1, state.max_tool_calls + 1):
            state.current_step = step
            state.refresh_datasets(self.planner)

            # When explicit database requirements are complete, finish from
            # collected evidence without asking the model for another action.
            if state.required_datasets and not state.missing_datasets:
                state.final_answer = self.generate_final_answer(
                    user_input,
                    state.tool_history,
                )
                print("\n===== AI Answer =====")
                print(state.final_answer)
                return self.final_result(state)

            action = self.decide(
                user_input,
                state.tool_history,
                state.missing_datasets,
                self.memory.to_prompt_context(),
            )

            action = self.validate_action(
                action,
                user_input,
                state.missing_datasets,
                state.tool_history,
            )

            self.print_action(action, step)

            # ====================================
            # FINAL
            # ====================================
            if action.action == "final":
                state.final_answer = action.answer or self.generate_final_answer(
                    user_input,
                    state.tool_history,
                )

                print("\n===== AI Answer =====")
                print(state.final_answer)
                return self.final_result(state)

            # ====================================
            # CALCULATOR
            # ====================================
            if action.tool == "calculator":
                expression = str(
                    action.arguments.get("expression", "")
                ).strip()

                if not self.is_valid_calculator_expression(expression):
                    state.final_answer = (
                        "無法執行這個計算要求，因為輸入不是有效的數學運算式。"
                    )
                    print("\n===== AI Answer =====")
                    print(state.final_answer)
                    return self.final_result(state, tool="calculator")

                success, result = self.tool_executor.execute(
                    "calculator",
                    expression,
                )

                state.add_tool_result(
                    ToolResult(
                        tool="calculator",
                        input=expression,
                        success=success,
                        result=result,
                    )
                )

                print("\n===== Tool Result =====")
                print("Tool: calculator")
                print("Success:", success)
                print("Result:", result)

                state.final_answer = (
                    f"計算結果：{result}" if success else f"計算失敗：{result}"
                )

                print("\n===== AI Answer =====")
                print(state.final_answer)
                return self.final_result(state, tool="calculator")

            # ====================================
            # DATABASE
            # ====================================
            if action.tool == "database":
                query = self.planner.action_to_database_query(action)

                if self.has_successful_query(state.tool_history, query):
                    if state.missing_datasets:
                        action = self.build_database_action(
                            state.missing_datasets[0],
                            user_input,
                            state.tool_history,
                        )
                        query = self.planner.action_to_database_query(action)

                    if self.has_successful_query(state.tool_history, query):
                        state.final_answer = self.generate_final_answer(
                            user_input,
                            state.tool_history,
                        )
                        print("\n===== AI Answer =====")
                        print(state.final_answer)
                        return self.final_result(state)

                print("\n[DEBUG] Database Query:")
                print(repr(query))

                success, result = self.tool_executor.execute(
                    "database",
                    query,
                )

                state.add_tool_result(
                    ToolResult(
                        tool="database",
                        input=query,
                        success=success,
                        result=result,
                    )
                )

                if success:
                    self.memory.observe_database_result(query, result)

                print("\n===== Tool Result =====")
                print("Tool: database")
                print("Success:", success)
                print("Result:", result)

                if not success:
                    state.final_answer = f"資料查詢失敗：{result}"
                    print("\n===== AI Answer =====")
                    print(state.final_answer)
                    return self.final_result(state, tool="database")

                # If the model selected a database tool for a request not caught
                # by the deterministic dataset detector, return the evidence now.
                if not state.required_datasets:
                    state.final_answer = self.generate_final_answer(
                        user_input,
                        state.tool_history,
                    )
                    print("\n===== AI Answer =====")
                    print(state.final_answer)
                    return self.final_result(state, tool="database")

                continue

        state.final_answer = self.generate_final_answer(
            user_input,
            state.tool_history,
        )
        print("\n===== AI Answer =====")
        print(state.final_answer)
        return self.final_result(state)


if __name__ == "__main__":
    print("Please run ProtectedAgent through main.py")
