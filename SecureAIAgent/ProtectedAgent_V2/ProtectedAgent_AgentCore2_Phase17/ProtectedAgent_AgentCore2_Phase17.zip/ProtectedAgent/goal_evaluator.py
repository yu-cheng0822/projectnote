import json
import re

from models import GoalEvaluation, PlanStep


class GoalCompletionEvaluator:
    """Verify that executed evidence actually satisfies the original goal.

    Deterministic calculator/database goals are checked locally so stable
    requests do not incur another LLM call. LLM-decomposed compound goals may
    use one bounded structured evaluation pass after all current plan steps
    complete. Any proposed supplemental steps are validated against the current
    Tool Registry before Agent Core can append them to the plan.
    """

    MAX_ADDITIONAL_STEPS = 4

    def __init__(self, llm, planner, tool_manager, max_goal_replans=2):
        self.llm = llm
        self.planner = planner
        self.tool_manager = tool_manager
        self.max_goal_replans = int(max_goal_replans)

    def evaluate(self, state, candidate_answer=""):
        deterministic = self._evaluate_deterministic_requirements(state)
        if not deterministic.complete:
            return deterministic

        task_plan = state.task_plan
        if task_plan is None or task_plan.source not in {"llm_decomposition", "generic_llm"}:
            return deterministic

        # The plan must be structurally complete before semantic evaluation.
        if not task_plan.all_completed():
            return GoalEvaluation(
                status="incomplete",
                reason="task_plan_not_completed",
                source="structural",
            )

        if state.goal_replan_count >= self.max_goal_replans:
            return GoalEvaluation(
                status="complete",
                reason="goal_replan_limit_reached_structural_fallback",
                source="structural_fallback",
            )

        return self._evaluate_with_llm(state, candidate_answer)

    def _evaluate_deterministic_requirements(self, state):
        missing = []

        completed_datasets = set(
            self.planner.get_completed_datasets(state.tool_history)
        )
        for dataset in self.planner.get_required_datasets(state.user_request):
            if dataset not in completed_datasets:
                missing.append(f"dataset:{dataset}")

        expression = self.planner.extract_arithmetic_expression(
            state.user_request
        )
        if expression:
            normalized = self._normalize_expression(expression)
            calculation_found = any(
                record.get("tool") == "calculator"
                and record.get("success")
                and self._normalize_expression(record.get("input", "")) == normalized
                for record in state.tool_history
            )
            if not calculation_found:
                missing.append(f"calculator:{expression}")

        if not missing:
            return GoalEvaluation(
                status="complete",
                reason="deterministic_requirements_satisfied",
                source="deterministic",
            )

        additional_steps = self._build_deterministic_supplemental_steps(
            state,
            missing,
        )
        return GoalEvaluation(
            status="incomplete",
            reason="deterministic_requirements_missing",
            missing_requirements=missing,
            additional_steps=additional_steps,
            source="deterministic",
        )

    def _build_deterministic_supplemental_steps(self, state, missing):
        planned = self.planner.create_task_plan(state.user_request)
        if planned is None:
            return []

        wanted = set(missing)
        steps = []
        for step in planned.steps:
            if step.tool == "database":
                dataset = str(step.arguments.get("dataset", "")).lower()
                key = f"dataset:{dataset}"
            elif step.tool == "calculator":
                expression = str(step.arguments.get("expression", ""))
                key = f"calculator:{expression}"
            else:
                continue

            if key not in wanted:
                continue

            steps.append(
                PlanStep(
                    step_id=0,
                    description=step.description,
                    tool=step.tool,
                    arguments=dict(step.arguments),
                    include_in_answer=step.include_in_answer,
                    origin="goal_completion",
                    depends_on=[],
                )
            )

        return steps[: self.MAX_ADDITIONAL_STEPS]

    def _evaluate_with_llm(self, state, candidate_answer):
        plan_payload = (
            state.task_plan.to_dict() if state.task_plan is not None else None
        )
        evidence = json.dumps(
            state.tool_history,
            ensure_ascii=False,
            indent=2,
        )
        tools = self.tool_manager.prompt_catalog()

        prompt = f"""
You are the goal-completion evaluator of an autonomous AI assistant.
Determine whether the ORIGINAL USER GOAL is satisfied by the ACTUAL TOOL EVIDENCE.
Do not judge style. Judge only whether required factual/tool work is complete.

Return ONLY one valid JSON object. No Markdown. No explanation outside JSON.

If complete:
{{
  "status": "complete",
  "reason": "short reason",
  "missing_requirements": [],
  "additional_steps": []
}}

If incomplete and a safe executable supplement can resolve it:
{{
  "status": "incomplete",
  "reason": "short reason",
  "missing_requirements": ["what is still missing"],
  "additional_steps": [
    {{
      "description": "what this step obtains",
      "tool": "registered_tool_name",
      "arguments": {{}},
      "depends_on": [],
      "include_in_answer": true
    }}
  ]
}}

AVAILABLE TOOLS:
{tools}

RULES:
1. Use only actual evidence. Never assume a tool result that is not present.
2. Do not repeat a completed tool action unless new arguments are necessary.
3. Propose at most {self.MAX_ADDITIONAL_STEPS} additional steps.
4. Use only registered tools.
5. Do not propose final-response wording as a tool step.
6. If no safe registered-tool step can fill the gap, return incomplete with an empty additional_steps list.
7. For database, use only users/accounts/sensitive_data and never use SQL.
8. Earlier step results may be referenced using exact syntax such as {{{{step:1.result.name}}}}.

ORIGINAL USER GOAL:
{state.user_request}

CURRENT TASK PLAN:
{json.dumps(plan_payload, ensure_ascii=False, indent=2)}

ACTUAL TOOL EVIDENCE:
{evidence}

CANDIDATE ANSWER:
{candidate_answer}
"""
        raw = self.llm.generate(prompt)
        parsed = self._extract_json_object(raw)
        if not isinstance(parsed, dict):
            return GoalEvaluation(
                status="complete",
                reason="invalid_evaluator_output_structural_fallback",
                source="structural_fallback",
            )

        status = str(parsed.get("status", "")).strip().lower()
        if status == "complete":
            return GoalEvaluation(
                status="complete",
                reason=str(parsed.get("reason") or "llm_goal_satisfied").strip(),
                source="llm_evaluation",
            )

        if status != "incomplete":
            return GoalEvaluation(
                status="complete",
                reason="unknown_evaluator_status_structural_fallback",
                source="structural_fallback",
            )

        missing = parsed.get("missing_requirements", [])
        if not isinstance(missing, list):
            missing = []
        missing = [str(item).strip() for item in missing if str(item).strip()]

        additional_steps = self._parse_additional_steps(
            parsed.get("additional_steps", []),
            state,
        )

        return GoalEvaluation(
            status="incomplete",
            reason=str(parsed.get("reason") or "goal_incomplete").strip(),
            missing_requirements=missing,
            additional_steps=additional_steps,
            source="llm_evaluation",
        )

    def _parse_additional_steps(self, items, state):
        if not isinstance(items, list):
            return []

        valid_tools = set(
            self.tool_manager.available_tool_names(exposed_only=True)
        )
        existing_actions = self._existing_action_keys(state)
        parsed_steps = []
        base_step_count = len(state.task_plan.steps) if state.task_plan else 0

        for item in items[: self.MAX_ADDITIONAL_STEPS]:
            if not isinstance(item, dict):
                continue

            tool = str(item.get("tool", "")).strip().lower()
            if tool not in valid_tools:
                continue

            arguments = item.get("arguments", {})
            if not isinstance(arguments, dict):
                continue

            if tool == "database":
                dataset = str(arguments.get("dataset", "")).strip().lower()
                if dataset not in self.planner.VALID_DATASETS:
                    continue

            action_key = self._action_key(tool, arguments)
            if action_key in existing_actions:
                continue

            depends_on = item.get("depends_on", [])
            if not isinstance(depends_on, list):
                depends_on = []

            normalized_dependencies = []
            future_step_id = base_step_count + len(parsed_steps) + 1
            valid_dependencies = True
            for dependency in depends_on:
                try:
                    dependency_id = int(dependency)
                except (TypeError, ValueError):
                    valid_dependencies = False
                    break
                if dependency_id < 1 or dependency_id >= future_step_id:
                    valid_dependencies = False
                    break
                if dependency_id not in normalized_dependencies:
                    normalized_dependencies.append(dependency_id)

            if not valid_dependencies:
                continue

            parsed_steps.append(
                PlanStep(
                    step_id=0,
                    description=str(
                        item.get("description") or f"補充執行 {tool}"
                    ).strip(),
                    tool=tool,
                    arguments=dict(arguments),
                    include_in_answer=bool(item.get("include_in_answer", True)),
                    origin="goal_completion",
                    depends_on=normalized_dependencies,
                )
            )
            existing_actions.add(action_key)

        return parsed_steps

    def _existing_action_keys(self, state):
        keys = set()
        if state.task_plan is not None:
            for step in state.task_plan.steps:
                if step.status == "COMPLETED":
                    keys.add(self._action_key(step.tool, step.arguments))
        return keys

    @staticmethod
    def _action_key(tool, arguments):
        try:
            serialized = json.dumps(arguments, ensure_ascii=False, sort_keys=True)
        except TypeError:
            serialized = repr(arguments)
        return str(tool).strip().lower(), serialized

    @staticmethod
    def _normalize_expression(expression):
        return re.sub(r"\s+", "", str(expression or "")).replace("×", "*").replace("÷", "/")

    @staticmethod
    def _extract_json_object(raw_output):
        if raw_output is None:
            return None

        text = str(raw_output).strip()
        if not text:
            return None

        if text.startswith("```"):
            text = re.sub(r"^```(?:json)?\s*", "", text, flags=re.I)
            text = re.sub(r"\s*```$", "", text)

        decoder = json.JSONDecoder()
        for index, char in enumerate(text):
            if char != "{":
                continue
            try:
                value, _ = decoder.raw_decode(text[index:])
            except json.JSONDecodeError:
                continue
            if isinstance(value, dict):
                return value
        return None
