import json
import re

from models import PlanStep, TaskPlan


class GenericPlanner:
    """Metadata-driven planner for registered tools outside hard-coded domains.

    Phase 15 keeps the proven deterministic calculator/database planner, but
    adds a generic route for tools described by Tool Registry metadata. The
    planner first retrieves a small relevant-tool catalog, then asks the LLM
    for a structured TaskPlan that is validated against the live registry.
    """

    MAX_STEPS = 8

    def __init__(self, llm, tool_manager):
        self.llm = llm
        self.tool_manager = tool_manager

    def should_plan(self, user_input, deterministic_plan=None):
        """Use generic planning for semantic custom-tool intent.

        Explicitly named custom tools keep using the Phase 9 decomposition path
        for backwards compatibility. The new behavior is intentionally aimed
        at requests such as "台北天氣如何" where no implementation name appears.
        """

        text = str(user_input).strip().lower()
        if not text:
            return False

        candidates = self.tool_manager.relevant_tools(user_input, limit=6)
        if not candidates:
            return False

        exposed_names = self.tool_manager.available_tool_names(exposed_only=True)
        explicitly_named = {
            name
            for name in exposed_names
            if str(name).strip().lower() in text
        }

        candidate_names = {item["name"] for item in candidates}
        custom_candidates = candidate_names - {"calculator", "database"}

        # Preserve Phase 9 behavior when users explicitly name custom tools.
        if custom_candidates & explicitly_named:
            return False

        # A stable deterministic plan remains authoritative unless a separate
        # custom capability is semantically relevant to the same request.
        if deterministic_plan is not None and not custom_candidates:
            return False

        return bool(custom_candidates)

    def plan(self, user_input, memory_context="(empty)"):
        candidates = self.tool_manager.relevant_tools(user_input, limit=6)
        if not candidates:
            return None

        candidate_names = [item["name"] for item in candidates]
        catalog = self.tool_manager.planning_catalog(
            names=candidate_names,
        )

        prompt = f"""
You are the generic planning component of an autonomous AI assistant.
Create a SMALL executable tool plan for the user's goal using only the
candidate tools selected from the runtime Tool Registry.

Return ONLY one valid JSON object. No Markdown. No explanation.

Schema:
{{
  "goal": "short goal summary",
  "steps": [
    {{
      "description": "what this step accomplishes",
      "tool": "registered_tool_name",
      "arguments": {{}},
      "depends_on": [],
      "include_in_answer": true
    }}
  ]
}}

CANDIDATE TOOLS:
{catalog}

REFERENCE SYNTAX:
A later step may consume an earlier tool result with an exact reference such as:
{{{{step:1.result}}}}
{{{{step:1.result.name}}}}
{{{{step:1.result.0.value}}}}

RULES:
1. Use only tools shown in CANDIDATE TOOLS.
2. Follow each tool's input_schema exactly.
3. Create at most {self.MAX_STEPS} steps.
4. Do not invent tool results or facts.
5. dependencies may reference only earlier steps.
6. Use include_in_answer=false for intermediate/supporting steps.
7. Do not add a step for final-response wording.
8. If none of the candidate tools can actually satisfy the request, return an empty steps list.

USER REQUEST:
{user_input}

RELEVANT MEMORY CONTEXT:
{memory_context}
"""
        raw = self.llm.generate(prompt)
        return self.parse_plan(
            raw,
            fallback_goal=str(user_input),
            allowed_tools=set(candidate_names),
        )

    def parse_plan(self, raw_output, fallback_goal="", allowed_tools=None):
        payload = self._extract_json_object(raw_output)
        if not isinstance(payload, dict):
            return None

        steps_data = payload.get("steps")
        if not isinstance(steps_data, list) or not steps_data:
            return None

        live_tools = set(
            self.tool_manager.available_tool_names(exposed_only=True)
        )
        if allowed_tools is not None:
            live_tools &= set(allowed_tools)

        steps = []
        for index, item in enumerate(steps_data[: self.MAX_STEPS], start=1):
            if not isinstance(item, dict):
                return None

            tool = str(item.get("tool", "")).strip().lower()
            if tool not in live_tools:
                return None

            arguments = item.get("arguments", {})
            if not isinstance(arguments, dict):
                return None

            # If arguments are concrete, validate them against the live tool
            # schema before accepting the plan. Step-reference placeholders are
            # resolved later, so their final type is validated at execution.
            if not self._contains_step_reference(arguments):
                valid, _ = self.tool_manager.validate_arguments(tool, arguments)
                if not valid:
                    return None

            depends_on = item.get("depends_on", [])
            if not isinstance(depends_on, list):
                return None

            normalized_dependencies = []
            for dependency in depends_on:
                try:
                    dependency_id = int(dependency)
                except (TypeError, ValueError):
                    return None
                if dependency_id < 1 or dependency_id >= index:
                    return None
                if dependency_id not in normalized_dependencies:
                    normalized_dependencies.append(dependency_id)

            steps.append(
                PlanStep(
                    step_id=index,
                    description=str(
                        item.get("description") or f"執行 {tool}"
                    ).strip(),
                    tool=tool,
                    arguments=dict(arguments),
                    include_in_answer=bool(item.get("include_in_answer", True)),
                    origin="generic_planner",
                    depends_on=normalized_dependencies,
                )
            )

        if not steps:
            return None

        return TaskPlan(
            goal=str(payload.get("goal") or fallback_goal).strip(),
            steps=steps,
            source="generic_llm",
        )

    def _contains_step_reference(self, value):
        if isinstance(value, str):
            return bool(re.search(r"\{\{step:\d+\.result", value))
        if isinstance(value, dict):
            return any(self._contains_step_reference(item) for item in value.values())
        if isinstance(value, list):
            return any(self._contains_step_reference(item) for item in value)
        return False

    @staticmethod
    def _extract_json_object(raw_output):
        if raw_output is None:
            return None

        text = str(raw_output).strip()
        if not text:
            return None

        if text.startswith("```"):
            text = re.sub(r"^```(?:json)?\s*", "", text, flags=re.I)
            text = re.sub(r"\s*```$", "", text)

        decoder = json.JSONDecoder()
        for index, char in enumerate(text):
            if char != "{":
                continue
            try:
                value, _ = decoder.raw_decode(text[index:])
            except json.JSONDecodeError:
                continue
            if isinstance(value, dict):
                return value
        return None
