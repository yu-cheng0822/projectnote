import json
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path


class SQLitePersistentMemoryStore:
    """Small local persistent fact store using only Python stdlib sqlite3.

    Every database operation opens a short-lived connection and closes it
    explicitly. This is important on Windows, where an unclosed SQLite handle
    can keep the database file locked and prevent TemporaryDirectory cleanup.
    """

    def __init__(self, path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._ensure_schema()

    def _connect(self):
        return sqlite3.connect(self.path)

    @contextmanager
    def _connection(self):
        """Yield one transaction-scoped SQLite connection and always close it."""

        connection = self._connect()
        try:
            yield connection
            connection.commit()
        except Exception:
            connection.rollback()
            raise
        finally:
            connection.close()

    def _ensure_schema(self):
        with self._connection() as connection:
            connection.execute(
                """
                CREATE TABLE IF NOT EXISTS persistent_facts (
                    key TEXT PRIMARY KEY,
                    value_json TEXT NOT NULL,
                    source TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                )
                """
            )

    def set_fact(self, key, value, source="user"):
        now = datetime.now(timezone.utc).isoformat()
        payload = json.dumps(value, ensure_ascii=False)
        with self._connection() as connection:
            connection.execute(
                """
                INSERT INTO persistent_facts(
                    key, value_json, source, created_at, updated_at
                ) VALUES (?, ?, ?, ?, ?)
                ON CONFLICT(key) DO UPDATE SET
                    value_json=excluded.value_json,
                    source=excluded.source,
                    updated_at=excluded.updated_at
                """,
                (str(key), payload, str(source), now, now),
            )

    def get_all(self):
        with self._connection() as connection:
            rows = connection.execute(
                """
                SELECT key, value_json, source, created_at, updated_at
                FROM persistent_facts
                ORDER BY key
                """
            ).fetchall()

        result = {}
        for key, value_json, source, created_at, updated_at in rows:
            try:
                value = json.loads(value_json)
            except json.JSONDecodeError:
                continue
            result[key] = {
                "value": value,
                "source": source,
                "created_at": created_at,
                "updated_at": updated_at,
            }
        return result

    def delete_fact(self, key):
        with self._connection() as connection:
            cursor = connection.execute(
                "DELETE FROM persistent_facts WHERE key = ?",
                (str(key),),
            )
            return cursor.rowcount > 0

    def clear(self):
        with self._connection() as connection:
            connection.execute("DELETE FROM persistent_facts")

    def close(self):
        """Compatibility lifecycle hook.

        The store intentionally keeps no long-lived connection, so there is
        nothing to close here. The method exists for callers that prefer an
        explicit resource-lifecycle API.
        """

        return None
