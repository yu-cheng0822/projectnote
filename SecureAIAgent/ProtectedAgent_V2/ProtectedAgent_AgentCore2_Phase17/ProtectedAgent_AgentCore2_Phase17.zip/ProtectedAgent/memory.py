from dataclasses import dataclass, field
from typing import Any

from memory_policy import MemoryPolicy


@dataclass
class ConversationTurn:
    user: str
    assistant: str

    def to_dict(self):
        return {
            "user": self.user,
            "assistant": self.assistant,
        }


@dataclass
class EntityMemory:
    """Small working-memory record for the currently referenced person."""

    name: str | None = None
    user_id: str | None = None
    username: str | None = None
    account_id: str | None = None
    facts: dict[str, Any] = field(default_factory=dict)

    def update(self, values):
        if not isinstance(values, dict):
            return

        for key in ("name", "user_id", "username", "account_id"):
            value = values.get(key)
            if value is not None and str(value).strip():
                setattr(self, key, str(value).strip())

        self.facts.update(values)

    def to_dict(self):
        return {
            "name": self.name,
            "user_id": self.user_id,
            "username": self.username,
            "account_id": self.account_id,
            "facts": dict(self.facts),
        }


@dataclass
class WorkingMemory:
    """Generic session-scoped context used by any ProtectedAgent tool.

    Phase 11 deliberately keeps this memory in RAM. It stores compact,
    inspectable evidence and facts rather than hidden model state, so future
    tools can participate without adding tool-specific memory code.
    """

    current_goal: str | None = None
    status: str = "IDLE"
    facts: dict[str, Any] = field(default_factory=dict)
    variables: dict[str, Any] = field(default_factory=dict)
    evidence: list[dict[str, Any]] = field(default_factory=list)
    pending_requirements: list[str] = field(default_factory=list)
    goal_history: list[dict[str, Any]] = field(default_factory=list)
    persistent_facts: dict[str, Any] = field(default_factory=dict)
    max_evidence: int = 16
    max_goal_history: int = 8

    def reset(self):
        self.current_goal = None
        self.status = "IDLE"
        self.facts.clear()
        self.variables.clear()
        self.evidence.clear()
        self.pending_requirements.clear()
        self.goal_history.clear()

    def begin_goal(self, goal, task_plan=None):
        self.current_goal = str(goal).strip()
        self.status = "ACTIVE"
        self.pending_requirements = []
        self.variables["current_goal"] = self.current_goal
        if task_plan is not None:
            self.variables["plan_source"] = getattr(task_plan, "source", None)
            self.variables["plan_step_count"] = len(getattr(task_plan, "steps", []))
        else:
            self.variables.pop("plan_source", None)
            self.variables.pop("plan_step_count", None)

    def set_pending_requirements(self, items):
        normalized = []
        for item in items or []:
            text = str(item).strip()
            if text and text not in normalized:
                normalized.append(text)
        self.pending_requirements = normalized
        self.variables["pending_requirement_count"] = len(normalized)

    def set_variable(self, key, value):
        name = str(key).strip()
        if name:
            self.variables[name] = value

    def remember_fact(self, key, value):
        name = str(key).strip()
        if not name:
            return
        if isinstance(value, (str, int, float, bool)) or value is None:
            self.facts[name] = value

    def _remember_mapping(self, namespace, mapping):
        if not isinstance(mapping, dict):
            return
        for key, value in mapping.items():
            self.remember_fact(f"{namespace}.{key}", value)

    def observe_tool_result(
        self,
        tool,
        tool_input,
        success,
        result,
        *,
        step_id=None,
        include_in_answer=True,
    ):
        tool_name = str(tool).strip().lower() or "unknown"
        record = {
            "tool": tool_name,
            "input": tool_input,
            "success": bool(success),
            "result": result,
            "step_id": step_id,
            "include_in_answer": bool(include_in_answer),
        }
        self.evidence.append(record)
        if len(self.evidence) > self.max_evidence:
            self.evidence = self.evidence[-self.max_evidence :]

        self.variables["last_tool"] = tool_name
        self.variables["last_tool_success"] = bool(success)
        self.variables["last_tool_result"] = result
        if step_id is not None:
            self.variables[f"step_{step_id}_result"] = result

        if not success:
            return

        namespace = tool_name
        if tool_name == "database" and isinstance(tool_input, str):
            dataset = tool_input.split("|", 1)[0].strip().lower()
            if dataset:
                namespace = dataset

        if isinstance(result, dict):
            self._remember_mapping(namespace, result)
        elif (
            isinstance(result, list)
            and len(result) == 1
            and isinstance(result[0], dict)
        ):
            self._remember_mapping(namespace, result[0])
        elif isinstance(result, (str, int, float, bool)) or result is None:
            self.remember_fact(f"{namespace}.last_result", result)

    def complete_goal(self, answer=""):
        final_status = "COMPLETE" if not self.pending_requirements else "PARTIAL"
        self.status = final_status
        if self.current_goal:
            self.goal_history.append({
                "goal": self.current_goal,
                "status": final_status,
                "pending_requirements": list(self.pending_requirements),
                "answer": str(answer),
            })
            if len(self.goal_history) > self.max_goal_history:
                self.goal_history = self.goal_history[-self.max_goal_history :]
        self.variables["last_goal_status"] = final_status

    def to_dict(self):
        return {
            "current_goal": self.current_goal,
            "status": self.status,
            "facts": dict(self.facts),
            "variables": dict(self.variables),
            "evidence": [dict(item) for item in self.evidence],
            "pending_requirements": list(self.pending_requirements),
            "goal_history": [dict(item) for item in self.goal_history],
            "persistent_facts": dict(self.persistent_facts),
        }

    def to_prompt_context(self):
        if not (
            self.current_goal
            or self.facts
            or self.variables
            or self.evidence
            or self.pending_requirements
            or self.persistent_facts
        ):
            return "(empty)"

        lines = ["WORKING MEMORY:"]
        if self.persistent_facts:
            lines.append("- persistent_facts:")
            for key, value in list(self.persistent_facts.items())[-24:]:
                lines.append(f"  - {key}: {value}")
        if self.current_goal:
            lines.append(f"- current_goal: {self.current_goal}")
        lines.append(f"- status: {self.status}")

        if self.pending_requirements:
            lines.append("- pending_requirements:")
            for item in self.pending_requirements:
                lines.append(f"  - {item}")

        if self.facts:
            lines.append("- known_facts:")
            for key, value in list(self.facts.items())[-24:]:
                lines.append(f"  - {key}: {value}")

        useful_variables = {
            key: value
            for key, value in self.variables.items()
            if key not in {"last_tool_result", "current_goal"}
        }
        if useful_variables:
            lines.append("- variables:")
            for key, value in list(useful_variables.items())[-16:]:
                lines.append(f"  - {key}: {value}")

        if self.evidence:
            lines.append("- recent_evidence:")
            for item in self.evidence[-6:]:
                lines.append(
                    "  - "
                    f"tool={item.get('tool')} "
                    f"success={item.get('success')} "
                    f"input={item.get('input')} "
                    f"result={item.get('result')}"
                )

        return "\n".join(lines)


class ConversationMemory:
    """Session-scoped memory for ProtectedAgent.

    EntityMemory keeps conversational identity links. WorkingMemory is the
    Phase 11 generic context store for goals, facts, variables and tool evidence.
    Everything is RAM-only and is cleared when the Agent is recreated/reset.
    """

    REFERENCE_WORDS = (
        "她",
        "他",
        "她的",
        "他的",
        "這個人",
        "這位",
        "那個人",
        "那位",
        "this person",
        "that person",
        "their",
        "her",
        "his",
    )

    def __init__(
        self,
        max_turns=8,
        *,
        persistent_store=None,
        memory_policy=None,
    ):
        self.max_turns = max(1, int(max_turns))
        self.turns: list[ConversationTurn] = []
        self.active_entity = EntityMemory()
        self.dataset_facts: dict[str, list[dict[str, Any]]] = {}
        self.working = WorkingMemory()
        self.persistent_store = persistent_store
        self.memory_policy = memory_policy or MemoryPolicy()
        self.reload_persistent_memory()

    def reset(self):
        """Clear session-scoped memory while keeping persistent facts."""

        persistent = dict(self.working.persistent_facts)
        self.turns.clear()
        self.active_entity = EntityMemory()
        self.dataset_facts.clear()
        self.working.reset()
        self.working.persistent_facts = persistent

    def reload_persistent_memory(self):
        self.working.persistent_facts = {}
        if self.persistent_store is None:
            return {}

        records = self.persistent_store.get_all()
        self.working.persistent_facts = {
            key: item.get("value")
            for key, item in records.items()
        }
        return dict(self.working.persistent_facts)

    def remember_persistent_fact(
        self,
        key,
        value,
        *,
        source="user",
        explicit=False,
    ):
        decision = self.memory_policy.classify(
            key,
            value,
            explicit=explicit,
            source=source,
        )

        if not decision.allowed:
            return {
                "success": False,
                "key": str(key).strip(),
                "decision": decision.to_dict(),
            }

        if self.persistent_store is None:
            return {
                "success": False,
                "key": str(key).strip(),
                "decision": {
                    "scope": "persistent",
                    "allowed": False,
                    "reason": "persistent_store_disabled",
                },
            }

        normalized_key = str(key).strip()
        self.persistent_store.set_fact(
            normalized_key,
            value,
            source=source,
        )
        self.reload_persistent_memory()
        return {
            "success": True,
            "key": normalized_key,
            "value": value,
            "decision": decision.to_dict(),
        }

    def forget_persistent_fact(self, key):
        if self.persistent_store is None:
            return False
        deleted = self.persistent_store.delete_fact(str(key).strip())
        self.reload_persistent_memory()
        return deleted

    def clear_persistent_memory(self):
        if self.persistent_store is None:
            self.working.persistent_facts = {}
            return False
        self.persistent_store.clear()
        self.reload_persistent_memory()
        return True

    def begin_goal(self, goal, task_plan=None):
        self.working.begin_goal(goal, task_plan=task_plan)

    def complete_goal(self, answer=""):
        self.working.complete_goal(answer)

    def set_pending_requirements(self, items):
        self.working.set_pending_requirements(items)

    def observe_tool_result(
        self,
        tool,
        tool_input,
        success,
        result,
        *,
        step_id=None,
        include_in_answer=True,
    ):
        self.working.observe_tool_result(
            tool,
            tool_input,
            success,
            result,
            step_id=step_id,
            include_in_answer=include_in_answer,
        )

    def add_turn(self, user, assistant):
        self.turns.append(
            ConversationTurn(
                user=str(user),
                assistant=str(assistant),
            )
        )

        if len(self.turns) > self.max_turns:
            self.turns = self.turns[-self.max_turns :]

    def refers_to_active_entity(self, text):
        lowered = str(text).lower()
        return any(word.lower() in lowered for word in self.REFERENCE_WORDS)

    def get_active_name(self):
        return self.active_entity.name

    def get_active_user_id(self):
        return self.active_entity.user_id

    def get_active_username(self):
        return self.active_entity.username

    def observe_database_result(self, query, result):
        """Learn deterministic identifiers from successful database evidence."""

        if not isinstance(result, list) or not result:
            return

        parts = [part.strip() for part in str(query).split("|")]
        dataset = parts[0].lower() if parts else ""
        filters = {}

        for part in parts[1:]:
            if "=" not in part:
                continue
            key, value = part.split("=", 1)
            filters[key.strip().lower()] = value.strip()

        records = [item for item in result if isinstance(item, dict)]
        if not records:
            return

        self.dataset_facts[dataset] = [dict(item) for item in records]

        # Only change the active referent for an unambiguous result. A query
        # returning every user/account should not silently make its first row
        # the person referenced by "她/他" in a later turn.
        if len(records) != 1:
            return

        record = records[0]

        if dataset == "users":
            self.active_entity.update(record)
            if self.active_entity.name and not self.active_entity.username:
                self.active_entity.username = self.active_entity.name.lower()
            return

        if dataset == "accounts":
            username = record.get("username") or filters.get("username")

            active_name = self.active_entity.name
            if active_name and username:
                if str(username).lower() == str(active_name).lower():
                    self.active_entity.update(record)
                    return

            self.active_entity.update(record)
            if username and not self.active_entity.name:
                self.active_entity.name = str(username).capitalize()
            return

        if dataset == "sensitive_data":
            record_user_id = record.get("user_id") or filters.get("user_id")
            active_user_id = self.active_entity.user_id

            if active_user_id and record_user_id:
                if str(active_user_id).lower() == str(record_user_id).lower():
                    self.active_entity.update(record)
                    return

            self.active_entity.update(record)

    def to_dict(self):
        return {
            "turns": [turn.to_dict() for turn in self.turns],
            "active_entity": self.active_entity.to_dict(),
            "dataset_facts": {
                key: [dict(item) for item in value]
                for key, value in self.dataset_facts.items()
            },
            "working_memory": self.working.to_dict(),
        }

    def to_prompt_context(self):
        lines = []

        if any(
            value
            for value in (
                self.active_entity.name,
                self.active_entity.user_id,
                self.active_entity.username,
                self.active_entity.account_id,
            )
        ):
            lines.append("ACTIVE ENTITY:")
            if self.active_entity.name:
                lines.append(f"- name: {self.active_entity.name}")
            if self.active_entity.user_id:
                lines.append(f"- user_id: {self.active_entity.user_id}")
            if self.active_entity.username:
                lines.append(f"- username: {self.active_entity.username}")
            if self.active_entity.account_id:
                lines.append(f"- account_id: {self.active_entity.account_id}")

        working_context = self.working.to_prompt_context()
        if working_context != "(empty)":
            lines.append(working_context)

        if self.turns:
            lines.append("RECENT CONVERSATION:")
            for turn in self.turns:
                lines.append(f"User: {turn.user}")
                lines.append(f"Assistant: {turn.assistant}")

        if not lines:
            return "(empty)"

        return "\n".join(lines)
