from dataclasses import dataclass, field
import json


@dataclass(frozen=True)
class RuntimeLimits:
    """Hard execution limits for one ProtectedAgent run.

    These limits are operational safeguards only. They are intentionally
    independent from SecurityArchitecture permissions/trust/policy decisions.
    """

    max_tool_calls: int = 20
    max_plan_steps: int = 12
    max_action_repeats: int = 3
    max_llm_errors: int = 3
    max_error_chars: int = 500
    llm_timeout_seconds: float = 30.0


@dataclass
class RuntimeGuard:
    limits: RuntimeLimits
    action_counts: dict[str, int] = field(default_factory=dict)
    llm_errors: int = 0
    stop_reason: str | None = None

    def action_signature(self, tool, arguments):
        try:
            payload = json.dumps(arguments or {}, ensure_ascii=False, sort_keys=True)
        except TypeError:
            payload = repr(arguments)
        return f"{str(tool or '').strip().lower()}::{payload}"

    def register_action(self, tool, arguments):
        signature = self.action_signature(tool, arguments)
        count = self.action_counts.get(signature, 0) + 1
        self.action_counts[signature] = count
        if count > self.limits.max_action_repeats:
            self.stop_reason = "repeated_action_limit"
            return False, count
        return True, count

    def record_llm_error(self):
        self.llm_errors += 1
        if self.llm_errors >= self.limits.max_llm_errors:
            self.stop_reason = "llm_error_limit"
        return self.llm_errors

    def trim_error(self, value):
        text = str(value or "unknown_error")
        if len(text) <= self.limits.max_error_chars:
            return text
        return text[: self.limits.max_error_chars] + "..."

    def snapshot(self):
        return {
            "action_counts": dict(self.action_counts),
            "llm_errors": self.llm_errors,
            "stop_reason": self.stop_reason,
            "limits": {
                "max_tool_calls": self.limits.max_tool_calls,
                "max_plan_steps": self.limits.max_plan_steps,
                "max_action_repeats": self.limits.max_action_repeats,
                "max_llm_errors": self.limits.max_llm_errors,
                "max_error_chars": self.limits.max_error_chars,
                "llm_timeout_seconds": self.limits.llm_timeout_seconds,
            },
        }
