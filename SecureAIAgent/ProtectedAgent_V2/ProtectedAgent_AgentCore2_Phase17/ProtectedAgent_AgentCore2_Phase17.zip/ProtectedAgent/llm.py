import requests


class LocalLLM:

    def __init__(self, timeout_seconds=30.0):
        self.url = "http://localhost:11434/api/generate"
        self.model = "qwen2.5:1.5b"
        self.timeout_seconds = float(timeout_seconds)

    def generate(self, prompt):
        try:
            response = requests.post(
                self.url,
                json={
                    "model": self.model,
                    "prompt": prompt,
                    "stream": False,
                },
                timeout=self.timeout_seconds,
            )
            response.raise_for_status()
        except requests.Timeout as exc:
            raise RuntimeError("llm_timeout") from exc
        except requests.RequestException as exc:
            raise RuntimeError(f"llm_request_error:{exc}") from exc

        try:
            data = response.json()
        except ValueError as exc:
            raise RuntimeError("llm_invalid_response_json") from exc

        generated = data.get("response")
        if generated is None:
            raise RuntimeError("llm_missing_response")
        return str(generated)
