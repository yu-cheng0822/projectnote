from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class MemoryDecision:
    scope: str
    allowed: bool
    reason: str

    def to_dict(self):
        return {
            "scope": self.scope,
            "allowed": self.allowed,
            "reason": self.reason,
        }


class MemoryPolicy:
    """Conservative policy for ProtectedAgent persistent memory.

    Session memory remains permissive because it disappears with the Agent
    process. Persistent memory is opt-in: a fact must be explicitly requested
    for storage and must not look sensitive.
    """

    SENSITIVE_TERMS = {
        "password",
        "passwd",
        "secret",
        "token",
        "api_key",
        "apikey",
        "access_key",
        "private_key",
        "credential",
        "credit_card",
        "card_number",
        "bank_account",
        "ssn",
        "phone",
        "email",
        "address",
        "user_id",
        "account_id",
        "sensitive_data",
    }

    def __init__(self, max_text_length=512):
        self.max_text_length = max(32, int(max_text_length))

    def _normalized_key(self, key):
        return str(key or "").strip().lower().replace("-", "_")

    def _is_sensitive_key(self, key):
        normalized = self._normalized_key(key)
        if not normalized:
            return False
        parts = {
            part
            for part in normalized.replace(".", "_").split("_")
            if part
        }
        return any(
            term == normalized
            or term in normalized
            or term in parts
            for term in self.SENSITIVE_TERMS
        )

    def classify(self, key, value: Any, *, explicit=False, source="unknown"):
        name = self._normalized_key(key)
        if not name:
            return MemoryDecision("blocked", False, "empty_key")

        if self._is_sensitive_key(name):
            return MemoryDecision("blocked", False, "sensitive_key")

        if not isinstance(value, (str, int, float, bool)) and value is not None:
            return MemoryDecision("session", False, "non_scalar_value")

        if isinstance(value, str) and len(value) > self.max_text_length:
            return MemoryDecision("session", False, "value_too_long")

        if not explicit:
            return MemoryDecision("session", False, "explicit_opt_in_required")

        return MemoryDecision("persistent", True, "explicit_safe_fact")
