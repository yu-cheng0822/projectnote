from dataclasses import dataclass, field
from typing import Any, Callable

from tools import (
    CalculatorTool,
    DatabaseTool,
    FilePlaceholderTool,
    RecoveryPlaceholderTool,
)


def _legacy_type_schema(type_name):
    normalized = str(type_name).strip().lower()
    mapping = {
        "str": "string",
        "string": "string",
        "int": "integer",
        "integer": "integer",
        "float": "number",
        "number": "number",
        "bool": "boolean",
        "boolean": "boolean",
        "object": "object",
        "dict": "object",
        "array": "array",
        "list": "array",
    }
    return {"type": mapping.get(normalized, "string")}


def normalize_tool_schema(schema):
    """Normalize Phase 4-style schemas into a JSON-Schema-like shape.

    Older phases registered custom tools with shorthand metadata such as
    ``{"text": "string"}``. Phase 14 keeps those registrations working while
    exposing a consistent public schema to planners and external adapters.
    """

    if schema is None:
        return None
    if not isinstance(schema, dict):
        return None
    if not schema:
        return {
            "type": "object",
            "properties": {},
            "required": [],
            "additionalProperties": True,
        }
    if "type" in schema or "anyOf" in schema:
        return dict(schema)

    properties = {}
    for key, value in schema.items():
        if isinstance(value, dict):
            properties[str(key)] = dict(value)
        else:
            properties[str(key)] = _legacy_type_schema(value)

    return {
        "type": "object",
        "properties": properties,
        # Legacy schemas were descriptive, not strict. Do not suddenly make
        # every old field required during migration.
        "required": [],
        "additionalProperties": True,
    }


@dataclass
class ToolDefinition:
    """Standard metadata + callable handler for one Agent tool."""

    name: str
    description: str
    input_schema: dict[str, Any]
    handler: Callable[[Any], Any]
    output_schema: dict[str, Any] | None = None
    capabilities: list[str] = field(default_factory=list)
    side_effects: list[str] = field(default_factory=list)
    error_results: set[str] = field(default_factory=set)
    exposed_to_agent: bool = True
    strict_input_validation: bool = False
    strict_output_validation: bool = False
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self):
        self.input_schema = normalize_tool_schema(self.input_schema) or {
            "type": "object",
            "properties": {},
            "required": [],
            "additionalProperties": True,
        }
        self.output_schema = normalize_tool_schema(self.output_schema)
        self.capabilities = [
            str(value).strip().lower()
            for value in self.capabilities
            if str(value).strip()
        ]
        self.side_effects = [
            str(value).strip().lower()
            for value in self.side_effects
            if str(value).strip()
        ]
        self.metadata = dict(self.metadata or {})

    @property
    def read_only(self):
        return not bool(self.side_effects)

    def public_metadata(self):
        return {
            "name": self.name,
            "description": self.description,
            "capabilities": list(self.capabilities),
            "side_effects": list(self.side_effects),
            "read_only": self.read_only,
            "input_schema": self.input_schema,
            "output_schema": self.output_schema,
            "metadata": dict(self.metadata),
        }


class ToolRegistry:
    """Runtime registry of tools available to ProtectedAgent."""

    def __init__(self):
        self._tools: dict[str, ToolDefinition] = {}

    def register(self, definition, replace=False):
        if not isinstance(definition, ToolDefinition):
            raise TypeError("definition must be ToolDefinition")

        name = str(definition.name).strip().lower()
        if not name:
            raise ValueError("tool name cannot be empty")

        if name in self._tools and not replace:
            raise ValueError(f"tool already registered: {name}")

        definition.name = name
        self._tools[name] = definition
        return definition

    def unregister(self, name):
        return self._tools.pop(str(name).strip().lower(), None)

    def get(self, name):
        return self._tools.get(str(name).strip().lower())

    def has(self, name, exposed_only=False):
        definition = self.get(name)
        if definition is None:
            return False
        if exposed_only and not definition.exposed_to_agent:
            return False
        return True

    def names(self, exposed_only=False):
        return [
            name
            for name, definition in self._tools.items()
            if not exposed_only or definition.exposed_to_agent
        ]

    def find_by_capability(self, capability, exposed_only=True):
        target = str(capability).strip().lower()
        if not target:
            return []
        return [
            definition
            for definition in self._tools.values()
            if target in definition.capabilities
            and (not exposed_only or definition.exposed_to_agent)
        ]

    def public_catalog(self):
        return [
            definition.public_metadata()
            for definition in self._tools.values()
            if definition.exposed_to_agent
        ]

    def search_relevant(self, query, exposed_only=True, limit=6):
        """Rank tools using only generic registry metadata.

        No Agent-specific tool names are encoded here. Tool authors can add
        ``planner_keywords`` / ``aliases`` / ``intent_keywords`` in metadata
        so semantic requests can discover a tool without naming its Python
        registration name.
        """

        text = str(query or "").strip().lower()
        if not text:
            return []

        ranked = []
        for definition in self._tools.values():
            if exposed_only and not definition.exposed_to_agent:
                continue

            score = self._relevance_score(definition, text)
            if score <= 0:
                continue
            ranked.append((score, definition))

        ranked.sort(key=lambda item: (-item[0], item[1].name))
        return [definition for _, definition in ranked[: max(1, int(limit))]]

    def _relevance_score(self, definition, query_text):
        score = 0
        name = str(definition.name).strip().lower()
        if name and name in query_text:
            score += 100

        metadata = dict(definition.metadata or {})
        keyword_values = []
        for key in ("planner_keywords", "intent_keywords", "aliases"):
            value = metadata.get(key, [])
            if isinstance(value, str):
                value = [value]
            if isinstance(value, (list, tuple, set)):
                keyword_values.extend(value)

        for raw_keyword in keyword_values:
            keyword = str(raw_keyword).strip().lower()
            if keyword and keyword in query_text:
                score += 40 + min(len(keyword), 20)

        for capability in definition.capabilities:
            capability = str(capability).strip().lower()
            fragments = [part for part in capability.replace("_", ".").split(".") if len(part) >= 3]
            for fragment in fragments:
                if fragment in query_text:
                    score += 18

        description = str(definition.description or "").strip().lower()
        query_tokens = set(self._search_tokens(query_text))
        description_tokens = set(self._search_tokens(description))
        overlap = query_tokens & description_tokens
        score += min(len(overlap) * 8, 32)
        return score

    @staticmethod
    def _search_tokens(text):
        import re
        return [
            token
            for token in re.findall(r"[a-z0-9_]+|[\u4e00-\u9fff]{2,}", str(text).lower())
            if len(token) >= 2
        ]

    def to_prompt_text(self, names=None):
        lines = []
        selected = None if names is None else {str(name).strip().lower() for name in names}
        for definition in self._tools.values():
            if not definition.exposed_to_agent:
                continue
            if selected is not None and definition.name not in selected:
                continue
            lines.append(f"- {definition.name}: {definition.description}")
            lines.append(
                f"  capabilities: {definition.capabilities or ['unspecified']}"
            )
            lines.append(
                f"  side_effects: {definition.side_effects or ['none']}"
            )
            lines.append(f"  read_only: {definition.read_only}")
            planning_keywords = definition.metadata.get("planner_keywords") or definition.metadata.get("intent_keywords")
            if planning_keywords:
                lines.append(f"  planner_keywords: {planning_keywords}")
            lines.append(f"  input_schema: {definition.input_schema}")
            if definition.output_schema is not None:
                lines.append(f"  output_schema: {definition.output_schema}")

        return "\n".join(lines) if lines else "(no tools registered)"


def build_default_tool_registry():
    registry = ToolRegistry()

    calculator = CalculatorTool()
    database = DatabaseTool()

    registry.register(
        ToolDefinition(
            name="calculator",
            description="Perform basic arithmetic using an expression.",
            input_schema={
                "type": "object",
                "properties": {
                    "expression": {
                        "type": "string",
                        "minLength": 1,
                        "description": "Arithmetic expression such as 123 * 456.",
                    },
                },
                "required": ["expression"],
                "additionalProperties": False,
            },
            output_schema={
                "type": "number",
                "description": "Calculated numeric result.",
            },
            capabilities=["arithmetic.compute"],
            side_effects=[],
            handler=calculator,
            error_results={"invalid_expression", "calculation_error"},
            exposed_to_agent=True,
            strict_input_validation=True,
            strict_output_validation=True,
            metadata={
                "category": "compute",
                "planner_keywords": ["計算", "算出", "多少", "calculate", "compute", "arithmetic"],
            },
        )
    )

    registry.register(
        ToolDefinition(
            name="database",
            description=(
                "Query the local demo database. Available datasets are users, "
                "accounts, and sensitive_data."
            ),
            input_schema={
                "type": "object",
                "properties": {
                    "dataset": {
                        "type": "string",
                        "enum": ["users", "accounts", "sensitive_data"],
                    },
                    "filters": {
                        "type": "object",
                        "properties": {
                            "user_id": {"type": "string"},
                            "name": {"type": "string"},
                            "account_id": {"type": "string"},
                            "username": {"type": "string"},
                        },
                        "required": [],
                        "additionalProperties": False,
                    },
                },
                "required": ["dataset", "filters"],
                "additionalProperties": False,
            },
            output_schema={
                "type": "array",
                "items": {"type": "object"},
                "description": "Matching database records.",
            },
            capabilities=["data.read", "demo_database.query"],
            side_effects=[],
            handler=database,
            error_results={"missing_database_query", "unknown_database_query"},
            exposed_to_agent=True,
            strict_input_validation=True,
            strict_output_validation=True,
            metadata={
                "category": "data",
                "datasets": ["users", "accounts", "sensitive_data"],
                "planner_keywords": [
                    "資料", "帳號", "個人資料", "地址", "database",
                    "users", "accounts", "sensitive_data",
                ],
            },
        )
    )

    # These two names existed in the historical ToolExecutor. They stay
    # executable for compatibility, but the Agent planner cannot choose them.
    registry.register(
        ToolDefinition(
            name="recovery",
            description="Legacy recovery placeholder.",
            input_schema={},
            output_schema=None,
            capabilities=["legacy.recovery"],
            side_effects=["agent_state_change"],
            handler=RecoveryPlaceholderTool(),
            exposed_to_agent=False,
        )
    )

    registry.register(
        ToolDefinition(
            name="file",
            description="Legacy file placeholder.",
            input_schema={},
            output_schema=None,
            capabilities=["legacy.file"],
            side_effects=[],
            handler=FilePlaceholderTool(),
            exposed_to_agent=False,
        )
    )

    return registry
