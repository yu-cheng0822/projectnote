import json
import re

from llm import LocalLLM
from tool_manager import ToolManager
from models import AgentAction, AgentState, PlanStep, ToolResult
from planner import TaskPlanner
from memory import ConversationMemory
from memory_policy import MemoryPolicy
from persistent_memory import SQLitePersistentMemoryStore
from replanner import FailureRecoveryPlanner
from trace import ExecutionTrace
from goal_decomposer import GoalDecomposer
from goal_evaluator import GoalCompletionEvaluator
from context_manager import MemoryContextManager
from generic_planner import GenericPlanner
from robustness import RuntimeGuard, RuntimeLimits


class Agent:

    def __init__(
        self,
        agent_id="agent_001",
        llm=None,
        tool_manager=None,
        tool_executor=None,
        session_id="session_001",
        trace_observers=None,
        persistent_memory_path=None,
        persistent_store=None,
        memory_policy=None,
        runtime_limits=None,
    ):
        self.agent_id = agent_id
        self.session_id = session_id
        self.runtime_limits = runtime_limits or RuntimeLimits()
        self.llm = (
            llm
            if llm is not None
            else LocalLLM(timeout_seconds=self.runtime_limits.llm_timeout_seconds)
        )
        self.trace_observers = list(trace_observers or [])
        self.last_trace = None
        self.last_context_selection = None

        # ``tool_executor`` is kept as a temporary compatibility argument for
        # older Phase 1-3 callers. New code should inject ToolManager.
        if tool_manager is not None:
            self.tool_manager = tool_manager
        elif tool_executor is not None:
            self.tool_manager = tool_executor
        else:
            self.tool_manager = ToolManager()

        # Compatibility alias. Agent Core itself uses ``tool_manager`` below.
        self.tool_executor = self.tool_manager

        self.planner = TaskPlanner(
            valid_tools=self.tool_manager.available_tool_names(exposed_only=True)
        )

        if persistent_store is not None:
            resolved_persistent_store = persistent_store
        elif persistent_memory_path is not None:
            resolved_persistent_store = SQLitePersistentMemoryStore(
                persistent_memory_path
            )
        else:
            resolved_persistent_store = None

        self.memory = ConversationMemory(
            max_turns=8,
            persistent_store=resolved_persistent_store,
            memory_policy=memory_policy or MemoryPolicy(),
        )
        self.failure_recovery = FailureRecoveryPlanner(
            max_attempts_per_step=2,
            max_replans=3,
        )
        self.generic_planner = GenericPlanner(
            llm=self.llm,
            tool_manager=self.tool_manager,
        )
        self.goal_decomposer = GoalDecomposer(
            llm=self.llm,
            planner=self.planner,
            tool_manager=self.tool_manager,
        )
        self.goal_evaluator = GoalCompletionEvaluator(
            llm=self.llm,
            planner=self.planner,
            tool_manager=self.tool_manager,
            max_goal_replans=2,
        )
        self.context_manager = MemoryContextManager(
            max_chars=3600,
            max_facts=8,
            max_persistent=6,
            max_evidence=4,
            max_turns=4,
        )

    # ==================================================
    # Execution Trace / Observation Hooks
    # ==================================================

    def add_trace_observer(self, callback):
        """Register a generic observer for future Agent trace events.

        The observer receives one normalized event dictionary at a time.
        ProtectedAgent does not know what the observer does; this keeps the
        hook independent from any future security or monitoring plugin.
        """

        if callable(callback):
            self.trace_observers.append(callback)

    def get_last_trace(self):
        return self.last_trace

    def record_trace(self, state, event_type, *, step=None, data=None):
        trace = getattr(state, "execution_trace", None)
        if trace is None:
            return None
        return trace.record(event_type, step=step, data=data or {})

    def print_execution_trace(self, state):
        trace = getattr(state, "execution_trace", None)
        if trace is None:
            return

        print("\n===== Execution Trace =====")
        for line in trace.compact_lines():
            print(line)

    # ==================================================
    # Dataset Planning Helpers
    # ==================================================

    def get_required_datasets(self, user_input):
        return self.planner.get_required_datasets(user_input)

    def get_completed_datasets(self, tool_history):
        return self.planner.get_completed_datasets(tool_history)

    def get_database_records(self, tool_history, dataset, answer_only=False):
        records = []

        for record in tool_history:
            if record.get("tool") != "database":
                continue
            if not record.get("success"):
                continue
            if answer_only and record.get("include_in_answer") is False:
                continue

            query = record.get("input", "")
            current_dataset = query.split("|", 1)[0].strip().lower()

            if current_dataset == dataset:
                result = record.get("result")
                if isinstance(result, list):
                    records.extend(result)

        return records

    def has_successful_query(self, tool_history, query):
        normalized = str(query).strip().lower()

        for record in tool_history:
            if not record.get("success"):
                continue

            old_query = str(record.get("input", "")).strip().lower()
            if old_query == normalized:
                return True

        return False

    # ==================================================
    # Entity / Query Helpers
    # ==================================================

    def extract_person_name(self, user_input):
        known_names = ["alice", "bob", "charlie"]
        text = str(user_input).strip()
        lower_text = text.lower()

        for name in known_names:
            if re.search(rf"\b{re.escape(name)}\b", lower_text):
                return name.capitalize()

        # Support an unseen Latin-script person name so a request such as
        # "請查 David 的個人資料" becomes a filtered query instead of an
        # unsafe broad query over every user.
        stop_words = {
            "user", "users", "account", "accounts", "database",
            "please", "find", "show", "get", "information", "profile",
        }
        for candidate in re.findall(r"\b[A-Z][A-Za-z'-]{1,40}\b", text):
            if candidate.lower() not in stop_words:
                return candidate

        if self.memory.refers_to_active_entity(user_input):
            return self.memory.get_active_name()

        return None

    def extract_user_id(self, user_input):
        match = re.search(r"\bU\d{3}\b", user_input, re.IGNORECASE)
        if match:
            return match.group(0).upper()

        if self.memory.refers_to_active_entity(user_input):
            return self.memory.get_active_user_id()

        return None

    def extract_account_id(self, user_input):
        match = re.search(r"\bA\d{3}\b", str(user_input), re.IGNORECASE)
        if match:
            return match.group(0).upper()

        if self.memory.refers_to_active_entity(user_input):
            return self.memory.active_entity.account_id

        return None

    def extract_username(self, user_input):
        person_name = self.extract_person_name(user_input)
        if person_name:
            return person_name.lower()

        if self.memory.refers_to_active_entity(user_input):
            return self.memory.get_active_username()

        return None

    def build_database_query(self, dataset, user_input, tool_history):
        if dataset == "accounts":
            account_id = self.extract_account_id(user_input)
            if account_id:
                return "accounts | account_id=" + account_id

            users = self.get_database_records(tool_history, "users")
            if users:
                name = users[0].get("name")
                if name:
                    return "accounts | username=" + str(name).lower()

            username = self.extract_username(user_input)
            if username:
                return "accounts | username=" + username

            return "accounts"

        if dataset == "users":
            accounts = self.get_database_records(tool_history, "accounts")
            if accounts:
                username = accounts[0].get("username")
                if username:
                    return "users | name=" + str(username).capitalize()

            user_id = self.extract_user_id(user_input)
            if user_id:
                return "users | user_id=" + user_id

            name = self.extract_person_name(user_input)
            if name:
                return "users | name=" + name

            return "users"

        if dataset == "sensitive_data":
            users = self.get_database_records(tool_history, "users")
            if users:
                user_id = users[0].get("user_id")
                if user_id:
                    return "sensitive_data | user_id=" + str(user_id)

            user_id = self.extract_user_id(user_input)
            if user_id:
                return "sensitive_data | user_id=" + user_id

            return "sensitive_data"

        return dataset

    def build_database_action(self, dataset, user_input, tool_history):
        query = self.build_database_query(dataset, user_input, tool_history)
        return self.planner.database_query_to_action(query)

    def request_targets_specific_entity(self, user_input):
        return bool(
            self.extract_person_name(user_input)
            or self.extract_user_id(user_input)
            or self.extract_account_id(user_input)
            or self.memory.refers_to_active_entity(user_input)
        )

    def build_prerequisite_steps(self, dataset, user_input, tool_history):
        """Build deterministic supporting steps for an unresolved identifier."""

        completed = set(self.get_completed_datasets(tool_history))
        prerequisites = []

        def add(dataset_name, description):
            if dataset_name in completed:
                return
            if any(
                step.get("arguments", {}).get("dataset") == dataset_name
                for step in prerequisites
            ):
                return
            prerequisites.append({
                "description": description,
                "tool": "database",
                "arguments": {"dataset": dataset_name, "filters": {}},
                "include_in_answer": False,
                "origin": "replan_prerequisite",
            })

        explicit_user_id = self.extract_user_id(user_input)
        explicit_account_id = self.extract_account_id(user_input)
        person_name = self.extract_person_name(user_input)

        if dataset == "accounts":
            # accounts supports account_id/username, but not user_id. Resolve a
            # user_id through users first so username can be derived safely.
            if explicit_user_id and not person_name:
                add("users", "由 user_id 取得使用者資料，以推導帳號 username")

        elif dataset == "users":
            # users supports user_id/name, but not account_id. Resolve account
            # evidence first, then derive the user's name from username.
            if explicit_account_id:
                add("accounts", "由 account_id 取得帳號資料，以推導使用者姓名")

        elif dataset == "sensitive_data":
            # sensitive_data requires user_id. A name needs users; an
            # account_id needs accounts first and then users.
            if explicit_account_id:
                add("accounts", "由 account_id 取得帳號資料")
                add("users", "由帳號資料取得 user_id")
            elif person_name and not explicit_user_id:
                add("users", "由姓名取得 user_id，以查詢敏感資料")

        return prerequisites

    def _memory_matches_request_entity(self, user_input):
        active = self.memory.active_entity
        explicit_name = self.extract_person_name(user_input)
        explicit_user_id = re.search(r"\bU\d{3}\b", str(user_input), re.IGNORECASE)
        explicit_account_id = re.search(r"\bA\d{3}\b", str(user_input), re.IGNORECASE)

        if explicit_name and active.name:
            if explicit_name.lower() != str(active.name).lower():
                return False

        if explicit_user_id and active.user_id:
            if explicit_user_id.group(0).lower() != str(active.user_id).lower():
                return False

        if explicit_account_id and active.account_id:
            if explicit_account_id.group(0).lower() != str(active.account_id).lower():
                return False

        return bool(
            self.memory.refers_to_active_entity(user_input)
            or explicit_name
            or explicit_user_id
            or explicit_account_id
        )

    def get_alternative_database_arguments(self, action, user_input):
        """Return a trustworthy alternate identifier for the same entity."""

        if action.tool != "database" or not self._memory_matches_request_entity(user_input):
            return None

        dataset = str(action.arguments.get("dataset", "")).strip().lower()
        filters = action.arguments.get("filters", {})
        if not isinstance(filters, dict):
            filters = {}

        active = self.memory.active_entity

        if dataset == "users":
            if "name" in filters and active.user_id:
                return {
                    "dataset": "users",
                    "filters": {"user_id": active.user_id},
                }
            if "user_id" in filters and active.name:
                return {
                    "dataset": "users",
                    "filters": {"name": active.name},
                }

        if dataset == "accounts":
            if "username" in filters and active.account_id:
                return {
                    "dataset": "accounts",
                    "filters": {"account_id": active.account_id},
                }
            if "account_id" in filters and active.username:
                return {
                    "dataset": "accounts",
                    "filters": {"username": active.username},
                }

        return None

    # ==================================================
    # Phase 13 Context Retrieval
    # ==================================================

    def retrieve_memory_context(self, user_input):
        selection = self.context_manager.retrieve(self.memory, user_input)
        self.last_context_selection = selection
        return selection

    # ==================================================
    # Structured Action Planning
    # ==================================================

    def decide(
        self,
        user_input,
        tool_history=None,
        missing_datasets=None,
        memory_context=None,
    ):
        if tool_history is None:
            tool_history = []
        if missing_datasets is None:
            missing_datasets = []
        if memory_context is None:
            memory_context = self.retrieve_memory_context(user_input).prompt

        history_text = json.dumps(
            tool_history,
            ensure_ascii=False,
            indent=2,
        )

        missing_text = json.dumps(missing_datasets, ensure_ascii=False)
        tool_catalog = self.tool_manager.prompt_catalog()

        # Tool registrations may change at runtime, so refresh the parser's
        # accepted names before every planning step.
        self.planner.set_valid_tools(
            self.tool_manager.available_tool_names(exposed_only=True)
        )

        prompt = f"""
You are the planning component of an autonomous AI assistant.
Choose exactly ONE next action.

Return ONLY one valid JSON object. Do not use Markdown. Do not add explanations.

JSON schema:

For calculator:
{{
  "action": "tool",
  "tool": "calculator",
  "arguments": {{
    "expression": "123 * 456"
  }}
}}

For database:
{{
  "action": "tool",
  "tool": "database",
  "arguments": {{
    "dataset": "users",
    "filters": {{
      "name": "Alice"
    }}
  }}
}}

For a final answer that needs no tool:
{{
  "action": "final",
  "tool": null,
  "arguments": {{}},
  "answer": "Traditional Chinese answer here"
}}

AVAILABLE TOOLS FROM TOOL REGISTRY:
{tool_catalog}

AVAILABLE DATABASE DATASETS:
- users: filters user_id, name
- accounts: filters account_id, username
- sensitive_data: filter user_id

RULES:
1. Use calculator only for real arithmetic.
2. Use database for requests that need database records.
3. Never invent database values.
4. Never use SQL.
5. Query only ONE dataset per action.
6. Do not repeat a successful database query.
7. If MISSING DATASETS is not empty, choose one of those datasets.
8. Do not return final while required data is still missing.
9. For ordinary conversation or knowledge questions that need no tool, return final and put the answer in the answer field.
10. The answer field must be Traditional Chinese when action is final.

USER REQUEST:
{user_input}

TOOL HISTORY:
{history_text}

MISSING DATASETS:
{missing_text}

SESSION MEMORY:
{memory_context}

MEMORY RULES:
- RELEVANT MEMORY CONTEXT is a bounded retrieval result, not the complete memory store.
- Use it only when it is relevant to the current USER REQUEST.
- A new explicit name or ID in USER REQUEST overrides the previous active entity.
- Do not invent facts that are not present in USER REQUEST, TOOL HISTORY, or RELEVANT MEMORY CONTEXT.
"""

        raw_output = self.llm.generate(prompt)
        return self.planner.parse_action(raw_output)

    def validate_action(
        self,
        action,
        user_input,
        missing_datasets,
        tool_history,
    ):
        """Controller-side validation of one structured LLM action."""

        if not isinstance(action, AgentAction):
            action = AgentAction(action="final")

        # Required database information has priority over an invalid/early action.
        if missing_datasets:
            if action.action != "tool" or action.tool != "database":
                return self.build_database_action(
                    missing_datasets[0],
                    user_input,
                    tool_history,
                )

            dataset = str(action.arguments.get("dataset", "")).strip().lower()
            if dataset not in missing_datasets:
                return self.build_database_action(
                    missing_datasets[0],
                    user_input,
                    tool_history,
                )

            # Prefer deterministic identifiers that are already supported by
            # the user request or previous tool results. This prevents the LLM
            # from silently changing Alice -> Bob, U001 -> U002, etc.
            expected_action = self.build_database_action(
                dataset,
                user_input,
                tool_history,
            )
            expected_query = self.planner.action_to_database_query(
                expected_action
            )
            model_query = self.planner.action_to_database_query(action)

            if expected_query != dataset:
                return expected_action

            if model_query == dataset:
                return expected_action

            return action

        if action.action == "tool":
            if not self.tool_manager.has_tool(action.tool, exposed_only=True):
                return AgentAction(action="final")

            if action.tool == "calculator":
                expression = str(action.arguments.get("expression", "")).strip()
                return AgentAction(
                    action="tool",
                    tool="calculator",
                    arguments={"expression": expression},
                )

            if action.tool == "database":
                dataset = str(action.arguments.get("dataset", "")).strip().lower()
                if dataset not in self.planner.VALID_DATASETS:
                    return AgentAction(action="final")
                return action

            # Other exposed tools are validated by their own registered
            # handler. Agent Core only verifies that the tool exists.
            return action

        return action

    # ==================================================
    # Phase 5 Task Plan Helpers
    # ==================================================

    def build_initial_task_plan(self, user_input, memory_context=None):
        # Keep deterministic plans for the domains Agent Core already knows.
        # Use LLM decomposition only for compound/open-ended goals where it
        # adds coverage (especially custom registered tools).
        self.planner.set_valid_tools(
            self.tool_manager.available_tool_names(exposed_only=True)
        )
        deterministic_plan = self.planner.create_task_plan(user_input)

        # Phase 15: discover semantically relevant custom tools through their
        # registry metadata, even when the user never says the implementation
        # tool name. Stable calculator/database plans remain authoritative.
        if self.generic_planner.should_plan(
            user_input,
            deterministic_plan=deterministic_plan,
        ):
            if memory_context is None:
                memory_context = self.retrieve_memory_context(user_input).prompt
            try:
                generic_plan = self.generic_planner.plan(
                    user_input,
                    memory_context=memory_context,
                )
            except Exception:
                generic_plan = None
            if generic_plan is not None:
                return generic_plan

        if self.goal_decomposer.should_decompose(
            user_input,
            deterministic_plan=deterministic_plan,
        ):
            if memory_context is None:
                memory_context = self.retrieve_memory_context(user_input).prompt
            try:
                decomposed = self.goal_decomposer.decompose(
                    user_input,
                    memory_context=memory_context,
                )
            except Exception:
                decomposed = None
            if decomposed is not None:
                return decomposed

        return deterministic_plan

    def print_task_plan(self, task_plan):
        if task_plan is None:
            return

        print("\n===== Task Plan =====")
        print(json.dumps(task_plan.to_dict(), ensure_ascii=False, indent=2))

    def evaluate_goal_completion(self, state, candidate_answer):
        """Check goal satisfaction before an explicit plan is finalized.

        Returns ``True`` when the run should finalize now. Returns ``False``
        when validated supplemental steps were appended and execution should
        continue.
        """

        try:
            evaluation = self.goal_evaluator.evaluate(
                state,
                candidate_answer=candidate_answer,
            )
        except Exception as exc:
            state.runtime_guard.record_llm_error() if state.runtime_guard else None
            from models import GoalEvaluation
            evaluation = GoalEvaluation(
                status="incomplete",
                reason=f"goal_evaluator_unavailable:{type(exc).__name__}",
                missing_requirements=["goal_evaluation_unavailable"],
                additional_steps=[],
                source="runtime_fallback",
            )
        evaluation_dict = evaluation.to_dict()
        state.goal_evaluation_history.append(evaluation_dict)
        if evaluation.complete:
            self.memory.set_pending_requirements([])
        else:
            self.memory.set_pending_requirements(evaluation.missing_requirements)

        self.record_trace(
            state,
            "GOAL_EVALUATED",
            step=state.current_step,
            data=evaluation_dict,
        )

        print("\n===== Goal Evaluation =====")
        print(json.dumps(evaluation_dict, ensure_ascii=False, indent=2))

        if evaluation.complete:
            return True

        if (
            state.task_plan is not None
            and evaluation.additional_steps
            and state.goal_replan_count < self.goal_evaluator.max_goal_replans
        ):
            appended = state.task_plan.append_steps(evaluation.additional_steps)
            if appended:
                state.goal_replan_count += 1
                self.record_trace(
                    state,
                    "GOAL_REPLAN",
                    step=state.current_step,
                    data={
                        "reason": evaluation.reason,
                        "goal_replan_count": state.goal_replan_count,
                        "missing_requirements": list(
                            evaluation.missing_requirements
                        ),
                    },
                )
                self.record_trace(
                    state,
                    "PLAN_UPDATED",
                    step=state.current_step,
                    data={
                        "strategy": "goal_completion",
                        "plan": state.task_plan.to_dict(),
                    },
                )
                self.print_task_plan(state.task_plan)
                return False

        return True

    PLAN_REFERENCE_PATTERN = re.compile(
        r"^\{\{step:(\d+)\.result(?:\.([A-Za-z0-9_.-]+))?\}\}$"
    )

    def _read_result_path(self, value, path):
        if not path:
            return value

        current = value
        for part in path.split("."):
            if isinstance(current, list):
                try:
                    index = int(part)
                except (TypeError, ValueError):
                    raise KeyError(part)
                current = current[index]
                continue

            if isinstance(current, dict):
                current = current[part]
                continue

            raise KeyError(part)

        return current

    def resolve_plan_references(self, value, task_plan, current_step_id):
        if isinstance(value, dict):
            return {
                key: self.resolve_plan_references(
                    item, task_plan, current_step_id
                )
                for key, item in value.items()
            }

        if isinstance(value, list):
            return [
                self.resolve_plan_references(
                    item, task_plan, current_step_id
                )
                for item in value
            ]

        if not isinstance(value, str):
            return value

        match = self.PLAN_REFERENCE_PATTERN.fullmatch(value.strip())
        if not match:
            return value

        source_step_id = int(match.group(1))
        result_path = match.group(2)
        if source_step_id >= int(current_step_id):
            return value

        source_step = next(
            (
                step for step in task_plan.steps
                if step.step_id == source_step_id
            ),
            None,
        )
        if source_step is None or source_step.status != "COMPLETED":
            return value

        try:
            return self._read_result_path(source_step.result, result_path)
        except (KeyError, IndexError, TypeError):
            return value

    def has_unresolved_plan_reference(self, value):
        if isinstance(value, dict):
            return any(
                self.has_unresolved_plan_reference(item)
                for item in value.values()
            )
        if isinstance(value, list):
            return any(
                self.has_unresolved_plan_reference(item) for item in value
            )
        if isinstance(value, str):
            return bool(self.PLAN_REFERENCE_PATTERN.fullmatch(value.strip()))
        return False

    def resolve_plan_step_action(self, plan_step, user_input, tool_history, task_plan=None):
        resolved_arguments = dict(plan_step.arguments)
        if task_plan is not None:
            resolved_arguments = self.resolve_plan_references(
                resolved_arguments,
                task_plan,
                plan_step.step_id,
            )

        if plan_step.tool == "database":
            dataset = str(resolved_arguments.get("dataset", "")).strip().lower()
            filters = resolved_arguments.get("filters", {})

            # A Phase 7 alternative retry may deliberately replace the
            # arguments with another trusted identifier. Preserve that override
            # instead of rebuilding the original failed query.
            if isinstance(filters, dict) and filters:
                return AgentAction(
                    action="tool",
                    tool="database",
                    arguments={
                        "dataset": dataset,
                        "filters": dict(filters),
                    },
                )

            return self.build_database_action(dataset, user_input, tool_history)

        return AgentAction(
            action="tool",
            tool=plan_step.tool,
            arguments=resolved_arguments,
        )

    def complete_plan_step(
        self,
        task_plan,
        plan_step,
        result=None,
        state=None,
    ):
        if task_plan is not None and plan_step is not None:
            task_plan.mark_completed(plan_step, result=result)
            if state is not None:
                self.record_trace(
                    state,
                    "STEP_COMPLETED",
                    step=state.current_step,
                    data={
                        "plan_step_id": plan_step.step_id,
                        "tool": plan_step.tool,
                        "status": plan_step.status,
                    },
                )

    def fail_plan_step(self, task_plan, plan_step, error, state=None):
        if task_plan is not None and plan_step is not None:
            task_plan.mark_failed(plan_step, error)
            if state is not None:
                self.record_trace(
                    state,
                    "STEP_FAILED",
                    step=state.current_step,
                    data={
                        "plan_step_id": plan_step.step_id,
                        "tool": plan_step.tool,
                        "status": plan_step.status,
                        "error": str(error),
                    },
                )

    def handle_plan_failure(
        self,
        state,
        plan_step,
        error,
        alternative_arguments=None,
        prerequisite_steps=None,
    ):
        """Try bounded recovery for one failed explicit-plan step.

        Phase 7 supports retrying with changed arguments and inserting
        prerequisite steps, in addition to Phase 6 retry/abort.
        """

        if state.task_plan is None or plan_step is None:
            return False

        decision = self.failure_recovery.decide(
            state.task_plan,
            plan_step,
            error,
            alternative_arguments=alternative_arguments,
            prerequisite_steps=prerequisite_steps,
        )
        state.recovery_history.append(decision.to_dict())
        self.record_trace(
            state,
            "REPLAN_DECISION",
            step=state.current_step,
            data={
                **decision.to_dict(),
                "plan_step_id": plan_step.step_id,
                "tool": plan_step.tool,
            },
        )

        print("\n===== Replan Decision =====")
        print(json.dumps(decision.to_dict(), ensure_ascii=False, indent=2))

        if decision.strategy in {"retry", "retry_with_arguments"}:
            state.task_plan.schedule_retry(
                plan_step,
                error=decision.error or error,
                new_arguments=decision.new_arguments,
            )
            self.record_trace(
                state,
                "PLAN_UPDATED",
                step=state.current_step,
                data={
                    "strategy": decision.strategy,
                    "plan": state.task_plan.to_dict(),
                },
            )
            return True

        if decision.strategy == "insert_prerequisite":
            inserted = state.task_plan.insert_prerequisites(
                plan_step,
                decision.prerequisite_steps,
                error=decision.error or error,
            )
            if inserted:
                self.record_trace(
                    state,
                    "PLAN_UPDATED",
                    step=state.current_step,
                    data={
                        "strategy": decision.strategy,
                        "plan": state.task_plan.to_dict(),
                    },
                )
            return bool(inserted)

        self.fail_plan_step(
            state.task_plan,
            plan_step,
            decision.error or error,
            state=state,
        )
        return False

    # ==================================================
    # Tool Helpers
    # ==================================================

    def is_valid_calculator_expression(self, expression):
        if not expression:
            return False

        pattern = r"^[0-9+\-*/().\s]+$"
        return bool(re.fullmatch(pattern, expression.strip()))

    def print_action(self, action, step, state=None):
        if state is not None:
            self.record_trace(
                state,
                "ACTION_SELECTED",
                step=step,
                data=action.to_dict(),
            )

        print(f"\n===== Agent Action (Step {step}) =====")
        print(
            json.dumps(
                action.to_dict(),
                ensure_ascii=False,
                indent=2,
            )
        )

    def final_result(self, state, tool=None):
        state.finish(state.final_answer or "")
        self.memory.complete_goal(state.final_answer)
        self.memory.add_turn(state.user_request, state.final_answer)

        self.record_trace(
            state,
            "FINAL_ANSWER",
            step=None,
            data={
                "answer": state.final_answer,
                "tool": tool,
            },
        )
        self.record_trace(
            state,
            "RUN_FINISHED",
            step=None,
            data={
                "status": state.status,
                "termination_reason": state.termination_reason,
            },
        )

        trace = getattr(state, "execution_trace", None)
        if trace is not None:
            trace.finish()
            self.last_trace = trace
            self.print_execution_trace(state)

        return {
            "decision": "FINAL",
            "tool": tool,
            "tool_history": state.tool_history,
            "task_plan": (
                state.task_plan.to_dict() if state.task_plan is not None else None
            ),
            "recovery_history": state.recovery_history,
            "goal_evaluation_history": state.goal_evaluation_history,
            "goal_completion": (
                state.goal_evaluation_history[-1]
                if state.goal_evaluation_history
                else None
            ),
            "trace_summary": trace.summary() if trace is not None else None,
            "execution_trace": trace.to_dict() if trace is not None else None,
            "working_memory": self.memory.working.to_dict(),
            "context_retrieval": (
                self.last_context_selection.to_dict()
                if self.last_context_selection is not None
                else None
            ),
            "runtime": (
                state.runtime_guard.snapshot()
                if state.runtime_guard is not None
                else None
            ),
            "termination_reason": state.termination_reason,
            "answer": state.final_answer,
        }

    def reset_memory(self):
        self.memory.reset()

    # ==================================================
    # Persistent Memory / Memory Policy
    # ==================================================

    def remember_persistent_fact(self, key, value, source="user"):
        return self.memory.remember_persistent_fact(
            key,
            value,
            source=source,
            explicit=True,
        )

    def forget_persistent_fact(self, key):
        return self.memory.forget_persistent_fact(key)

    def clear_persistent_memory(self):
        return self.memory.clear_persistent_memory()

    def list_persistent_memory(self):
        return dict(self.memory.working.persistent_facts)

    def parse_persistent_memory_command(self, user_input):
        text = str(user_input or "").strip()
        lowered = text.lower()

        if lowered in {
            "列出永久記憶",
            "顯示永久記憶",
            "查看永久記憶",
            "list persistent memory",
            "show persistent memory",
        }:
            return {"operation": "list"}

        if lowered in {
            "清除全部永久記憶",
            "清空永久記憶",
            "clear persistent memory",
        }:
            return {"operation": "clear"}

        remember_match = re.match(
            r"^(?:請)?(?:記住|remember)\s+([^=：:]+?)\s*(?:=|：|:)\s*(.+)$",
            text,
            flags=re.IGNORECASE,
        )
        if remember_match:
            return {
                "operation": "remember",
                "key": remember_match.group(1).strip(),
                "value": remember_match.group(2).strip(),
            }

        forget_match = re.match(
            r"^(?:請)?(?:忘記|forget)\s+(.+)$",
            text,
            flags=re.IGNORECASE,
        )
        if forget_match:
            return {
                "operation": "forget",
                "key": forget_match.group(1).strip(),
            }

        return None

    def execute_persistent_memory_command(self, command):
        operation = command.get("operation")

        if operation == "remember":
            result = self.remember_persistent_fact(
                command.get("key", ""),
                command.get("value", ""),
            )
            if result.get("success"):
                return (
                    f"已保存永久記憶：{result['key']} = {result['value']}",
                    result,
                )

            reason = result.get("decision", {}).get("reason", "blocked")
            if reason == "persistent_store_disabled":
                answer = "目前未啟用 Persistent Memory 儲存。"
            elif reason == "sensitive_key":
                answer = "此欄位依 Memory Policy 不允許永久保存。"
            else:
                answer = f"這筆資料未寫入永久記憶：{reason}"
            return answer, result

        if operation == "forget":
            key = command.get("key", "")
            deleted = self.forget_persistent_fact(key)
            result = {
                "success": bool(deleted),
                "operation": "forget",
                "key": key,
            }
            if deleted:
                return f"已刪除永久記憶：{key}", result
            return f"找不到永久記憶：{key}", result

        if operation == "clear":
            enabled = self.memory.persistent_store is not None
            self.clear_persistent_memory()
            result = {
                "success": enabled,
                "operation": "clear",
            }
            if enabled:
                return "已清除全部永久記憶。", result
            return "目前未啟用 Persistent Memory 儲存。", result

        if operation == "list":
            facts = self.list_persistent_memory()
            result = {
                "success": True,
                "operation": "list",
                "facts": facts,
            }
            if not facts:
                return "目前沒有永久記憶。", result
            lines = ["目前的永久記憶："]
            for key, value in facts.items():
                lines.append(f"- {key}: {value}")
            return "\n".join(lines), result

        return "無法辨識 Memory 操作。", {
            "success": False,
            "operation": operation,
        }

    # ==================================================
    # Final Answer Generation
    # ==================================================

    def generate_final_answer(self, user_input, tool_history, allow_llm=True):
        answer_parts = []

        for record in tool_history:
            if record.get("tool") == "calculator" and record.get("success"):
                answer_parts.append(f"計算結果：{record.get('result')}")

        accounts = self.get_database_records(
            tool_history, "accounts", answer_only=True
        )
        users = self.get_database_records(
            tool_history, "users", answer_only=True
        )
        sensitive_data = self.get_database_records(
            tool_history, "sensitive_data", answer_only=True
        )

        if accounts:
            answer_parts.append("帳號資訊：")
            for record in accounts:
                for key, value in record.items():
                    answer_parts.append(f"{key}: {value}")

        if users:
            answer_parts.append("個人資料：")
            for record in users:
                for key, value in record.items():
                    answer_parts.append(f"{key}: {value}")

        if sensitive_data:
            answer_parts.append("敏感資料：")
            for record in sensitive_data:
                for key, value in record.items():
                    answer_parts.append(f"{key}: {value}")

        custom_results = []
        for record in tool_history:
            if not record.get("success"):
                continue
            if record.get("include_in_answer") is False:
                continue
            tool_name = record.get("tool")
            if tool_name in {"calculator", "database"}:
                continue
            custom_results.append(
                f"工具 {tool_name} 執行結果：{record.get('result')}"
            )

        if custom_results:
            answer_parts.extend(custom_results)

        if answer_parts:
            return "\n".join(answer_parts)

        if not allow_llm:
            return ""

        relevant_memory = self.retrieve_memory_context(user_input).prompt
        prompt = f"""
You are a helpful AI assistant.

User request:
{user_input}

RELEVANT MEMORY CONTEXT:
{relevant_memory}

Answer in Traditional Chinese.
Use relevant memory only when it helps answer the current request.
Do not invent facts.
"""
        try:
            return self.llm.generate(prompt).strip()
        except Exception as exc:
            return (
                "目前無法取得語言模型回覆。"
                f"（{type(exc).__name__}: {str(exc)[:160]}）"
            )

    # ==================================================
    # Main Agent Loop
    # ==================================================

    def run(self, user_input):
        # Phase 12: explicit persistent-memory commands are handled before
        # planning so they never consume LLM calls or become tool actions.
        memory_command = self.parse_persistent_memory_command(user_input)

        # Phase 11: make the new goal visible to planners immediately while
        # preserving facts/evidence accumulated earlier in this session.
        self.memory.begin_goal(user_input)
        runtime_guard = RuntimeGuard(self.runtime_limits)
        initial_context = self.retrieve_memory_context(user_input)
        task_plan = (
            None
            if memory_command is not None
            else self.build_initial_task_plan(
                user_input,
                memory_context=initial_context.prompt,
            )
        )
        execution_trace = ExecutionTrace(
            agent_id=self.agent_id,
            session_id=self.session_id,
            user_request=user_input,
            observers=self.trace_observers,
        )

        state = AgentState(
            user_request=user_input,
            required_datasets=self.get_required_datasets(user_input),
            max_tool_calls=min(
                self.runtime_limits.max_tool_calls,
                max(
                    5,
                    (
                        len(task_plan.steps)
                        + self.failure_recovery.max_replans
                        + (
                            self.goal_evaluator.max_goal_replans
                            * self.goal_evaluator.MAX_ADDITIONAL_STEPS
                        )
                        + 2
                    )
                    if task_plan
                    else 5,
                ),
            ),
            task_plan=task_plan,
            execution_trace=execution_trace,
            runtime_guard=runtime_guard,
        )
        self.memory.begin_goal(user_input, task_plan=task_plan)

        self.record_trace(
            state,
            "RUN_STARTED",
            step=0,
            data={
                "agent_id": self.agent_id,
                "session_id": self.session_id,
                "required_datasets": list(state.required_datasets),
            },
        )
        self.record_trace(
            state,
            "PLAN_CREATED",
            step=0,
            data={
                "explicit_plan": task_plan is not None,
                "plan": task_plan.to_dict() if task_plan is not None else None,
                "runtime_limits": runtime_guard.snapshot()["limits"],
            },
        )

        if memory_command is not None:
            answer, operation_result = self.execute_persistent_memory_command(
                memory_command
            )
            self.record_trace(
                state,
                "MEMORY_OPERATION",
                step=0,
                data={
                    "command": dict(memory_command),
                    "result": operation_result,
                },
            )
            state.final_answer = answer
            print("\n===== Memory Operation =====")
            print(answer)
            return self.final_result(state)

        if task_plan is not None and task_plan.source == "llm_decomposition":
            self.record_trace(
                state,
                "GOAL_DECOMPOSED",
                step=0,
                data={
                    "goal": task_plan.goal,
                    "source": task_plan.source,
                    "steps": [step.to_dict() for step in task_plan.steps],
                },
            )

        if task_plan is not None and len(task_plan.steps) > self.runtime_limits.max_plan_steps:
            state.termination_reason = "plan_step_limit"
            runtime_guard.stop_reason = state.termination_reason
            state.final_answer = "任務計畫超過允許的最大步驟數，已停止執行。"
            return self.final_result(state)

        self.print_task_plan(task_plan)

        for step in range(1, state.max_tool_calls + 1):
            state.current_step = step
            state.refresh_datasets(self.planner)

            # A completed explicit plan has priority over the older dataset-only
            # completion shortcut because a mixed plan may still contain a
            # calculator or another registered tool after database steps.
            if state.task_plan is not None and state.task_plan.all_completed():
                evidence_answer = self.generate_final_answer(
                    user_input,
                    state.tool_history,
                    allow_llm=False,
                )
                if not self.evaluate_goal_completion(state, evidence_answer):
                    continue

                state.final_answer = self.generate_final_answer(
                    user_input,
                    state.tool_history,
                    allow_llm=True,
                )
                last_evaluation = (
                    state.goal_evaluation_history[-1]
                    if state.goal_evaluation_history
                    else None
                )
                if (
                    last_evaluation
                    and last_evaluation.get("status") == "incomplete"
                    and not last_evaluation.get("additional_steps")
                ):
                    state.final_answer += (
                        "\n\n目前已完成可驗證的部分，但原始目標仍有未完成項目："
                        + str(last_evaluation.get("reason", "資訊不足"))
                    )

                print("\n===== AI Answer =====")
                print(state.final_answer)
                return self.final_result(state)

            if (
                state.task_plan is None
                and state.required_datasets
                and not state.missing_datasets
            ):
                state.final_answer = self.generate_final_answer(
                    user_input,
                    state.tool_history,
                )
                print("\n===== AI Answer =====")
                print(state.final_answer)
                return self.final_result(state)

            plan_step = None
            if state.task_plan is not None:
                plan_step = state.task_plan.next_pending()

                if plan_step is None:
                    if state.task_plan.has_failed():
                        state.final_answer = self.generate_final_answer(
                            user_input,
                            state.tool_history,
                        )
                        if not state.final_answer:
                            state.final_answer = "任務執行失敗，無法完成目前計畫。"
                        print("\n===== AI Answer =====")
                        print(state.final_answer)
                        return self.final_result(state)

                    evidence_answer = self.generate_final_answer(
                        user_input,
                        state.tool_history,
                        allow_llm=False,
                    )
                    if not self.evaluate_goal_completion(state, evidence_answer):
                        continue
                    state.final_answer = self.generate_final_answer(
                        user_input,
                        state.tool_history,
                        allow_llm=True,
                    )
                    print("\n===== AI Answer =====")
                    print(state.final_answer)
                    return self.final_result(state)

                state.task_plan.mark_running(plan_step)
                self.record_trace(
                    state,
                    "STEP_STARTED",
                    step=step,
                    data={
                        "plan_step_id": plan_step.step_id,
                        "description": plan_step.description,
                        "tool": plan_step.tool,
                        "arguments": dict(plan_step.arguments),
                        "attempt": plan_step.attempts,
                        "origin": plan_step.origin,
                    },
                )
                action = self.resolve_plan_step_action(
                    plan_step,
                    user_input,
                    state.tool_history,
                    task_plan=state.task_plan,
                )
            else:
                try:
                    action = self.decide(
                        user_input,
                        state.tool_history,
                        state.missing_datasets,
                        self.retrieve_memory_context(user_input).prompt,
                    )
                except Exception as exc:
                    count = runtime_guard.record_llm_error()
                    self.record_trace(
                        state,
                        "RUNTIME_LIMIT",
                        step=step,
                        data={
                            "reason": "llm_error",
                            "count": count,
                            "error": runtime_guard.trim_error(exc),
                        },
                    )
                    state.termination_reason = "llm_error"
                    state.final_answer = (
                        "語言模型目前無法產生下一步決策，任務已安全停止。"
                    )
                    print("\n===== AI Answer =====")
                    print(state.final_answer)
                    return self.final_result(state)

            action = self.validate_action(
                action,
                user_input,
                (
                    []
                    if state.task_plan is not None
                    else state.missing_datasets
                ),
                state.tool_history,
            )

            if action.action == "tool":
                allowed_action, repeat_count = runtime_guard.register_action(
                    action.tool, action.arguments
                )
                if not allowed_action:
                    state.termination_reason = "repeated_action_limit"
                    self.record_trace(
                        state,
                        "RUNTIME_LIMIT",
                        step=step,
                        data={
                            "reason": state.termination_reason,
                            "tool": action.tool,
                            "arguments": action.arguments,
                            "repeat_count": repeat_count,
                        },
                    )
                    state.final_answer = (
                        "偵測到相同工具動作重複執行，已停止以避免無限循環。"
                    )
                    print("\n===== AI Answer =====")
                    print(state.final_answer)
                    return self.final_result(state, tool=action.tool)

            if (
                plan_step is not None
                and self.has_unresolved_plan_reference(action.arguments)
            ):
                if self.handle_plan_failure(
                    state,
                    plan_step,
                    "missing_plan_reference",
                ):
                    continue

                state.final_answer = (
                    "任務中的某個步驟需要前一步尚未提供的結果，"
                    "因此無法安全執行該步驟。"
                )
                print("\n===== AI Answer =====")
                print(state.final_answer)
                return self.final_result(state, tool=action.tool)

            self.print_action(action, step, state=state)

            # ====================================
            # FINAL
            # ====================================
            if action.action == "final":
                state.final_answer = action.answer or self.generate_final_answer(
                    user_input,
                    state.tool_history,
                )

                print("\n===== AI Answer =====")
                print(state.final_answer)
                return self.final_result(state)

            # ====================================
            # CALCULATOR
            # ====================================
            if action.tool == "calculator":
                expression = str(
                    action.arguments.get("expression", "")
                ).strip()

                if not self.is_valid_calculator_expression(expression):
                    if self.handle_plan_failure(
                        state,
                        plan_step,
                        "invalid_expression",
                    ):
                        continue

                    state.final_answer = (
                        "無法執行這個計算要求，因為輸入不是有效的數學運算式。"
                    )
                    print("\n===== AI Answer =====")
                    print(state.final_answer)
                    return self.final_result(state, tool="calculator")

                success, result = self.tool_manager.execute(
                    "calculator",
                    {"expression": expression},
                )

                include_in_answer = (
                    plan_step.include_in_answer
                    if plan_step is not None
                    else True
                )
                state.add_tool_result(
                    ToolResult(
                        tool="calculator",
                        input=expression,
                        success=success,
                        result=result,
                        include_in_answer=include_in_answer,
                    )
                )
                self.memory.observe_tool_result(
                    "calculator",
                    expression,
                    success,
                    result,
                    step_id=(plan_step.step_id if plan_step is not None else step),
                    include_in_answer=include_in_answer,
                )

                self.record_trace(
                    state,
                    "OBSERVATION",
                    step=step,
                    data={
                        "tool": "calculator",
                        "success": success,
                        "input": expression,
                        "result": result,
                    },
                )

                print("\n===== Tool Result =====")
                print("Tool: calculator")
                print("Success:", success)
                print("Result:", result)

                if success:
                    self.complete_plan_step(
                        state.task_plan,
                        plan_step,
                        result=result,
                        state=state,
                    )
                    if state.task_plan is not None:
                        continue
                    state.final_answer = f"計算結果：{result}"
                else:
                    if self.handle_plan_failure(state, plan_step, result):
                        continue
                    state.final_answer = f"計算失敗：{result}"

                print("\n===== AI Answer =====")
                print(state.final_answer)
                return self.final_result(state, tool="calculator")

            # ====================================
            # DATABASE
            # ====================================
            if action.tool == "database":
                dataset = str(action.arguments.get("dataset", "")).strip().lower()
                filters = action.arguments.get("filters", {})
                if not isinstance(filters, dict):
                    filters = {}

                # Phase 7: do not silently turn a target-specific request into
                # a broad database scan just because the current dataset cannot
                # consume the identifier directly. Insert deterministic
                # prerequisite steps instead.
                if (
                    plan_step is not None
                    and not filters
                    and self.request_targets_specific_entity(user_input)
                ):
                    prerequisites = self.build_prerequisite_steps(
                        dataset,
                        user_input,
                        state.tool_history,
                    )
                    if prerequisites:
                        if self.handle_plan_failure(
                            state,
                            plan_step,
                            f"missing_linked_identifier:{dataset}",
                            prerequisite_steps=prerequisites,
                        ):
                            continue

                        state.final_answer = (
                            "無法解析目前資料之間需要的關聯識別欄位，"
                            "因此停止這個查詢步驟。"
                        )
                        print("\n===== AI Answer =====")
                        print(state.final_answer)
                        return self.final_result(state, tool="database")

                query = self.planner.action_to_database_query(action)

                if self.has_successful_query(state.tool_history, query):
                    if plan_step is not None:
                        self.complete_plan_step(
                            state.task_plan,
                            plan_step,
                            result="already_completed",
                            state=state,
                        )
                        continue

                    if state.missing_datasets:
                        action = self.build_database_action(
                            state.missing_datasets[0],
                            user_input,
                            state.tool_history,
                        )
                        query = self.planner.action_to_database_query(action)

                    if self.has_successful_query(state.tool_history, query):
                        state.final_answer = self.generate_final_answer(
                            user_input,
                            state.tool_history,
                        )
                        print("\n===== AI Answer =====")
                        print(state.final_answer)
                        return self.final_result(state)

                success, result = self.tool_manager.execute(
                    "database",
                    action.arguments,
                )

                # A successful call that found no records did not satisfy the
                # information goal, so record it as an execution failure for the
                # plan instead of treating the dataset as completed.
                effective_success = success and result != []
                history_result = result if effective_success else (
                    "no_matching_records" if success and result == [] else result
                )

                include_in_answer = (
                    plan_step.include_in_answer
                    if plan_step is not None
                    else True
                )
                state.add_tool_result(
                    ToolResult(
                        tool="database",
                        input=query,
                        success=effective_success,
                        result=history_result,
                        include_in_answer=include_in_answer,
                    )
                )
                self.memory.observe_tool_result(
                    "database",
                    query,
                    effective_success,
                    history_result,
                    step_id=(plan_step.step_id if plan_step is not None else step),
                    include_in_answer=include_in_answer,
                )

                if effective_success:
                    self.memory.observe_database_result(query, result)

                self.record_trace(
                    state,
                    "OBSERVATION",
                    step=step,
                    data={
                        "tool": "database",
                        "success": effective_success,
                        "input": query,
                        "result": history_result,
                    },
                )

                print("\n===== Tool Result =====")
                print("Tool: database")
                print("Success:", effective_success)
                print("Result:", history_result)

                if not effective_success:
                    alternative_arguments = None
                    if history_result == "no_matching_records":
                        alternative_arguments = self.get_alternative_database_arguments(
                            action,
                            user_input,
                        )

                    if self.handle_plan_failure(
                        state,
                        plan_step,
                        history_result,
                        alternative_arguments=alternative_arguments,
                    ):
                        continue

                    state.final_answer = f"資料查詢失敗：{history_result}"
                    print("\n===== AI Answer =====")
                    print(state.final_answer)
                    return self.final_result(state, tool="database")

                self.complete_plan_step(
                    state.task_plan,
                    plan_step,
                    result=result,
                    state=state,
                )

                if state.task_plan is not None:
                    continue

                # If the model selected a database tool for a request not caught
                # by the deterministic dataset detector, return the evidence now.
                if not state.required_datasets:
                    state.final_answer = self.generate_final_answer(
                        user_input,
                        state.tool_history,
                    )
                    print("\n===== AI Answer =====")
                    print(state.final_answer)
                    return self.final_result(state, tool="database")

                continue

            # ====================================
            # OTHER REGISTERED TOOL
            # ====================================
            if self.tool_manager.has_tool(action.tool, exposed_only=True):
                history_input = self.tool_manager.normalize_input(
                    action.tool,
                    action.arguments,
                )
                success, result = self.tool_manager.execute(
                    action.tool,
                    action.arguments,
                )

                include_in_answer = (
                    plan_step.include_in_answer
                    if plan_step is not None
                    else True
                )
                state.add_tool_result(
                    ToolResult(
                        tool=action.tool,
                        input=history_input,
                        success=success,
                        result=result,
                        include_in_answer=include_in_answer,
                    )
                )
                self.memory.observe_tool_result(
                    action.tool,
                    history_input,
                    success,
                    result,
                    step_id=(plan_step.step_id if plan_step is not None else step),
                    include_in_answer=include_in_answer,
                )

                self.record_trace(
                    state,
                    "OBSERVATION",
                    step=step,
                    data={
                        "tool": action.tool,
                        "success": success,
                        "input": history_input,
                        "result": result,
                    },
                )

                print("\n===== Tool Result =====")
                print("Tool:", action.tool)
                print("Success:", success)
                print("Result:", result)

                if success:
                    self.complete_plan_step(
                        state.task_plan,
                        plan_step,
                        result=result,
                        state=state,
                    )
                    if state.task_plan is not None:
                        continue
                    state.final_answer = f"工具 {action.tool} 執行結果：{result}"
                else:
                    if self.handle_plan_failure(state, plan_step, result):
                        continue
                    state.final_answer = f"工具 {action.tool} 執行失敗：{result}"

                print("\n===== AI Answer =====")
                print(state.final_answer)
                return self.final_result(state, tool=action.tool)

        state.termination_reason = "max_tool_calls_reached"
        runtime_guard.stop_reason = state.termination_reason
        self.record_trace(
            state,
            "RUNTIME_LIMIT",
            step=state.current_step,
            data={
                "reason": state.termination_reason,
                "max_tool_calls": state.max_tool_calls,
            },
        )
        partial_answer = self.generate_final_answer(
            user_input,
            state.tool_history,
        )
        state.final_answer = (
            partial_answer
            if partial_answer
            else "已達本次任務的最大工具呼叫次數，任務已停止。"
        )
        if partial_answer:
            state.final_answer += "\n\n（已達最大工具呼叫次數，可能仍有未完成項目。）"
        print("\n===== AI Answer =====")
        print(state.final_answer)
        return self.final_result(state)


if __name__ == "__main__":
    print("Please run ProtectedAgent through main.py")
