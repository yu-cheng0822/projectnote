import sys
from pathlib import Path
from tempfile import TemporaryDirectory

PROJECT_DIR = Path(__file__).resolve().parents[1]
if str(PROJECT_DIR) not in sys.path:
    sys.path.insert(0, str(PROJECT_DIR))

from agent import Agent
from context_manager import MemoryContextManager


class QueueLLM:
    def __init__(self, outputs):
        self.outputs = iter(outputs)
        self.prompts = []

    def generate(self, prompt):
        self.prompts.append(prompt)
        try:
            return next(self.outputs)
        except StopIteration:
            return '{"action":"final","answer":"完成"}'


def test_retrieval_filters_unrelated_working_facts_but_keeps_namespace_siblings():
    agent = Agent(llm=QueueLLM([]))
    agent.memory.working.remember_fact("profile_lookup.name", "Alice")
    agent.memory.working.remember_fact("profile_lookup.score", 95)
    agent.memory.working.remember_fact("weather.temperature", 31)

    retrieved = agent.retrieve_memory_context("剛才的 score 是多少？")

    assert "profile_lookup.score: 95" in retrieved.prompt
    assert "profile_lookup.name: Alice" in retrieved.prompt
    assert "weather.temperature" not in retrieved.prompt


def test_persistent_memory_is_retrieved_only_when_relevant():
    with TemporaryDirectory() as temp_dir:
        path = Path(temp_dir) / "memory.sqlite3"
        agent = Agent(llm=QueueLLM([]), persistent_memory_path=path)
        agent.remember_persistent_fact("preference.language", "繁體中文")
        agent.remember_persistent_fact("preference.detail", "step-by-step")

        language = agent.retrieve_memory_context("請依照我的語言偏好回答")
        assert "preference.language: 繁體中文" in language.prompt

        unrelated = agent.retrieve_memory_context("123 * 456 是多少？")
        assert "preference.language" not in unrelated.prompt
        assert "preference.detail" not in unrelated.prompt


def test_entity_context_is_included_for_pronoun_reference():
    agent = Agent(llm=QueueLLM([]))
    agent.memory.active_entity.update({
        "name": "Alice",
        "user_id": "U001",
        "username": "alice",
    })

    retrieved = agent.retrieve_memory_context("那她的帳號呢？")

    assert "ACTIVE ENTITY:" in retrieved.prompt
    assert "name: Alice" in retrieved.prompt
    assert "user_id: U001" in retrieved.prompt


def test_agent_planner_receives_retrieved_context_not_full_memory_dump():
    llm = QueueLLM([
        '{"action":"final","tool":null,"arguments":{},"answer":"剛才的 score 是 95。"}'
    ])
    agent = Agent(llm=llm)
    agent.memory.working.remember_fact("profile_lookup.name", "Alice")
    agent.memory.working.remember_fact("profile_lookup.score", 95)
    agent.memory.working.remember_fact("weather.temperature", 31)

    result = agent.run("剛才的 score 是多少？")

    assert result["answer"] == "剛才的 score 是 95。"
    assert len(llm.prompts) == 1
    prompt = llm.prompts[0]
    assert "profile_lookup.score: 95" in prompt
    assert "profile_lookup.name: Alice" in prompt
    assert "weather.temperature" not in prompt
    assert result["context_retrieval"]["stats"]["working_fact_count"] == 2


def test_context_budget_is_bounded():
    manager = MemoryContextManager(max_chars=800, max_facts=50)
    agent = Agent(llm=QueueLLM([]))
    for index in range(40):
        agent.memory.working.remember_fact(
            f"topic.item_{index}",
            "topic " + ("x" * 80),
        )

    retrieved = manager.retrieve(agent.memory, "topic")

    assert len(retrieved.prompt) <= 800
    assert retrieved.stats["prompt_chars"] <= 800


if __name__ == "__main__":
    test_retrieval_filters_unrelated_working_facts_but_keeps_namespace_siblings()
    test_persistent_memory_is_retrieved_only_when_relevant()
    test_entity_context_is_included_for_pronoun_reference()
    test_agent_planner_receives_retrieved_context_not_full_memory_dump()
    test_context_budget_is_bounded()
    print("Agent Core 2.0 Phase 13 context management tests passed.")
