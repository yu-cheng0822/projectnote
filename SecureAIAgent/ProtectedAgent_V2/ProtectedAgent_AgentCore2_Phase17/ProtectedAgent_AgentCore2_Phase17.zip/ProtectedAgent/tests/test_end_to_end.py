import sys
from pathlib import Path
from tempfile import TemporaryDirectory

PROJECT_DIR = Path(__file__).resolve().parents[1]
if str(PROJECT_DIR) not in sys.path:
    sys.path.insert(0, str(PROJECT_DIR))

from agent import Agent
from robustness import RuntimeLimits
from tool_manager import ToolManager
from tool_registry import ToolDefinition


class NoCallLLM:
    def generate(self, prompt):
        raise AssertionError("This deterministic E2E path must not call the LLM")


class QueueLLM:
    def __init__(self, outputs):
        self.outputs = iter(outputs)
        self.prompts = []

    def generate(self, prompt):
        self.prompts.append(prompt)
        try:
            return next(self.outputs)
        except StopIteration:
            return '{"action":"final","answer":"完成"}'


def build_weather_manager():
    manager = ToolManager()

    def weather_lookup(arguments):
        city = str((arguments or {}).get("city", "")).strip()
        return {
            "city": city,
            "condition": "晴",
            "temperature": 28,
        }

    manager.register_tool(
        ToolDefinition(
            name="weather_lookup",
            description="Look up current demo weather for a city.",
            input_schema={
                "type": "object",
                "properties": {
                    "city": {"type": "string", "minLength": 1},
                },
                "required": ["city"],
                "additionalProperties": False,
            },
            output_schema={
                "type": "object",
                "properties": {
                    "city": {"type": "string"},
                    "condition": {"type": "string"},
                    "temperature": {"type": "number"},
                },
                "required": ["city", "condition", "temperature"],
                "additionalProperties": False,
            },
            capabilities=["weather.read"],
            side_effects=[],
            handler=weather_lookup,
            exposed_to_agent=True,
            strict_input_validation=True,
            strict_output_validation=True,
            metadata={
                "category": "weather",
                "planner_keywords": ["天氣", "氣溫", "weather", "temperature"],
            },
        )
    )
    return manager


def build_profile_manager():
    manager = ToolManager()

    def profile_lookup(arguments):
        person = str((arguments or {}).get("person", "")).strip()
        return {"name": person, "source": "profile_lookup"}

    def echo(arguments):
        return str((arguments or {}).get("text", ""))

    manager.register_tool(
        ToolDefinition(
            name="profile_lookup",
            description="Look up a small profile by person name.",
            input_schema={"person": "string"},
            handler=profile_lookup,
            capabilities=["profile.read"],
            exposed_to_agent=True,
        )
    )
    manager.register_tool(
        ToolDefinition(
            name="echo",
            description="Return the provided text.",
            input_schema={"text": "string"},
            handler=echo,
            capabilities=["text.echo"],
            exposed_to_agent=True,
        )
    )
    return manager


def test_e2e_deterministic_multi_tool_goal_and_trace():
    agent = Agent(llm=NoCallLLM())

    result = agent.run("請查 Alice 的帳號和個人資料，並計算 123 * 456")

    assert result["termination_reason"] is None
    assert result["task_plan"]["source"] == "deterministic"
    assert [item["tool"] for item in result["tool_history"]] == [
        "database",
        "database",
        "calculator",
    ]
    assert result["tool_history"][2]["result"] == 56088
    assert result["goal_completion"]["status"] == "complete"
    assert "account_id: A001" in result["answer"]
    assert "user_id: U001" in result["answer"]
    assert "計算結果：56088" in result["answer"]

    event_types = [
        event["event_type"]
        for event in result["execution_trace"]["events"]
    ]
    for required_event in (
        "RUN_STARTED",
        "PLAN_CREATED",
        "STEP_STARTED",
        "ACTION_SELECTED",
        "OBSERVATION",
        "STEP_COMPLETED",
        "GOAL_EVALUATED",
        "FINAL_ANSWER",
        "RUN_FINISHED",
    ):
        assert required_event in event_types


def test_e2e_session_memory_and_alternative_replanning():
    agent = Agent(llm=NoCallLLM())

    first = agent.run("請查 Alice 的個人資料")
    second = agent.run("那她的帳號呢？")
    third = agent.run("請查 A001 的地址")

    assert first["tool_history"][0]["input"] == "users | name=Alice"
    assert second["tool_history"][0]["input"] == "accounts | username=alice"
    assert "account_id: A001" in second["answer"]

    # A001 does not directly identify a user_id, so the Agent must build a
    # prerequisite chain before reading sensitive_data.
    assert [item["tool"] for item in third["tool_history"]] == [
        "database",
        "database",
        "database",
    ]
    assert third["tool_history"][0]["input"] == "accounts | account_id=A001"
    assert third["tool_history"][1]["input"] == "users | name=Alice"
    assert third["tool_history"][2]["input"] == "sensitive_data | user_id=U001"
    assert "address: Taipei" in third["answer"]
    assert agent.memory.get_active_name() == "Alice"
    assert agent.memory.get_active_user_id() == "U001"


def test_e2e_generic_planner_from_tool_metadata():
    manager = build_weather_manager()
    llm = QueueLLM([
        '''{
          "goal": "查詢台北天氣",
          "steps": [
            {
              "description": "取得台北天氣",
              "tool": "weather_lookup",
              "arguments": {"city": "台北"},
              "depends_on": [],
              "include_in_answer": true
            }
          ]
        }''',
        '''{
          "status": "complete",
          "reason": "已取得台北天氣",
          "missing_requirements": [],
          "additional_steps": []
        }''',
    ])
    agent = Agent(llm=llm, tool_manager=manager)

    result = agent.run("台北現在天氣如何？")

    assert result["task_plan"]["source"] == "generic_llm"
    assert result["tool_history"][0]["tool"] == "weather_lookup"
    assert result["tool_history"][0]["result"]["temperature"] == 28
    assert result["goal_completion"]["status"] == "complete"
    assert "weather_lookup" in llm.prompts[0]
    assert "database" not in llm.prompts[0]


def test_e2e_goal_completion_repairs_incomplete_plan():
    manager = build_profile_manager()
    llm = QueueLLM([
        # Decomposition intentionally misses the requested echo step.
        '''{
          "goal": "取得 Alice 並回傳她的名字",
          "steps": [
            {
              "description": "取得 Alice profile",
              "tool": "profile_lookup",
              "arguments": {"person": "Alice"},
              "depends_on": [],
              "include_in_answer": false
            }
          ]
        }''',
        # Self-evaluation notices the missing step.
        '''{
          "status": "incomplete",
          "reason": "尚未使用 echo 回傳 Alice 的名字",
          "missing_requirements": ["echo the profile name"],
          "additional_steps": [
            {
              "description": "用 echo 回傳 profile 名稱",
              "tool": "echo",
              "arguments": {"text": "{{step:1.result.name}}"},
              "depends_on": [1],
              "include_in_answer": true
            }
          ]
        }''',
        '''{
          "status": "complete",
          "reason": "profile 與 echo 均已完成",
          "missing_requirements": [],
          "additional_steps": []
        }''',
    ])
    agent = Agent(llm=llm, tool_manager=manager)

    result = agent.run(
        "先用 profile_lookup 取得 Alice，然後用 echo 回傳她的名字"
    )

    assert [item["tool"] for item in result["tool_history"]] == [
        "profile_lookup",
        "echo",
    ]
    assert result["tool_history"][1]["result"] == "Alice"
    assert [item["status"] for item in result["goal_evaluation_history"]] == [
        "incomplete",
        "complete",
    ]
    assert result["answer"] == "工具 echo 執行結果：Alice"

    event_types = [
        event["event_type"]
        for event in result["execution_trace"]["events"]
    ]
    assert "GOAL_REPLAN" in event_types
    assert "PLAN_UPDATED" in event_types


def test_e2e_persistent_memory_policy_and_restart():
    with TemporaryDirectory() as temp_dir:
        db_path = Path(temp_dir) / "memory.sqlite3"

        first_agent = Agent(llm=NoCallLLM(), persistent_memory_path=db_path)
        saved = first_agent.run("記住 preference.language=繁體中文")
        blocked = first_agent.run("記住 api_key=do-not-store")

        assert "已保存永久記憶" in saved["answer"]
        assert "不允許永久保存" in blocked["answer"]
        assert first_agent.list_persistent_memory() == {
            "preference.language": "繁體中文"
        }

        # Simulate a fresh Agent process/session using the same SQLite file.
        reopened = Agent(llm=NoCallLLM(), persistent_memory_path=db_path)
        assert reopened.list_persistent_memory() == {
            "preference.language": "繁體中文"
        }
        assert "api_key" not in reopened.list_persistent_memory()


def test_e2e_runtime_limit_fails_gracefully_with_partial_result():
    agent = Agent(
        llm=NoCallLLM(),
        runtime_limits=RuntimeLimits(max_tool_calls=1),
    )

    result = agent.run("請查 Alice 的帳號和個人資料")

    assert result["termination_reason"] == "max_tool_calls_reached"
    assert len(result["tool_history"]) == 1
    assert result["tool_history"][0]["success"] is True
    assert "可能仍有未完成項目" in result["answer"]
    assert result["runtime"]["stop_reason"] == "max_tool_calls_reached"


if __name__ == "__main__":
    test_e2e_deterministic_multi_tool_goal_and_trace()
    test_e2e_session_memory_and_alternative_replanning()
    test_e2e_generic_planner_from_tool_metadata()
    test_e2e_goal_completion_repairs_incomplete_plan()
    test_e2e_persistent_memory_policy_and_restart()
    test_e2e_runtime_limit_fails_gracefully_with_partial_result()
    print("Agent Core 2.0 Phase 17 end-to-end tests passed.")
