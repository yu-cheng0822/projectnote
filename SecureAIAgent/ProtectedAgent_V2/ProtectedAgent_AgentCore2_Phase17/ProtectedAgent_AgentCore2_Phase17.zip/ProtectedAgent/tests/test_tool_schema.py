import sys
from pathlib import Path

PROJECT_DIR = Path(__file__).resolve().parents[1]
if str(PROJECT_DIR) not in sys.path:
    sys.path.insert(0, str(PROJECT_DIR))

from tool_manager import ToolManager
from tool_registry import ToolDefinition


def test_default_metadata_is_standardized():
    manager = ToolManager()

    calculator = manager.get_tool_metadata("calculator")
    database = manager.get_tool_metadata("database")

    assert calculator["capabilities"] == ["arithmetic.compute"]
    assert calculator["side_effects"] == []
    assert calculator["read_only"] is True
    assert calculator["input_schema"]["type"] == "object"
    assert calculator["input_schema"]["required"] == ["expression"]
    assert calculator["output_schema"]["type"] == "number"

    assert "data.read" in database["capabilities"]
    assert database["read_only"] is True
    assert database["input_schema"]["properties"]["dataset"]["enum"] == [
        "users",
        "accounts",
        "sensitive_data",
    ]
    assert database["output_schema"]["type"] == "array"


def test_capability_lookup_does_not_require_agent_changes():
    manager = ToolManager()

    matches = manager.tools_with_capability("data.read")

    assert [item["name"] for item in matches] == ["database"]
    assert manager.tools_with_capability("does.not.exist") == []


def test_prompt_catalog_contains_capability_and_schema_metadata():
    manager = ToolManager()
    prompt = manager.prompt_catalog()

    assert "capabilities: ['arithmetic.compute']" in prompt
    assert "side_effects: ['none']" in prompt
    assert "read_only: True" in prompt
    assert "input_schema:" in prompt
    assert "output_schema:" in prompt
    assert "Legacy recovery placeholder" not in prompt


def test_invalid_default_tool_arguments_are_rejected_before_execution():
    manager = ToolManager()

    success, result = manager.execute("calculator", {})
    assert success is False
    assert result.startswith("invalid_tool_arguments:")
    assert "expression is required" in result

    success, result = manager.execute(
        "database",
        {
            "dataset": "users",
            "filters": {"unsupported_filter": "value"},
        },
    )
    assert success is False
    assert result.startswith("invalid_tool_arguments:")
    assert "unsupported_filter" in result


def test_legacy_string_input_is_normalized_before_schema_validation():
    manager = ToolManager()

    success, result = manager.execute("calculator", "2 + 3")
    assert success is True
    assert result == 5

    success, result = manager.execute("database", "users | name=Alice")
    assert success is True
    assert result[0]["user_id"] == "U001"


def test_strict_custom_tool_input_and_output_validation():
    manager = ToolManager()
    calls = []

    def uppercase(arguments):
        calls.append(arguments)
        return str(arguments["text"]).upper()

    manager.register_tool(
        ToolDefinition(
            name="uppercase",
            description="Uppercase text.",
            input_schema={
                "type": "object",
                "properties": {"text": {"type": "string", "minLength": 1}},
                "required": ["text"],
                "additionalProperties": False,
            },
            output_schema={"type": "string"},
            capabilities=["text.transform"],
            side_effects=[],
            handler=uppercase,
            strict_input_validation=True,
            strict_output_validation=True,
        )
    )

    success, result = manager.execute("uppercase", {"text": "hello"})
    assert success is True
    assert result == "HELLO"
    assert calls == [{"text": "hello"}]

    success, result = manager.execute("uppercase", {"wrong": "hello"})
    assert success is False
    assert result.startswith("invalid_tool_arguments:")
    # Invalid arguments never reach the tool handler.
    assert calls == [{"text": "hello"}]

    def broken_output(arguments):
        return {"not": "a string"}

    manager.register_tool(
        ToolDefinition(
            name="broken_output",
            description="Test invalid output.",
            input_schema={
                "type": "object",
                "properties": {},
                "required": [],
                "additionalProperties": False,
            },
            output_schema={"type": "string"},
            capabilities=["test.output"],
            handler=broken_output,
            strict_input_validation=True,
            strict_output_validation=True,
        )
    )

    success, result = manager.execute("broken_output", {})
    assert success is False
    assert result.startswith("invalid_tool_output:")


def test_phase4_shorthand_schema_remains_compatible():
    manager = ToolManager()

    def echo(arguments):
        return str((arguments or {}).get("text", ""))

    definition = manager.register_tool(
        ToolDefinition(
            name="echo_legacy_schema",
            description="Legacy shorthand schema test.",
            input_schema={"text": "string"},
            handler=echo,
            capabilities=["text.echo"],
        )
    )

    metadata = definition.public_metadata()
    assert metadata["input_schema"]["type"] == "object"
    assert metadata["input_schema"]["properties"]["text"]["type"] == "string"

    success, result = manager.execute(
        "echo_legacy_schema",
        {"text": "hello"},
    )
    assert success is True
    assert result == "hello"


if __name__ == "__main__":
    test_default_metadata_is_standardized()
    test_capability_lookup_does_not_require_agent_changes()
    test_prompt_catalog_contains_capability_and_schema_metadata()
    test_invalid_default_tool_arguments_are_rejected_before_execution()
    test_legacy_string_input_is_normalized_before_schema_validation()
    test_strict_custom_tool_input_and_output_validation()
    test_phase4_shorthand_schema_remains_compatible()
    print("Agent Core 2.0 Phase 14 tool schema tests passed.")
