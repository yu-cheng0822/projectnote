import sys
from pathlib import Path

PROJECT_DIR = Path(__file__).resolve().parents[1]
if str(PROJECT_DIR) not in sys.path:
    sys.path.insert(0, str(PROJECT_DIR))

from agent import Agent
from tool_manager import ToolManager
from tool_registry import ToolDefinition


class QueueLLM:
    def __init__(self, outputs):
        self.outputs = iter(outputs)
        self.prompts = []

    def generate(self, prompt):
        self.prompts.append(prompt)
        try:
            return next(self.outputs)
        except StopIteration:
            return '{"action":"final","answer":"完成"}'


def build_weather_manager():
    manager = ToolManager()

    def weather_lookup(arguments):
        city = str((arguments or {}).get("city", "")).strip()
        return {"city": city, "condition": "晴", "temperature": 28}

    manager.register_tool(
        ToolDefinition(
            name="weather_lookup",
            description="Look up current demo weather for a city.",
            input_schema={
                "type": "object",
                "properties": {
                    "city": {"type": "string", "minLength": 1},
                },
                "required": ["city"],
                "additionalProperties": False,
            },
            output_schema={
                "type": "object",
                "properties": {
                    "city": {"type": "string"},
                    "condition": {"type": "string"},
                    "temperature": {"type": "number"},
                },
                "required": ["city", "condition", "temperature"],
                "additionalProperties": False,
            },
            capabilities=["weather.read"],
            side_effects=[],
            handler=weather_lookup,
            exposed_to_agent=True,
            strict_input_validation=True,
            strict_output_validation=True,
            metadata={
                "category": "weather",
                "planner_keywords": ["天氣", "氣溫", "weather", "temperature"],
            },
        )
    )
    return manager


def test_semantic_custom_tool_is_planned_without_naming_tool():
    manager = build_weather_manager()
    llm = QueueLLM([
        '''{
          "goal": "查詢台北天氣",
          "steps": [
            {
              "description": "取得台北天氣",
              "tool": "weather_lookup",
              "arguments": {"city": "台北"},
              "depends_on": [],
              "include_in_answer": true
            }
          ]
        }''',
        # Goal evaluator for generic_llm plan.
        '''{
          "status": "complete",
          "reason": "已取得台北天氣",
          "missing_requirements": [],
          "additional_steps": []
        }'''
    ])
    agent = Agent(llm=llm, tool_manager=manager)

    result = agent.run("台北現在天氣如何？")

    assert result["task_plan"]["source"] == "generic_llm"
    assert result["tool_history"][0]["tool"] == "weather_lookup"
    assert result["tool_history"][0]["input"] == {"city": "台北"}
    assert result["tool_history"][0]["result"]["temperature"] == 28
    assert "weather_lookup" in llm.prompts[0]
    # Candidate retrieval keeps unrelated core tools out of this planning prompt.
    assert "- database:" not in llm.prompts[0]


def test_invalid_generic_plan_schema_falls_back_to_one_action_path():
    manager = build_weather_manager()
    llm = QueueLLM([
        # Generic plan is rejected before execution because city is required.
        '''{
          "goal": "查詢台北天氣",
          "steps": [
            {
              "description": "bad weather lookup",
              "tool": "weather_lookup",
              "arguments": {},
              "depends_on": [],
              "include_in_answer": true
            }
          ]
        }''',
        # Existing one-action path remains the fallback.
        '{"action":"tool","tool":"weather_lookup","arguments":{"city":"台北"}}',
    ])
    agent = Agent(llm=llm, tool_manager=manager)

    result = agent.run("台北天氣如何？")

    assert result["task_plan"] is None
    assert result["tool_history"][0]["tool"] == "weather_lookup"
    assert result["tool_history"][0]["success"] is True
    assert len(llm.prompts) >= 2


def test_deterministic_calculator_still_has_priority():
    manager = build_weather_manager()
    llm = QueueLLM([])
    agent = Agent(llm=llm, tool_manager=manager)

    result = agent.run("123 * 456 是多少？")

    assert result["task_plan"]["source"] == "deterministic"
    assert result["tool_history"][0]["tool"] == "calculator"
    assert result["tool_history"][0]["result"] == 56088
    assert llm.prompts == []


def test_registry_relevance_uses_capability_metadata_not_agent_hardcoding():
    manager = build_weather_manager()

    matches = manager.relevant_tools("請告訴我今天的氣溫")
    names = [item["name"] for item in matches]

    assert "weather_lookup" in names
    assert manager.get_tool_metadata("weather_lookup")["capabilities"] == ["weather.read"]


if __name__ == "__main__":
    test_semantic_custom_tool_is_planned_without_naming_tool()
    test_invalid_generic_plan_schema_falls_back_to_one_action_path()
    test_deterministic_calculator_still_has_priority()
    test_registry_relevance_uses_capability_metadata_not_agent_hardcoding()
    print("Agent Core 2.0 Phase 15 generic planner tests passed.")
