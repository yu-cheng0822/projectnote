import sys
from pathlib import Path
from tempfile import TemporaryDirectory

PROJECT_DIR = Path(__file__).resolve().parents[1]
if str(PROJECT_DIR) not in sys.path:
    sys.path.insert(0, str(PROJECT_DIR))

from agent import Agent


class NoCallLLM:
    def generate(self, prompt):
        raise AssertionError("Persistent-memory commands must not call the LLM")


def test_explicit_safe_fact_persists_across_agent_instances():
    with TemporaryDirectory() as temp_dir:
        db_path = Path(temp_dir) / "memory.sqlite3"

        first_agent = Agent(llm=NoCallLLM(), persistent_memory_path=db_path)
        result = first_agent.run("記住 preference.language=繁體中文")

        assert "已保存永久記憶" in result["answer"]
        assert result["working_memory"]["persistent_facts"] == {
            "preference.language": "繁體中文"
        }

        second_agent = Agent(llm=NoCallLLM(), persistent_memory_path=db_path)
        assert second_agent.list_persistent_memory() == {
            "preference.language": "繁體中文"
        }
        assert "preference.language: 繁體中文" in second_agent.memory.to_prompt_context()


def test_reset_memory_clears_session_but_keeps_persistent_facts():
    with TemporaryDirectory() as temp_dir:
        db_path = Path(temp_dir) / "memory.sqlite3"
        agent = Agent(llm=NoCallLLM(), persistent_memory_path=db_path)

        agent.run("記住 preference.language=繁體中文")
        agent.memory.working.remember_fact("session.temp", "temporary")
        agent.memory.add_turn("測試", "測試回答")

        agent.reset_memory()

        assert agent.memory.turns == []
        assert agent.memory.working.facts == {}
        assert agent.list_persistent_memory() == {
            "preference.language": "繁體中文"
        }
        assert "preference.language: 繁體中文" in agent.memory.to_prompt_context()


def test_sensitive_fact_is_blocked_by_memory_policy():
    with TemporaryDirectory() as temp_dir:
        db_path = Path(temp_dir) / "memory.sqlite3"
        agent = Agent(llm=NoCallLLM(), persistent_memory_path=db_path)

        result = agent.run("記住 api_key=super-secret-value")

        assert "不允許永久保存" in result["answer"]
        assert agent.list_persistent_memory() == {}

        reopened = Agent(llm=NoCallLLM(), persistent_memory_path=db_path)
        assert reopened.list_persistent_memory() == {}


def test_normal_tool_evidence_is_not_automatically_persisted():
    class DatabaseNoCallLLM:
        def generate(self, prompt):
            raise AssertionError("Deterministic database task should not need the LLM")

    with TemporaryDirectory() as temp_dir:
        db_path = Path(temp_dir) / "memory.sqlite3"
        agent = Agent(llm=DatabaseNoCallLLM(), persistent_memory_path=db_path)

        result = agent.run("請查 Alice 的個人資料")
        assert result["working_memory"]["facts"]["users.name"] == "Alice"
        assert agent.list_persistent_memory() == {}

        reopened = Agent(llm=NoCallLLM(), persistent_memory_path=db_path)
        assert reopened.list_persistent_memory() == {}
        assert reopened.memory.working.facts == {}


def test_forget_and_clear_persistent_memory_are_explicit_operations():
    with TemporaryDirectory() as temp_dir:
        db_path = Path(temp_dir) / "memory.sqlite3"
        agent = Agent(llm=NoCallLLM(), persistent_memory_path=db_path)

        agent.run("記住 preference.language=繁體中文")
        agent.run("記住 preference.detail=step-by-step")

        forgotten = agent.run("忘記 preference.language")
        assert "已刪除永久記憶" in forgotten["answer"]
        assert agent.list_persistent_memory() == {
            "preference.detail": "step-by-step"
        }

        cleared = agent.run("清除全部永久記憶")
        assert "已清除全部永久記憶" in cleared["answer"]
        assert agent.list_persistent_memory() == {}


if __name__ == "__main__":
    test_explicit_safe_fact_persists_across_agent_instances()
    test_reset_memory_clears_session_but_keeps_persistent_facts()
    test_sensitive_fact_is_blocked_by_memory_policy()
    test_normal_tool_evidence_is_not_automatically_persisted()
    test_forget_and_clear_persistent_memory_are_explicit_operations()
    print("Agent Core 2.0 Phase 12 persistent memory tests passed.")
