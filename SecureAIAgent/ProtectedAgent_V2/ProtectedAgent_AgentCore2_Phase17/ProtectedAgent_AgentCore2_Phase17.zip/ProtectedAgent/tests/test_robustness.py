import sys
from pathlib import Path

PROJECT_DIR = Path(__file__).resolve().parents[1]
if str(PROJECT_DIR) not in sys.path:
    sys.path.insert(0, str(PROJECT_DIR))

from agent import Agent
from llm import LocalLLM
from robustness import RuntimeLimits
from tool_manager import ToolManager
from tool_registry import ToolDefinition
from tools.database import DatabaseTool


class FailingLLM:
    def __init__(self, message="simulated_llm_failure"):
        self.message = message
        self.calls = 0

    def generate(self, prompt):
        self.calls += 1
        raise RuntimeError(self.message)


class QueueLLM:
    def __init__(self, outputs):
        self.outputs = iter(outputs)
        self.calls = 0

    def generate(self, prompt):
        self.calls += 1
        try:
            return next(self.outputs)
        except StopIteration:
            return "not valid json"


class FlakyDatabaseTool:
    def __init__(self):
        self.calls = 0
        self.delegate = DatabaseTool()

    def __call__(self, arguments=None):
        self.calls += 1
        if self.calls == 1:
            raise RuntimeError("temporary_failure")
        return self.delegate(arguments)

    def to_history_input(self, arguments=None):
        return self.delegate.to_history_input(arguments)


def replace_database(manager, handler):
    manager.register_tool(
        ToolDefinition(
            name="database",
            description="robustness test database",
            input_schema={
                "dataset": "users | accounts | sensitive_data",
                "filters": "object",
            },
            handler=handler,
            error_results={"missing_database_query", "unknown_database_query"},
            exposed_to_agent=True,
        ),
        replace=True,
    )


def test_deterministic_task_survives_llm_outage():
    llm = FailingLLM()
    agent = Agent(llm=llm)
    result = agent.run("123 * 456 是多少？")

    assert result["tool_history"][0]["result"] == 56088
    assert result["termination_reason"] is None
    assert llm.calls == 0


def test_llm_failure_gracefully_stops_open_ended_task():
    agent = Agent(llm=FailingLLM())
    result = agent.run("你好，請介紹你自己")

    assert result["termination_reason"] == "llm_error"
    assert "語言模型" in result["answer"]
    assert result["runtime"]["llm_errors"] == 1
    assert any(
        event["event_type"] == "RUNTIME_LIMIT"
        for event in result["execution_trace"]["events"]
    )


def test_tool_exception_is_isolated_from_agent_process():
    manager = ToolManager()

    def explode(arguments):
        raise ValueError("boom")

    manager.register_tool(
        ToolDefinition(
            name="explode",
            description="A test tool that raises an exception.",
            input_schema={
                "type": "object",
                "properties": {},
                "additionalProperties": False,
            },
            handler=explode,
            exposed_to_agent=True,
        )
    )
    llm = QueueLLM([
        '{"action":"tool","tool":"explode","arguments":{}}'
    ])
    agent = Agent(llm=llm, tool_manager=manager)
    result = agent.run("使用 explode")

    assert len(result["tool_history"]) == 1
    assert result["tool_history"][0]["success"] is False
    assert result["tool_history"][0]["result"] == "boom"
    assert "執行失敗" in result["answer"]


def test_plan_step_limit_stops_before_any_tool_execution():
    limits = RuntimeLimits(max_plan_steps=1)
    agent = Agent(llm=FailingLLM(), runtime_limits=limits)
    result = agent.run("請查 Alice 的帳號和個人資料")

    assert result["termination_reason"] == "plan_step_limit"
    assert result["tool_history"] == []
    assert "最大步驟數" in result["answer"]


def test_max_tool_call_limit_returns_partial_result():
    limits = RuntimeLimits(max_tool_calls=1)
    agent = Agent(llm=FailingLLM(), runtime_limits=limits)
    result = agent.run("請查 Alice 的帳號和個人資料")

    assert result["termination_reason"] == "max_tool_calls_reached"
    assert len(result["tool_history"]) == 1
    assert result["tool_history"][0]["success"] is True
    assert "可能仍有未完成項目" in result["answer"]


def test_repeated_action_limit_breaks_retry_loop():
    manager = ToolManager()
    flaky = FlakyDatabaseTool()
    replace_database(manager, flaky)
    limits = RuntimeLimits(max_action_repeats=1)
    agent = Agent(
        llm=FailingLLM(),
        tool_manager=manager,
        runtime_limits=limits,
    )
    result = agent.run("請查 Alice 的個人資料")

    assert flaky.calls == 1
    assert result["termination_reason"] == "repeated_action_limit"
    assert "無限循環" in result["answer"]


def test_malformed_json_does_not_crash_agent():
    llm = QueueLLM([
        "THIS IS NOT JSON",
        "仍然不是 JSON，但系統不應崩潰",
    ])
    agent = Agent(llm=llm)
    result = agent.run("跟我打聲招呼")

    assert result["decision"] == "FINAL"
    assert isinstance(result["answer"], str)
    assert result["answer"]


def test_local_llm_has_request_timeout(monkeypatch=None):
    # No real network request is made. Replace requests.post at module level.
    import llm as llm_module
    import requests

    original = llm_module.requests.post

    def timeout_post(*args, **kwargs):
        assert kwargs.get("timeout") == 0.25
        raise requests.Timeout("simulated timeout")

    llm_module.requests.post = timeout_post
    try:
        local = LocalLLM(timeout_seconds=0.25)
        try:
            local.generate("hello")
        except RuntimeError as exc:
            assert str(exc) == "llm_timeout"
        else:
            raise AssertionError("LocalLLM timeout should raise RuntimeError")
    finally:
        llm_module.requests.post = original


if __name__ == "__main__":
    test_deterministic_task_survives_llm_outage()
    test_llm_failure_gracefully_stops_open_ended_task()
    test_tool_exception_is_isolated_from_agent_process()
    test_plan_step_limit_stops_before_any_tool_execution()
    test_max_tool_call_limit_returns_partial_result()
    test_repeated_action_limit_breaks_retry_loop()
    test_malformed_json_does_not_crash_agent()
    test_local_llm_has_request_timeout()
    print("Agent Core 2.0 Phase 16 robustness tests passed.")
