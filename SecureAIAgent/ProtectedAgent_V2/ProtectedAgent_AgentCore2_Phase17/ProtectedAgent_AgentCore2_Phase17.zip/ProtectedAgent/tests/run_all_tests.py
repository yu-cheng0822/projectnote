"""Run the complete ProtectedAgent regression suite in isolated subprocesses.

Usage from the SecureAIAgent project root:
    python ProtectedAgent\tests\run_all_tests.py

The runner keeps every test file isolated so temporary monkeypatches, SQLite
connections, fake LLMs, and tool registrations cannot leak into another phase.
"""

import os
import subprocess
import sys
from pathlib import Path

TEST_DIR = Path(__file__).resolve().parent
PROJECT_DIR = TEST_DIR.parent

TEST_FILES = [
    "test_agent_core.py",              # Phase 2
    "test_memory.py",                  # Phase 3
    "test_tool_registry.py",           # Phase 4
    "test_task_plan.py",               # Phase 5
    "test_replanning.py",              # Phase 6
    "test_alternative_replanning.py",  # Phase 7
    "test_execution_trace.py",         # Phase 8
    "test_goal_decomposition.py",      # Phase 9
    "test_goal_completion.py",         # Phase 10
    "test_working_memory.py",          # Phase 11
    "test_persistent_memory.py",       # Phase 12
    "test_context_management.py",      # Phase 13
    "test_tool_schema.py",             # Phase 14
    "test_generic_planner.py",         # Phase 15
    "test_robustness.py",              # Phase 16
    "test_end_to_end.py",              # Phase 17
]


def run_test(test_name):
    path = TEST_DIR / test_name
    if not path.exists():
        return False, "", f"Missing test file: {path}"

    env = os.environ.copy()
    env["PYTHONIOENCODING"] = "utf-8"

    completed = subprocess.run(
        [sys.executable, str(path)],
        cwd=str(PROJECT_DIR.parent),
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        env=env,
    )
    return completed.returncode == 0, completed.stdout, completed.stderr


def main():
    print("=" * 64)
    print("ProtectedAgent Full Regression Test Suite (Phase 2-17)")
    print("=" * 64)

    passed = 0
    failed = []

    for index, test_name in enumerate(TEST_FILES, start=1):
        ok, stdout, stderr = run_test(test_name)
        status = "PASS" if ok else "FAIL"
        print(f"[{index:02d}/{len(TEST_FILES):02d}] {status}  {test_name}")

        if ok:
            passed += 1
            continue

        failed.append(test_name)
        print("\n--- stdout ---")
        print(stdout.rstrip() or "(empty)")
        print("\n--- stderr ---")
        print(stderr.rstrip() or "(empty)")
        print("-" * 64)

    print("\n" + "=" * 64)
    print(f"Result: {passed}/{len(TEST_FILES)} test files passed")

    if failed:
        print("Failed:")
        for test_name in failed:
            print(f"- {test_name}")
        print("=" * 64)
        return 1

    print("ALL PROTECTEDAGENT REGRESSION TESTS PASSED")
    print("=" * 64)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
