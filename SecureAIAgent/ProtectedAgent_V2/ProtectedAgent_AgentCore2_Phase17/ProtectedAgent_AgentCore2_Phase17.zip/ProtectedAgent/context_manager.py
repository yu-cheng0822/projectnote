from dataclasses import dataclass, field
import re
from typing import Any


@dataclass
class RetrievedContext:
    """Compact context selected for one current goal.

    The object is deliberately inspectable: Agent Core can expose what was
    selected without exposing hidden model state or coupling retrieval to an
    external vector database.
    """

    query: str
    prompt: str
    selected: dict[str, Any] = field(default_factory=dict)
    stats: dict[str, int] = field(default_factory=dict)

    def to_dict(self):
        return {
            "query": self.query,
            "prompt": self.prompt,
            "selected": dict(self.selected),
            "stats": dict(self.stats),
        }


class MemoryContextManager:
    """Phase 13 bounded, relevance-aware retrieval for Agent memory.

    This is intentionally local and dependency-free. It uses lightweight
    lexical relevance plus conversational-reference rules so ProtectedAgent
    does not need a vector database merely to keep prompts bounded.
    """

    FOLLOW_UP_MARKERS = (
        "剛才", "剛剛", "之前", "上次", "前面", "那", "這個", "上述",
        "it", "that", "previous", "before", "earlier", "last time",
    )

    KEY_ALIASES = {
        "language": ("語言", "language"),
        "preference": ("偏好", "喜好", "preference"),
        "detail": ("詳細", "細節", "detail"),
        "score": ("分數", "score"),
        "name": ("姓名", "名字", "name"),
        "user_id": ("使用者", "使用者編號", "user id", "userid"),
        "account_id": ("帳號", "帳戶", "account id"),
        "username": ("帳號", "使用者名稱", "username"),
        "email": ("信箱", "電子郵件", "email"),
        "phone": ("電話", "phone"),
        "address": ("地址", "address"),
    }

    def __init__(
        self,
        *,
        max_chars=3600,
        max_facts=8,
        max_persistent=6,
        max_evidence=4,
        max_turns=4,
    ):
        self.max_chars = max(800, int(max_chars))
        self.max_facts = max(1, int(max_facts))
        self.max_persistent = max(1, int(max_persistent))
        self.max_evidence = max(1, int(max_evidence))
        self.max_turns = max(1, int(max_turns))

    # --------------------------------------------------------------
    # Public API
    # --------------------------------------------------------------

    def retrieve(self, memory, query):
        query = str(query or "").strip()
        query_tokens = self._tokens(query)
        follow_up = self._is_follow_up(query, memory)

        selected = {
            "active_entity": None,
            "persistent_facts": {},
            "working_facts": {},
            "variables": {},
            "pending_requirements": [],
            "evidence": [],
            "turns": [],
        }

        # Entity identity is only injected when the request actually refers to
        # the active person (pronoun/reference or an explicit matching ID/name).
        if self._should_include_active_entity(memory, query):
            selected["active_entity"] = memory.active_entity.to_dict()

        working = memory.working
        selected["persistent_facts"] = self._select_mapping(
            working.persistent_facts,
            query_tokens,
            self.max_persistent,
        )
        selected["working_facts"] = self._select_mapping(
            working.facts,
            query_tokens,
            self.max_facts,
        )

        useful_variables = {
            key: value
            for key, value in working.variables.items()
            if key not in {"last_tool_result", "current_goal"}
        }
        selected["variables"] = self._select_mapping(
            useful_variables,
            query_tokens,
            5,
        )

        if working.pending_requirements and follow_up:
            selected["pending_requirements"] = list(
                working.pending_requirements[-4:]
            )

        selected["evidence"] = self._select_evidence(
            working.evidence,
            query_tokens,
            follow_up=follow_up,
        )
        selected["turns"] = self._select_turns(
            memory.turns,
            query_tokens,
            follow_up=follow_up,
        )

        prompt = self._build_prompt(query, working, selected)
        prompt = self._bounded(prompt)

        stats = {
            "prompt_chars": len(prompt),
            "persistent_fact_count": len(selected["persistent_facts"]),
            "working_fact_count": len(selected["working_facts"]),
            "variable_count": len(selected["variables"]),
            "evidence_count": len(selected["evidence"]),
            "turn_count": len(selected["turns"]),
            "active_entity_included": int(selected["active_entity"] is not None),
        }

        return RetrievedContext(
            query=query,
            prompt=prompt or "(empty)",
            selected=selected,
            stats=stats,
        )

    # --------------------------------------------------------------
    # Retrieval
    # --------------------------------------------------------------

    def _select_mapping(self, mapping, query_tokens, limit):
        ranked = []
        for index, (key, value) in enumerate(mapping.items()):
            text = self._enrich_key_text(key, value)
            score = self._score(text, query_tokens)
            if score <= 0:
                continue
            ranked.append((score, index, str(key), value))

        ranked.sort(key=lambda item: (item[0], item[1]), reverse=True)
        chosen = [(key, value) for _, _, key, value in ranked[:limit]]

        # If one namespaced fact is relevant (for example
        # profile_lookup.score), include a few sibling facts from the same
        # evidence namespace (profile_lookup.name). This preserves compact
        # object-level context without falling back to the entire memory store.
        prefixes = {
            key.rsplit(".", 1)[0]
            for key, _ in chosen
            if "." in key
        }
        chosen_keys = {key for key, _ in chosen}
        for key, value in mapping.items():
            key = str(key)
            if len(chosen) >= limit:
                break
            if key in chosen_keys or "." not in key:
                continue
            if key.rsplit(".", 1)[0] in prefixes:
                chosen.append((key, value))
                chosen_keys.add(key)

        return dict(chosen)

    def _select_evidence(self, evidence, query_tokens, *, follow_up):
        ranked = []
        evidence = list(evidence or [])
        for index, item in enumerate(evidence):
            text = self._flatten_text(item)
            score = self._score(text, query_tokens)
            recency = index + 1
            if follow_up and index >= max(0, len(evidence) - 2):
                score += 2
            if score > 0:
                ranked.append((score, recency, dict(item)))

        ranked.sort(key=lambda item: (item[0], item[1]), reverse=True)
        chosen = [item for _, _, item in ranked[: self.max_evidence]]
        # Present selected evidence chronologically for easier model reading.
        chosen.reverse()
        return chosen

    def _select_turns(self, turns, query_tokens, *, follow_up):
        turns = list(turns or [])
        ranked = []
        for index, turn in enumerate(turns):
            payload = turn.to_dict() if hasattr(turn, "to_dict") else dict(turn)
            text = f"{payload.get('user', '')} {payload.get('assistant', '')}"
            score = self._score(text, query_tokens)
            if follow_up and index >= max(0, len(turns) - 2):
                score += 3
            if score > 0:
                ranked.append((score, index, payload))

        ranked.sort(key=lambda item: (item[0], item[1]), reverse=True)
        chosen = [item for _, _, item in ranked[: self.max_turns]]
        chosen.reverse()
        return chosen

    def _should_include_active_entity(self, memory, query):
        active = memory.active_entity
        values = [
            active.name,
            active.user_id,
            active.username,
            active.account_id,
        ]
        if not any(values):
            return False
        if memory.refers_to_active_entity(query):
            return True

        lowered = query.lower()
        return any(
            value and str(value).lower() in lowered
            for value in values
        )

    def _is_follow_up(self, query, memory):
        lowered = query.lower()
        if memory.refers_to_active_entity(query):
            return True
        return any(marker.lower() in lowered for marker in self.FOLLOW_UP_MARKERS)

    # --------------------------------------------------------------
    # Prompt formatting
    # --------------------------------------------------------------

    def _build_prompt(self, query, working, selected):
        lines = []

        entity = selected["active_entity"]
        if entity:
            lines.append("ACTIVE ENTITY:")
            for key in ("name", "user_id", "username", "account_id"):
                value = entity.get(key)
                if value:
                    lines.append(f"- {key}: {value}")

        has_working = any(
            (
                selected["persistent_facts"],
                selected["working_facts"],
                selected["variables"],
                selected["pending_requirements"],
                selected["evidence"],
            )
        )
        if has_working:
            lines.append("RELEVANT WORKING MEMORY:")
            if working.current_goal:
                lines.append(f"- current_goal: {working.current_goal}")
            lines.append(f"- status: {working.status}")

            if selected["persistent_facts"]:
                lines.append("- persistent_facts:")
                for key, value in selected["persistent_facts"].items():
                    lines.append(f"  - {key}: {value}")

            if selected["working_facts"]:
                lines.append("- known_facts:")
                for key, value in selected["working_facts"].items():
                    lines.append(f"  - {key}: {value}")

            if selected["variables"]:
                lines.append("- variables:")
                for key, value in selected["variables"].items():
                    lines.append(f"  - {key}: {value}")

            if selected["pending_requirements"]:
                lines.append("- pending_requirements:")
                for item in selected["pending_requirements"]:
                    lines.append(f"  - {item}")

            if selected["evidence"]:
                lines.append("- relevant_evidence:")
                for item in selected["evidence"]:
                    lines.append(
                        "  - "
                        f"tool={item.get('tool')} "
                        f"success={item.get('success')} "
                        f"input={item.get('input')} "
                        f"result={item.get('result')}"
                    )

        if selected["turns"]:
            lines.append("RELEVANT CONVERSATION:")
            for turn in selected["turns"]:
                lines.append(f"User: {turn.get('user', '')}")
                lines.append(f"Assistant: {turn.get('assistant', '')}")

        return "\n".join(lines)

    def _bounded(self, text):
        text = str(text or "").strip()
        if len(text) <= self.max_chars:
            return text
        suffix = "\n...[context truncated by Phase 13 budget]"
        return text[: self.max_chars - len(suffix)].rstrip() + suffix

    # --------------------------------------------------------------
    # Lightweight lexical scoring
    # --------------------------------------------------------------

    def _score(self, candidate_text, query_tokens):
        if not query_tokens:
            return 0
        candidate = self._normalize(candidate_text)
        score = 0
        for token in query_tokens:
            if token and token in candidate:
                score += 3 if len(token) >= 4 else 2
        return score

    def _enrich_key_text(self, key, value):
        key_text = str(key)
        aliases = []
        lowered = key_text.lower()
        for name, values in self.KEY_ALIASES.items():
            if name in lowered:
                aliases.extend(values)
        return f"{key_text} {value} {' '.join(aliases)}"

    def _tokens(self, text):
        normalized = self._normalize(text)
        tokens = set()

        # Latin words / identifiers / numbers.
        for token in re.findall(r"[a-z0-9_\.]+", normalized):
            if len(token) >= 2:
                tokens.add(token)
                for part in re.split(r"[_.]", token):
                    if len(part) >= 2:
                        tokens.add(part)

        # CJK sequences plus 2-character shingles provide useful matching
        # without requiring an external tokenizer.
        for sequence in re.findall(r"[\u3400-\u9fff]+", normalized):
            if len(sequence) >= 2:
                tokens.add(sequence)
            for size in (2, 3):
                if len(sequence) >= size:
                    for index in range(len(sequence) - size + 1):
                        tokens.add(sequence[index : index + size])

        return tokens

    @staticmethod
    def _normalize(value):
        return re.sub(r"\s+", " ", str(value or "").strip().lower())

    def _flatten_text(self, value):
        if isinstance(value, dict):
            return " ".join(
                f"{key} {self._flatten_text(item)}"
                for key, item in value.items()
            )
        if isinstance(value, list):
            return " ".join(self._flatten_text(item) for item in value)
        return str(value)
