import json
import re

from models import AgentAction, PlanStep, TaskPlan


class TaskPlanner:
    """Deterministic task planning and structured action parsing.

    The planner parses structured AgentAction objects and keeps deterministic
    dataset-completion rules. Phase 4 lets the valid tool names come from the
    runtime ToolRegistry rather than a hard-coded global list.
    """

    def __init__(self, valid_tools=None):
        self.valid_tools = set(valid_tools or {"calculator", "database"})

    def set_valid_tools(self, valid_tools):
        self.valid_tools = {str(name).strip().lower() for name in valid_tools}

    ACCOUNT_KEYWORDS = [
        "帳號",
        "賬號",
        "account",
        "username",
        "角色",
        "role",
    ]

    USER_KEYWORDS = [
        "個人資料",
        "個人資訊",
        "使用者資料",
        "使用者資訊",
        "user information",
        "email",
        "電話",
        "phone",
        "姓名",
        "使用者",
    ]

    SENSITIVE_KEYWORDS = [
        "敏感資料",
        "敏感資訊",
        "私人資訊",
        "private information",
        "private_information",
        "地址",
        "個資",
    ]

    VALID_ACTIONS = {"tool", "final"}
    VALID_DATASETS = {"users", "accounts", "sensitive_data"}

    def get_required_datasets(self, user_input):
        text = user_input.lower()
        required = []

        if any(keyword in text for keyword in self.ACCOUNT_KEYWORDS):
            required.append("accounts")

        if any(keyword in text for keyword in self.USER_KEYWORDS):
            required.append("users")

        if any(keyword in text for keyword in self.SENSITIVE_KEYWORDS):
            required.append("sensitive_data")

        if "資料" in text and not required:
            required.append("users")

        return required

    def get_completed_datasets(self, tool_history):
        completed = []

        for record in tool_history:
            if record.get("tool") != "database":
                continue

            if not record.get("success"):
                continue

            # An empty database result is not evidence that the requested
            # dataset requirement was actually satisfied.
            if record.get("result") == []:
                continue

            query = record.get("input", "")
            dataset = query.split("|", 1)[0].strip().lower()

            if dataset not in completed:
                completed.append(dataset)

        return completed

    def get_missing_datasets(self, required_datasets, completed_datasets):
        return [
            dataset
            for dataset in required_datasets
            if dataset not in completed_datasets
        ]

    PLAN_DATASET_ORDER = ("users", "accounts", "sensitive_data")

    def extract_arithmetic_expression(self, user_input):
        """Extract a basic arithmetic expression when arithmetic is intended."""

        text = str(user_input).replace("×", "*").replace("÷", "/")
        lowered = text.lower()
        arithmetic_intent = any(
            keyword in lowered
            for keyword in (
                "計算",
                "算出",
                "多少",
                "等於",
                "calculate",
                "compute",
            )
        )

        compact = text.strip()
        if re.fullmatch(r"[0-9+\-*/().\s]+", compact or ""):
            arithmetic_intent = True

        if not arithmetic_intent:
            return None

        candidates = re.findall(
            r"\d+(?:\.\d+)?(?:\s*[+\-*/]\s*\d+(?:\.\d+)?)+",
            text,
        )
        if not candidates:
            return None

        return max(candidates, key=len).strip()

    def create_task_plan(self, user_input):
        """Build a verifiable first plan for deterministic tool requirements.

        Phase 5 intentionally uses a hybrid planner: known database dependencies
        and arithmetic are planned by Agent Core, while open-ended requests keep
        using the LLM structured-action path.
        """

        required_datasets = self.get_required_datasets(user_input)
        ordered_datasets = [
            dataset
            for dataset in self.PLAN_DATASET_ORDER
            if dataset in required_datasets
        ]

        steps = []
        step_id = 1

        descriptions = {
            "users": "取得使用者個人資料",
            "accounts": "取得使用者帳號資料",
            "sensitive_data": "取得使用者敏感資料",
        }

        for dataset in ordered_datasets:
            steps.append(
                PlanStep(
                    step_id=step_id,
                    description=descriptions[dataset],
                    tool="database",
                    arguments={"dataset": dataset, "filters": {}},
                )
            )
            step_id += 1

        expression = self.extract_arithmetic_expression(user_input)
        if expression:
            steps.append(
                PlanStep(
                    step_id=step_id,
                    description=f"計算 {expression}",
                    tool="calculator",
                    arguments={"expression": expression},
                )
            )

        if not steps:
            return None

        return TaskPlan(goal=str(user_input), steps=steps)

    def parse_action(self, raw_output):
        """Parse one LLM response into a safe AgentAction.

        The normal Phase 2 path is JSON. A small legacy fallback is retained
        only so a local model that ignores the new prompt does not immediately
        break the agent during migration.
        """

        if raw_output is None:
            return AgentAction(action="final")

        text = str(raw_output).strip()
        if not text:
            return AgentAction(action="final")

        parsed = self._extract_json_object(text)
        if isinstance(parsed, dict):
            action = self._action_from_dict(parsed)
            if action is not None:
                return action

        return self._parse_legacy_action(text)

    def _extract_json_object(self, text):
        cleaned = text.strip()

        if cleaned.startswith("```"):
            cleaned = re.sub(r"^```(?:json)?\s*", "", cleaned, flags=re.I)
            cleaned = re.sub(r"\s*```$", "", cleaned)

        decoder = json.JSONDecoder()

        for index, char in enumerate(cleaned):
            if char != "{":
                continue

            try:
                value, _ = decoder.raw_decode(cleaned[index:])
            except json.JSONDecodeError:
                continue

            if isinstance(value, dict):
                return value

        return None

    def _action_from_dict(self, data):
        action_name = str(data.get("action", "")).strip().lower()

        if action_name not in self.VALID_ACTIONS:
            return None

        if action_name == "final":
            answer = data.get("answer")
            if answer is not None:
                answer = str(answer).strip() or None

            return AgentAction(
                action="final",
                answer=answer,
            )

        tool = str(data.get("tool", "")).strip().lower()
        if not tool or tool not in self.valid_tools:
            return None

        arguments = data.get("arguments", {})
        if not isinstance(arguments, dict):
            arguments = {}

        return AgentAction(
            action="tool",
            tool=tool,
            arguments=arguments,
        )

    def _parse_legacy_action(self, text):
        """Temporary compatibility parser for old local-model outputs."""

        for line in text.splitlines():
            line = line.strip()
            if not line:
                continue

            upper = line.upper()

            if upper.startswith("CALCULATE:"):
                expression = line.split(":", 1)[1].strip()
                return AgentAction(
                    action="tool",
                    tool="calculator",
                    arguments={"expression": expression},
                )

            if upper.startswith("DATABASE:"):
                query = line.split(":", 1)[1].strip()
                return self.database_query_to_action(query)

            if upper == "FINAL":
                return AgentAction(action="final")

        return AgentAction(action="final")

    def database_query_to_action(self, query):
        parts = [part.strip() for part in str(query).split("|")]
        dataset = parts[0].lower() if parts else ""
        filters = {}

        for part in parts[1:]:
            if "=" not in part:
                continue

            key, value = part.split("=", 1)
            filters[key.strip().lower()] = value.strip()

        return AgentAction(
            action="tool",
            tool="database",
            arguments={
                "dataset": dataset,
                "filters": filters,
            },
        )

    def action_to_database_query(self, action):
        dataset = str(action.arguments.get("dataset", "")).strip().lower()
        filters = action.arguments.get("filters", {})

        if not isinstance(filters, dict):
            filters = {}

        parts = [dataset]
        for key, value in filters.items():
            if value is None:
                continue
            parts.append(f"{str(key).strip()}={str(value).strip()}")

        return " | ".join(parts)
