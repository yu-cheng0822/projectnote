from dataclasses import dataclass, field
from typing import Any


@dataclass
class AgentAction:
    """A structured decision produced by the Agent planner/LLM."""

    action: str
    tool: str | None = None
    arguments: dict[str, Any] = field(default_factory=dict)
    answer: str | None = None

    def to_dict(self):
        return {
            "action": self.action,
            "tool": self.tool,
            "arguments": self.arguments,
            "answer": self.answer,
        }


@dataclass
class PlanStep:
    """One executable step inside an explicit task plan."""

    step_id: int
    description: str
    tool: str
    arguments: dict[str, Any] = field(default_factory=dict)
    status: str = "PENDING"
    attempts: int = 0
    result: Any = None
    error: str | None = None

    def to_dict(self):
        return {
            "step_id": self.step_id,
            "description": self.description,
            "tool": self.tool,
            "arguments": self.arguments,
            "status": self.status,
            "attempts": self.attempts,
            "result": self.result,
            "error": self.error,
        }


@dataclass
class TaskPlan:
    """A small, inspectable execution plan for one user request."""

    goal: str
    steps: list[PlanStep] = field(default_factory=list)
    status: str = "PLANNED"
    replan_count: int = 0

    def next_pending(self):
        for step in self.steps:
            if step.status == "PENDING":
                return step
        return None

    def mark_running(self, step):
        step.status = "RUNNING"
        step.attempts += 1
        self.status = "RUNNING"

    def mark_completed(self, step, result=None):
        step.status = "COMPLETED"
        step.result = result
        step.error = None
        if self.all_completed():
            self.status = "COMPLETED"

    def mark_failed(self, step, error):
        step.status = "FAILED"
        step.error = str(error)
        self.status = "FAILED"

    def all_completed(self):
        return bool(self.steps) and all(
            step.status == "COMPLETED" for step in self.steps
        )

    def has_failed(self):
        return any(step.status == "FAILED" for step in self.steps)

    def to_dict(self):
        return {
            "goal": self.goal,
            "status": self.status,
            "replan_count": self.replan_count,
            "steps": [step.to_dict() for step in self.steps],
        }

    def to_prompt_context(self):
        if not self.steps:
            return "(no explicit plan)"

        lines = [f"GOAL: {self.goal}", f"PLAN STATUS: {self.status}"]
        for step in self.steps:
            lines.append(
                f"- Step {step.step_id}: [{step.status}] "
                f"{step.tool} - {step.description}"
            )
        return "\n".join(lines)


@dataclass
class ToolResult:
    tool: str
    input: Any
    success: bool
    result: Any

    def to_history_record(self):
        return {
            "tool": self.tool,
            "input": self.input,
            "success": self.success,
            "result": self.result,
        }


@dataclass
class AgentState:
    user_request: str
    required_datasets: list[str] = field(default_factory=list)
    tool_history: list[dict] = field(default_factory=list)
    completed_datasets: list[str] = field(default_factory=list)
    missing_datasets: list[str] = field(default_factory=list)
    current_step: int = 0
    max_tool_calls: int = 5
    status: str = "RUNNING"
    final_answer: str | None = None
    task_plan: TaskPlan | None = None

    def add_tool_result(self, tool_result: ToolResult):
        self.tool_history.append(tool_result.to_history_record())

    def refresh_datasets(self, planner):
        self.completed_datasets = planner.get_completed_datasets(
            self.tool_history
        )

        self.missing_datasets = planner.get_missing_datasets(
            self.required_datasets,
            self.completed_datasets,
        )

    def finish(self, answer):
        self.status = "FINISHED"
        self.final_answer = answer
