import json
import re

from llm import LocalLLM
from tool_manager import ToolManager
from models import AgentAction, AgentState, ToolResult
from planner import TaskPlanner
from memory import ConversationMemory


class Agent:

    def __init__(
        self,
        agent_id="agent_001",
        llm=None,
        tool_manager=None,
        tool_executor=None,
        session_id="session_001",
    ):
        self.agent_id = agent_id
        self.session_id = session_id
        self.llm = llm if llm is not None else LocalLLM()

        # ``tool_executor`` is kept as a temporary compatibility argument for
        # older Phase 1-3 callers. New code should inject ToolManager.
        if tool_manager is not None:
            self.tool_manager = tool_manager
        elif tool_executor is not None:
            self.tool_manager = tool_executor
        else:
            self.tool_manager = ToolManager()

        # Compatibility alias. Agent Core itself uses ``tool_manager`` below.
        self.tool_executor = self.tool_manager

        self.planner = TaskPlanner(
            valid_tools=self.tool_manager.available_tool_names(exposed_only=True)
        )
        self.memory = ConversationMemory(max_turns=8)

    # ==================================================
    # Dataset Planning Helpers
    # ==================================================

    def get_required_datasets(self, user_input):
        return self.planner.get_required_datasets(user_input)

    def get_completed_datasets(self, tool_history):
        return self.planner.get_completed_datasets(tool_history)

    def get_database_records(self, tool_history, dataset):
        records = []

        for record in tool_history:
            if record.get("tool") != "database":
                continue
            if not record.get("success"):
                continue

            query = record.get("input", "")
            current_dataset = query.split("|", 1)[0].strip().lower()

            if current_dataset == dataset:
                result = record.get("result")
                if isinstance(result, list):
                    records.extend(result)

        return records

    def has_successful_query(self, tool_history, query):
        normalized = str(query).strip().lower()

        for record in tool_history:
            if not record.get("success"):
                continue

            old_query = str(record.get("input", "")).strip().lower()
            if old_query == normalized:
                return True

        return False

    # ==================================================
    # Entity / Query Helpers
    # ==================================================

    def extract_person_name(self, user_input):
        known_names = ["alice", "bob", "charlie"]
        text = str(user_input).strip()
        lower_text = text.lower()

        for name in known_names:
            if re.search(rf"\b{re.escape(name)}\b", lower_text):
                return name.capitalize()

        # Support an unseen Latin-script person name so a request such as
        # "請查 David 的個人資料" becomes a filtered query instead of an
        # unsafe broad query over every user.
        stop_words = {
            "user", "users", "account", "accounts", "database",
            "please", "find", "show", "get", "information", "profile",
        }
        for candidate in re.findall(r"\b[A-Z][A-Za-z'-]{1,40}\b", text):
            if candidate.lower() not in stop_words:
                return candidate

        if self.memory.refers_to_active_entity(user_input):
            return self.memory.get_active_name()

        return None

    def extract_user_id(self, user_input):
        match = re.search(r"\bU\d{3}\b", user_input, re.IGNORECASE)
        if match:
            return match.group(0).upper()

        if self.memory.refers_to_active_entity(user_input):
            return self.memory.get_active_user_id()

        return None

    def extract_username(self, user_input):
        person_name = self.extract_person_name(user_input)
        if person_name:
            return person_name.lower()

        if self.memory.refers_to_active_entity(user_input):
            return self.memory.get_active_username()

        return None

    def build_database_query(self, dataset, user_input, tool_history):
        if dataset == "accounts":
            users = self.get_database_records(tool_history, "users")
            if users:
                name = users[0].get("name")
                if name:
                    return "accounts | username=" + str(name).lower()

            username = self.extract_username(user_input)
            if username:
                return "accounts | username=" + username

            return "accounts"

        if dataset == "users":
            accounts = self.get_database_records(tool_history, "accounts")
            if accounts:
                username = accounts[0].get("username")
                if username:
                    return "users | name=" + str(username).capitalize()

            user_id = self.extract_user_id(user_input)
            if user_id:
                return "users | user_id=" + user_id

            name = self.extract_person_name(user_input)
            if name:
                return "users | name=" + name

            return "users"

        if dataset == "sensitive_data":
            users = self.get_database_records(tool_history, "users")
            if users:
                user_id = users[0].get("user_id")
                if user_id:
                    return "sensitive_data | user_id=" + str(user_id)

            user_id = self.extract_user_id(user_input)
            if user_id:
                return "sensitive_data | user_id=" + user_id

            return "sensitive_data"

        return dataset

    def build_database_action(self, dataset, user_input, tool_history):
        query = self.build_database_query(dataset, user_input, tool_history)
        return self.planner.database_query_to_action(query)

    # ==================================================
    # Structured Action Planning
    # ==================================================

    def decide(
        self,
        user_input,
        tool_history=None,
        missing_datasets=None,
        memory_context=None,
    ):
        if tool_history is None:
            tool_history = []
        if missing_datasets is None:
            missing_datasets = []
        if memory_context is None:
            memory_context = self.memory.to_prompt_context()

        history_text = json.dumps(
            tool_history,
            ensure_ascii=False,
            indent=2,
        )

        missing_text = json.dumps(missing_datasets, ensure_ascii=False)
        tool_catalog = self.tool_manager.prompt_catalog()

        # Tool registrations may change at runtime, so refresh the parser's
        # accepted names before every planning step.
        self.planner.set_valid_tools(
            self.tool_manager.available_tool_names(exposed_only=True)
        )

        prompt = f"""
You are the planning component of an autonomous AI assistant.
Choose exactly ONE next action.

Return ONLY one valid JSON object. Do not use Markdown. Do not add explanations.

JSON schema:

For calculator:
{{
  "action": "tool",
  "tool": "calculator",
  "arguments": {{
    "expression": "123 * 456"
  }}
}}

For database:
{{
  "action": "tool",
  "tool": "database",
  "arguments": {{
    "dataset": "users",
    "filters": {{
      "name": "Alice"
    }}
  }}
}}

For a final answer that needs no tool:
{{
  "action": "final",
  "tool": null,
  "arguments": {{}},
  "answer": "Traditional Chinese answer here"
}}

AVAILABLE TOOLS FROM TOOL REGISTRY:
{tool_catalog}

AVAILABLE DATABASE DATASETS:
- users: filters user_id, name
- accounts: filters account_id, username
- sensitive_data: filter user_id

RULES:
1. Use calculator only for real arithmetic.
2. Use database for requests that need database records.
3. Never invent database values.
4. Never use SQL.
5. Query only ONE dataset per action.
6. Do not repeat a successful database query.
7. If MISSING DATASETS is not empty, choose one of those datasets.
8. Do not return final while required data is still missing.
9. For ordinary conversation or knowledge questions that need no tool, return final and put the answer in the answer field.
10. The answer field must be Traditional Chinese when action is final.

USER REQUEST:
{user_input}

TOOL HISTORY:
{history_text}

MISSING DATASETS:
{missing_text}

SESSION MEMORY:
{memory_context}

MEMORY RULES:
- Use SESSION MEMORY only to resolve conversational references such as 她/他/那個人.
- A new explicit name or ID in USER REQUEST overrides the previous active entity.
- Do not invent facts that are not present in USER REQUEST, TOOL HISTORY, or SESSION MEMORY.
"""

        raw_output = self.llm.generate(prompt)
        return self.planner.parse_action(raw_output)

    def validate_action(
        self,
        action,
        user_input,
        missing_datasets,
        tool_history,
    ):
        """Controller-side validation of one structured LLM action."""

        if not isinstance(action, AgentAction):
            action = AgentAction(action="final")

        # Required database information has priority over an invalid/early action.
        if missing_datasets:
            if action.action != "tool" or action.tool != "database":
                return self.build_database_action(
                    missing_datasets[0],
                    user_input,
                    tool_history,
                )

            dataset = str(action.arguments.get("dataset", "")).strip().lower()
            if dataset not in missing_datasets:
                return self.build_database_action(
                    missing_datasets[0],
                    user_input,
                    tool_history,
                )

            # Prefer deterministic identifiers that are already supported by
            # the user request or previous tool results. This prevents the LLM
            # from silently changing Alice -> Bob, U001 -> U002, etc.
            expected_action = self.build_database_action(
                dataset,
                user_input,
                tool_history,
            )
            expected_query = self.planner.action_to_database_query(
                expected_action
            )
            model_query = self.planner.action_to_database_query(action)

            if expected_query != dataset:
                return expected_action

            if model_query == dataset:
                return expected_action

            return action

        if action.action == "tool":
            if not self.tool_manager.has_tool(action.tool, exposed_only=True):
                return AgentAction(action="final")

            if action.tool == "calculator":
                expression = str(action.arguments.get("expression", "")).strip()
                return AgentAction(
                    action="tool",
                    tool="calculator",
                    arguments={"expression": expression},
                )

            if action.tool == "database":
                dataset = str(action.arguments.get("dataset", "")).strip().lower()
                if dataset not in self.planner.VALID_DATASETS:
                    return AgentAction(action="final")
                return action

            # Other exposed tools are validated by their own registered
            # handler. Agent Core only verifies that the tool exists.
            return action

        return action

    # ==================================================
    # Phase 5 Task Plan Helpers
    # ==================================================

    def build_initial_task_plan(self, user_input):
        return self.planner.create_task_plan(user_input)

    def print_task_plan(self, task_plan):
        if task_plan is None:
            return

        print("\n===== Task Plan =====")
        print(json.dumps(task_plan.to_dict(), ensure_ascii=False, indent=2))

    def resolve_plan_step_action(self, plan_step, user_input, tool_history):
        if plan_step.tool == "database":
            dataset = str(plan_step.arguments.get("dataset", "")).strip().lower()
            return self.build_database_action(dataset, user_input, tool_history)

        return AgentAction(
            action="tool",
            tool=plan_step.tool,
            arguments=dict(plan_step.arguments),
        )

    def complete_plan_step(self, task_plan, plan_step, result=None):
        if task_plan is not None and plan_step is not None:
            task_plan.mark_completed(plan_step, result=result)

    def fail_plan_step(self, task_plan, plan_step, error):
        if task_plan is not None and plan_step is not None:
            task_plan.mark_failed(plan_step, error)

    # ==================================================
    # Tool Helpers
    # ==================================================

    def is_valid_calculator_expression(self, expression):
        if not expression:
            return False

        pattern = r"^[0-9+\-*/().\s]+$"
        return bool(re.fullmatch(pattern, expression.strip()))

    def print_action(self, action, step):
        print(f"\n===== Agent Action (Step {step}) =====")
        print(
            json.dumps(
                action.to_dict(),
                ensure_ascii=False,
                indent=2,
            )
        )

    def final_result(self, state, tool=None):
        state.finish(state.final_answer or "")
        self.memory.add_turn(state.user_request, state.final_answer)
        return {
            "decision": "FINAL",
            "tool": tool,
            "tool_history": state.tool_history,
            "task_plan": (
                state.task_plan.to_dict() if state.task_plan is not None else None
            ),
            "answer": state.final_answer,
        }

    def reset_memory(self):
        self.memory.reset()

    # ==================================================
    # Final Answer Generation
    # ==================================================

    def generate_final_answer(self, user_input, tool_history):
        answer_parts = []

        for record in tool_history:
            if record.get("tool") == "calculator" and record.get("success"):
                answer_parts.append(f"計算結果：{record.get('result')}")

        accounts = self.get_database_records(tool_history, "accounts")
        users = self.get_database_records(tool_history, "users")
        sensitive_data = self.get_database_records(tool_history, "sensitive_data")

        if accounts:
            answer_parts.append("帳號資訊：")
            for record in accounts:
                for key, value in record.items():
                    answer_parts.append(f"{key}: {value}")

        if users:
            answer_parts.append("個人資料：")
            for record in users:
                for key, value in record.items():
                    answer_parts.append(f"{key}: {value}")

        if sensitive_data:
            answer_parts.append("敏感資料：")
            for record in sensitive_data:
                for key, value in record.items():
                    answer_parts.append(f"{key}: {value}")

        if answer_parts:
            return "\n".join(answer_parts)

        prompt = f"""
You are a helpful AI assistant.

User request:
{user_input}

Answer in Traditional Chinese.
Do not invent facts.
"""
        return self.llm.generate(prompt).strip()

    # ==================================================
    # Main Agent Loop
    # ==================================================

    def run(self, user_input):
        task_plan = self.build_initial_task_plan(user_input)

        state = AgentState(
            user_request=user_input,
            required_datasets=self.get_required_datasets(user_input),
            max_tool_calls=max(5, (len(task_plan.steps) + 2) if task_plan else 5),
            task_plan=task_plan,
        )

        self.print_task_plan(task_plan)

        for step in range(1, state.max_tool_calls + 1):
            state.current_step = step
            state.refresh_datasets(self.planner)

            # A completed explicit plan has priority over the older dataset-only
            # completion shortcut because a mixed plan may still contain a
            # calculator or another registered tool after database steps.
            if state.task_plan is not None and state.task_plan.all_completed():
                state.final_answer = self.generate_final_answer(
                    user_input,
                    state.tool_history,
                )
                print("\n===== AI Answer =====")
                print(state.final_answer)
                return self.final_result(state)

            if (
                state.task_plan is None
                and state.required_datasets
                and not state.missing_datasets
            ):
                state.final_answer = self.generate_final_answer(
                    user_input,
                    state.tool_history,
                )
                print("\n===== AI Answer =====")
                print(state.final_answer)
                return self.final_result(state)

            plan_step = None
            if state.task_plan is not None:
                plan_step = state.task_plan.next_pending()

                if plan_step is None:
                    if state.task_plan.has_failed():
                        state.final_answer = self.generate_final_answer(
                            user_input,
                            state.tool_history,
                        )
                        if not state.final_answer:
                            state.final_answer = "任務執行失敗，無法完成目前計畫。"
                        print("\n===== AI Answer =====")
                        print(state.final_answer)
                        return self.final_result(state)

                    state.final_answer = self.generate_final_answer(
                        user_input,
                        state.tool_history,
                    )
                    print("\n===== AI Answer =====")
                    print(state.final_answer)
                    return self.final_result(state)

                state.task_plan.mark_running(plan_step)
                action = self.resolve_plan_step_action(
                    plan_step,
                    user_input,
                    state.tool_history,
                )
            else:
                action = self.decide(
                    user_input,
                    state.tool_history,
                    state.missing_datasets,
                    self.memory.to_prompt_context(),
                )

            action = self.validate_action(
                action,
                user_input,
                state.missing_datasets,
                state.tool_history,
            )

            self.print_action(action, step)

            # ====================================
            # FINAL
            # ====================================
            if action.action == "final":
                state.final_answer = action.answer or self.generate_final_answer(
                    user_input,
                    state.tool_history,
                )

                print("\n===== AI Answer =====")
                print(state.final_answer)
                return self.final_result(state)

            # ====================================
            # CALCULATOR
            # ====================================
            if action.tool == "calculator":
                expression = str(
                    action.arguments.get("expression", "")
                ).strip()

                if not self.is_valid_calculator_expression(expression):
                    self.fail_plan_step(
                        state.task_plan,
                        plan_step,
                        "invalid_expression",
                    )
                    state.final_answer = (
                        "無法執行這個計算要求，因為輸入不是有效的數學運算式。"
                    )
                    print("\n===== AI Answer =====")
                    print(state.final_answer)
                    return self.final_result(state, tool="calculator")

                success, result = self.tool_manager.execute(
                    "calculator",
                    {"expression": expression},
                )

                state.add_tool_result(
                    ToolResult(
                        tool="calculator",
                        input=expression,
                        success=success,
                        result=result,
                    )
                )

                print("\n===== Tool Result =====")
                print("Tool: calculator")
                print("Success:", success)
                print("Result:", result)

                if success:
                    self.complete_plan_step(
                        state.task_plan,
                        plan_step,
                        result=result,
                    )
                    if state.task_plan is not None:
                        continue
                    state.final_answer = f"計算結果：{result}"
                else:
                    self.fail_plan_step(
                        state.task_plan,
                        plan_step,
                        result,
                    )
                    state.final_answer = f"計算失敗：{result}"

                print("\n===== AI Answer =====")
                print(state.final_answer)
                return self.final_result(state, tool="calculator")

            # ====================================
            # DATABASE
            # ====================================
            if action.tool == "database":
                query = self.planner.action_to_database_query(action)

                if self.has_successful_query(state.tool_history, query):
                    if plan_step is not None:
                        self.complete_plan_step(
                            state.task_plan,
                            plan_step,
                            result="already_completed",
                        )
                        continue

                    if state.missing_datasets:
                        action = self.build_database_action(
                            state.missing_datasets[0],
                            user_input,
                            state.tool_history,
                        )
                        query = self.planner.action_to_database_query(action)

                    if self.has_successful_query(state.tool_history, query):
                        state.final_answer = self.generate_final_answer(
                            user_input,
                            state.tool_history,
                        )
                        print("\n===== AI Answer =====")
                        print(state.final_answer)
                        return self.final_result(state)

                success, result = self.tool_manager.execute(
                    "database",
                    action.arguments,
                )

                # A successful call that found no records did not satisfy the
                # information goal, so record it as an execution failure for the
                # plan instead of treating the dataset as completed.
                effective_success = success and result != []
                history_result = result if effective_success else (
                    "no_matching_records" if success and result == [] else result
                )

                state.add_tool_result(
                    ToolResult(
                        tool="database",
                        input=query,
                        success=effective_success,
                        result=history_result,
                    )
                )

                if effective_success:
                    self.memory.observe_database_result(query, result)

                print("\n===== Tool Result =====")
                print("Tool: database")
                print("Success:", effective_success)
                print("Result:", history_result)

                if not effective_success:
                    self.fail_plan_step(
                        state.task_plan,
                        plan_step,
                        history_result,
                    )
                    state.final_answer = f"資料查詢失敗：{history_result}"
                    print("\n===== AI Answer =====")
                    print(state.final_answer)
                    return self.final_result(state, tool="database")

                self.complete_plan_step(
                    state.task_plan,
                    plan_step,
                    result=result,
                )

                if state.task_plan is not None:
                    continue

                # If the model selected a database tool for a request not caught
                # by the deterministic dataset detector, return the evidence now.
                if not state.required_datasets:
                    state.final_answer = self.generate_final_answer(
                        user_input,
                        state.tool_history,
                    )
                    print("\n===== AI Answer =====")
                    print(state.final_answer)
                    return self.final_result(state, tool="database")

                continue

            # ====================================
            # OTHER REGISTERED TOOL
            # ====================================
            if self.tool_manager.has_tool(action.tool, exposed_only=True):
                history_input = self.tool_manager.normalize_input(
                    action.tool,
                    action.arguments,
                )
                success, result = self.tool_manager.execute(
                    action.tool,
                    action.arguments,
                )

                state.add_tool_result(
                    ToolResult(
                        tool=action.tool,
                        input=history_input,
                        success=success,
                        result=result,
                    )
                )

                print("\n===== Tool Result =====")
                print("Tool:", action.tool)
                print("Success:", success)
                print("Result:", result)

                if success:
                    self.complete_plan_step(
                        state.task_plan,
                        plan_step,
                        result=result,
                    )
                    if state.task_plan is not None:
                        continue
                    state.final_answer = f"工具 {action.tool} 執行結果：{result}"
                else:
                    self.fail_plan_step(
                        state.task_plan,
                        plan_step,
                        result,
                    )
                    state.final_answer = f"工具 {action.tool} 執行失敗：{result}"

                print("\n===== AI Answer =====")
                print(state.final_answer)
                return self.final_result(state, tool=action.tool)

        state.final_answer = self.generate_final_answer(
            user_input,
            state.tool_history,
        )
        print("\n===== AI Answer =====")
        print(state.final_answer)
        return self.final_result(state)


if __name__ == "__main__":
    print("Please run ProtectedAgent through main.py")
