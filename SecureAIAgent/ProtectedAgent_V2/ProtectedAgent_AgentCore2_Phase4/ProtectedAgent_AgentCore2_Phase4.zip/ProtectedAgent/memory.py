from dataclasses import dataclass, field
from typing import Any


@dataclass
class ConversationTurn:
    user: str
    assistant: str

    def to_dict(self):
        return {
            "user": self.user,
            "assistant": self.assistant,
        }


@dataclass
class EntityMemory:
    """Small working-memory record for the currently referenced person."""

    name: str | None = None
    user_id: str | None = None
    username: str | None = None
    account_id: str | None = None
    facts: dict[str, Any] = field(default_factory=dict)

    def update(self, values):
        if not isinstance(values, dict):
            return

        for key in ("name", "user_id", "username", "account_id"):
            value = values.get(key)
            if value is not None and str(value).strip():
                setattr(self, key, str(value).strip())

        self.facts.update(values)

    def to_dict(self):
        return {
            "name": self.name,
            "user_id": self.user_id,
            "username": self.username,
            "account_id": self.account_id,
            "facts": dict(self.facts),
        }


class ConversationMemory:
    """Session-scoped memory for ProtectedAgent.

    Phase 3 intentionally keeps memory in RAM only. It is cleared whenever the
    Agent object is recreated, so this is conversation memory rather than
    persistent/long-term storage.
    """

    REFERENCE_WORDS = (
        "她",
        "他",
        "她的",
        "他的",
        "這個人",
        "這位",
        "那個人",
        "那位",
        "this person",
        "that person",
        "their",
        "her",
        "his",
    )

    def __init__(self, max_turns=8):
        self.max_turns = max(1, int(max_turns))
        self.turns: list[ConversationTurn] = []
        self.active_entity = EntityMemory()
        self.dataset_facts: dict[str, list[dict[str, Any]]] = {}

    def reset(self):
        self.turns.clear()
        self.active_entity = EntityMemory()
        self.dataset_facts.clear()

    def add_turn(self, user, assistant):
        self.turns.append(
            ConversationTurn(
                user=str(user),
                assistant=str(assistant),
            )
        )

        if len(self.turns) > self.max_turns:
            self.turns = self.turns[-self.max_turns :]

    def refers_to_active_entity(self, text):
        lowered = str(text).lower()
        return any(word.lower() in lowered for word in self.REFERENCE_WORDS)

    def get_active_name(self):
        return self.active_entity.name

    def get_active_user_id(self):
        return self.active_entity.user_id

    def get_active_username(self):
        return self.active_entity.username

    def observe_database_result(self, query, result):
        """Learn deterministic identifiers from successful database evidence."""

        if not isinstance(result, list) or not result:
            return

        parts = [part.strip() for part in str(query).split("|")]
        dataset = parts[0].lower() if parts else ""
        filters = {}

        for part in parts[1:]:
            if "=" not in part:
                continue
            key, value = part.split("=", 1)
            filters[key.strip().lower()] = value.strip()

        records = [item for item in result if isinstance(item, dict)]
        if not records:
            return

        self.dataset_facts[dataset] = [dict(item) for item in records]

        # Only change the active referent for an unambiguous result. A query
        # returning every user/account should not silently make its first row
        # the person referenced by "她/他" in a later turn.
        if len(records) != 1:
            return

        record = records[0]

        if dataset == "users":
            self.active_entity.update(record)
            if self.active_entity.name and not self.active_entity.username:
                self.active_entity.username = self.active_entity.name.lower()
            return

        if dataset == "accounts":
            username = record.get("username") or filters.get("username")

            # If an active person already exists, attach the account only when
            # its username is consistent with that person. Otherwise the
            # account itself becomes the best available referent.
            active_name = self.active_entity.name
            if active_name and username:
                if str(username).lower() == str(active_name).lower():
                    self.active_entity.update(record)
                    return

            self.active_entity.update(record)
            if username and not self.active_entity.name:
                self.active_entity.name = str(username).capitalize()
            return

        if dataset == "sensitive_data":
            record_user_id = record.get("user_id") or filters.get("user_id")
            active_user_id = self.active_entity.user_id

            if active_user_id and record_user_id:
                if str(active_user_id).lower() == str(record_user_id).lower():
                    self.active_entity.update(record)
                    return

            # Keep useful evidence, but do not invent a person's name from a
            # user ID when no prior identity link has been established.
            self.active_entity.update(record)

    def to_prompt_context(self):
        lines = []

        if any(
            value
            for value in (
                self.active_entity.name,
                self.active_entity.user_id,
                self.active_entity.username,
                self.active_entity.account_id,
            )
        ):
            lines.append("ACTIVE ENTITY:")
            if self.active_entity.name:
                lines.append(f"- name: {self.active_entity.name}")
            if self.active_entity.user_id:
                lines.append(f"- user_id: {self.active_entity.user_id}")
            if self.active_entity.username:
                lines.append(f"- username: {self.active_entity.username}")
            if self.active_entity.account_id:
                lines.append(f"- account_id: {self.active_entity.account_id}")

        if self.turns:
            lines.append("RECENT CONVERSATION:")
            for turn in self.turns:
                lines.append(f"User: {turn.user}")
                lines.append(f"Assistant: {turn.assistant}")

        if not lines:
            return "(empty)"

        return "\n".join(lines)
