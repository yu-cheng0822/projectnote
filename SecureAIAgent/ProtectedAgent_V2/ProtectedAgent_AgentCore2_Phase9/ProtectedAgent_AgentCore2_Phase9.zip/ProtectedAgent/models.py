from dataclasses import dataclass, field
from typing import Any


@dataclass
class AgentAction:
    """A structured decision produced by the Agent planner/LLM."""

    action: str
    tool: str | None = None
    arguments: dict[str, Any] = field(default_factory=dict)
    answer: str | None = None

    def to_dict(self):
        return {
            "action": self.action,
            "tool": self.tool,
            "arguments": self.arguments,
            "answer": self.answer,
        }


@dataclass
class RecoveryDecision:
    """One bounded replanning decision after a plan step fails."""

    strategy: str
    reason: str
    error: str | None = None
    new_arguments: dict[str, Any] | None = None
    prerequisite_steps: list[dict[str, Any]] = field(default_factory=list)

    def to_dict(self):
        return {
            "strategy": self.strategy,
            "reason": self.reason,
            "error": self.error,
            "new_arguments": self.new_arguments,
            "prerequisite_steps": list(self.prerequisite_steps),
        }


@dataclass
class PlanStep:
    """One executable step inside an explicit task plan."""

    step_id: int
    description: str
    tool: str
    arguments: dict[str, Any] = field(default_factory=dict)
    status: str = "PENDING"
    attempts: int = 0
    result: Any = None
    error: str | None = None
    include_in_answer: bool = True
    origin: str = "initial"
    depends_on: list[int] = field(default_factory=list)

    def to_dict(self):
        return {
            "step_id": self.step_id,
            "description": self.description,
            "tool": self.tool,
            "arguments": self.arguments,
            "status": self.status,
            "attempts": self.attempts,
            "result": self.result,
            "error": self.error,
            "include_in_answer": self.include_in_answer,
            "origin": self.origin,
            "depends_on": list(self.depends_on),
        }


@dataclass
class TaskPlan:
    """A small, inspectable execution plan for one user request."""

    goal: str
    steps: list[PlanStep] = field(default_factory=list)
    status: str = "PLANNED"
    replan_count: int = 0
    source: str = "deterministic"

    def next_pending(self):
        for step in self.steps:
            if step.status in {"PENDING", "RETRY_PENDING"}:
                return step
        return None

    def mark_running(self, step):
        step.status = "RUNNING"
        step.attempts += 1
        self.status = "RUNNING"

    def mark_completed(self, step, result=None):
        step.status = "COMPLETED"
        step.result = result
        step.error = None
        if self.all_completed():
            self.status = "COMPLETED"

    def mark_failed(self, step, error):
        step.status = "FAILED"
        step.error = str(error)
        self.status = "FAILED"

    def schedule_retry(self, step, error, new_arguments=None):
        step.status = "RETRY_PENDING"
        step.error = str(error)
        if new_arguments is not None:
            step.arguments = dict(new_arguments)
        self.replan_count += 1
        self.status = "REPLANNING"

    def insert_prerequisites(self, step, new_steps, error=None):
        """Insert supporting steps immediately before the blocked step.

        The blocked step is returned to PENDING so it can be resolved again
        after the newly inserted evidence-producing steps complete. The
        original RUNNING transition is planning work rather than a real tool
        execution, so its attempt counter is rolled back by one.
        """

        if step not in self.steps:
            return False

        prepared = []
        for item in new_steps:
            if isinstance(item, PlanStep):
                prepared.append(item)
                continue

            if not isinstance(item, dict):
                continue

            prepared.append(
                PlanStep(
                    step_id=0,
                    description=str(item.get("description", "替代前置步驟")),
                    tool=str(item.get("tool", "")).strip().lower(),
                    arguments=dict(item.get("arguments", {})),
                    include_in_answer=bool(item.get("include_in_answer", False)),
                    origin=str(item.get("origin", "replan")),
                )
            )

        if not prepared:
            return False

        index = self.steps.index(step)
        self.steps[index:index] = prepared

        step.status = "PENDING"
        step.error = str(error) if error is not None else None
        step.attempts = max(0, step.attempts - 1)

        self.replan_count += 1
        self.status = "REPLANNING"
        self._renumber_steps()
        return True

    def _renumber_steps(self):
        for index, item in enumerate(self.steps, start=1):
            item.step_id = index

    def all_completed(self):
        return bool(self.steps) and all(
            step.status == "COMPLETED" for step in self.steps
        )

    def has_failed(self):
        return any(step.status == "FAILED" for step in self.steps)

    def to_dict(self):
        return {
            "goal": self.goal,
            "status": self.status,
            "replan_count": self.replan_count,
            "source": self.source,
            "steps": [step.to_dict() for step in self.steps],
        }

    def to_prompt_context(self):
        if not self.steps:
            return "(no explicit plan)"

        lines = [
            f"GOAL: {self.goal}",
            f"PLAN SOURCE: {self.source}",
            f"PLAN STATUS: {self.status}",
        ]
        for step in self.steps:
            lines.append(
                f"- Step {step.step_id}: [{step.status}] "
                f"{step.tool} - {step.description}"
            )
        return "\n".join(lines)


@dataclass
class ToolResult:
    tool: str
    input: Any
    success: bool
    result: Any
    include_in_answer: bool = True

    def to_history_record(self):
        return {
            "tool": self.tool,
            "input": self.input,
            "success": self.success,
            "result": self.result,
            "include_in_answer": self.include_in_answer,
        }


@dataclass
class AgentState:
    user_request: str
    required_datasets: list[str] = field(default_factory=list)
    tool_history: list[dict] = field(default_factory=list)
    completed_datasets: list[str] = field(default_factory=list)
    missing_datasets: list[str] = field(default_factory=list)
    current_step: int = 0
    max_tool_calls: int = 5
    status: str = "RUNNING"
    final_answer: str | None = None
    task_plan: TaskPlan | None = None
    recovery_history: list[dict] = field(default_factory=list)
    execution_trace: Any = None

    def add_tool_result(self, tool_result: ToolResult):
        self.tool_history.append(tool_result.to_history_record())

    def refresh_datasets(self, planner):
        self.completed_datasets = planner.get_completed_datasets(
            self.tool_history
        )

        self.missing_datasets = planner.get_missing_datasets(
            self.required_datasets,
            self.completed_datasets,
        )

    def finish(self, answer):
        self.status = "FINISHED"
        self.final_answer = answer
