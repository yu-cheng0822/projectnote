from models import RecoveryDecision


class FailureRecoveryPlanner:
    """Bounded, inspectable failure recovery for explicit TaskPlan steps.

    Phase 6 intentionally starts with deterministic recovery rules. Tool
    failures that may be transient are retried a limited number of times.
    Semantic/input failures that will not improve by repeating the same call
    are stopped immediately. This avoids infinite retry loops and makes every
    recovery decision visible in the task plan.
    """

    NON_RETRYABLE_ERRORS = {
        "no_matching_records",
        "invalid_expression",
        "missing_database_query",
        "unknown_database_query",
        "unknown_tool",
    }

    NON_RETRYABLE_PREFIXES = (
        "invalid_",
        "missing_",
        "unknown_",
    )

    def __init__(self, max_attempts_per_step=2, max_replans=3):
        self.max_attempts_per_step = max(1, int(max_attempts_per_step))
        self.max_replans = max(0, int(max_replans))

    def decide(self, task_plan, plan_step, error):
        error_text = str(error or "tool_failure").strip()
        normalized = error_text.lower()

        if self._is_non_retryable(normalized):
            return RecoveryDecision(
                strategy="abort",
                reason=(
                    "錯誤屬於重試無法改善的結果，停止此步驟以避免無限重試。"
                ),
                error=error_text,
            )

        if task_plan is None or plan_step is None:
            return RecoveryDecision(
                strategy="abort",
                reason="目前不是可重新規劃的 TaskPlan 步驟。",
                error=error_text,
            )

        if task_plan.replan_count >= self.max_replans:
            return RecoveryDecision(
                strategy="abort",
                reason="已達整體重新規劃次數上限。",
                error=error_text,
            )

        if plan_step.attempts >= self.max_attempts_per_step:
            return RecoveryDecision(
                strategy="abort",
                reason="此步驟已達最大嘗試次數。",
                error=error_text,
            )

        return RecoveryDecision(
            strategy="retry",
            reason="工具執行錯誤可能是暫時性的，重新執行目前計畫步驟。",
            error=error_text,
            new_arguments=None,
        )

    def _is_non_retryable(self, normalized_error):
        if normalized_error in self.NON_RETRYABLE_ERRORS:
            return True
        return normalized_error.startswith(self.NON_RETRYABLE_PREFIXES)
