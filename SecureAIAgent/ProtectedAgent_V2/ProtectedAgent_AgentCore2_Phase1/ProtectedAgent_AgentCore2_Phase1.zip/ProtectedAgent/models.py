from dataclasses import dataclass, field
from typing import Any


@dataclass
class ToolResult:
    tool: str
    input: Any
    success: bool
    result: Any

    def to_history_record(self):
        return {
            "tool": self.tool,
            "input": self.input,
            "success": self.success,
            "result": self.result,
        }


@dataclass
class AgentState:
    user_request: str
    required_datasets: list[str] = field(default_factory=list)
    tool_history: list[dict] = field(default_factory=list)
    completed_datasets: list[str] = field(default_factory=list)
    missing_datasets: list[str] = field(default_factory=list)
    current_step: int = 0
    max_tool_calls: int = 5
    status: str = "RUNNING"
    final_answer: str | None = None

    def add_tool_result(self, tool_result: ToolResult):
        self.tool_history.append(
            tool_result.to_history_record()
        )

    def refresh_datasets(self, planner):
        self.completed_datasets = planner.get_completed_datasets(
            self.tool_history
        )

        self.missing_datasets = planner.get_missing_datasets(
            self.required_datasets,
            self.completed_datasets,
        )

    def finish(self, answer):
        self.status = "FINISHED"
        self.final_answer = answer
