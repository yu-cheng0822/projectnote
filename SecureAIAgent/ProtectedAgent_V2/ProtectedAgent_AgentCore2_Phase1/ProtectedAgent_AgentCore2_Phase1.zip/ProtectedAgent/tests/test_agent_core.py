import sys
from pathlib import Path

PROJECT_DIR = Path(__file__).resolve().parents[1]
if str(PROJECT_DIR) not in sys.path:
    sys.path.insert(0, str(PROJECT_DIR))

from agent import Agent


class QueueLLM:
    def __init__(self, outputs):
        self.outputs = iter(outputs)

    def generate(self, prompt):
        try:
            return next(self.outputs)
        except StopIteration:
            return "FINAL"


def test_calculator_flow():
    agent = Agent(
        llm=QueueLLM([
            "CALCULATE: 123 * 456"
        ])
    )

    result = agent.run(
        "123 * 456 是多少？"
    )

    assert result["answer"] == "計算結果：56088"
    assert result["tool_history"][0]["result"] == 56088


def test_alice_accounts_and_profile_flow():
    agent = Agent(
        llm=QueueLLM([
            "DATABASE: accounts | username=alice",
            "DATABASE: users | name=Alice",
        ])
    )

    result = agent.run(
        "請查 Alice 的帳號和個人資料"
    )

    assert len(result["tool_history"]) == 2
    assert result["tool_history"][0]["input"] == "accounts | username=alice"
    assert result["tool_history"][1]["input"] == "users | name=Alice"
    assert "account_id: A001" in result["answer"]
    assert "user_id: U001" in result["answer"]


if __name__ == "__main__":
    test_calculator_flow()
    test_alice_accounts_and_profile_flow()
    print("Agent Core 2.0 tests passed.")
