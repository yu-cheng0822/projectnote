class TaskPlanner:
    """Small deterministic planning layer for the current Agent Core.

    This first version only decides which database datasets are required
    and which ones are still missing. LLM action selection remains in
    agent.py for now so the refactor stays backward-compatible.
    """

    ACCOUNT_KEYWORDS = [
        "帳號",
        "賬號",
        "account",
        "username",
        "角色",
        "role",
    ]

    USER_KEYWORDS = [
        "個人資料",
        "個人資訊",
        "使用者資料",
        "使用者資訊",
        "user information",
        "email",
        "電話",
        "phone",
        "姓名",
        "使用者",
    ]

    SENSITIVE_KEYWORDS = [
        "敏感資料",
        "敏感資訊",
        "私人資訊",
        "private information",
        "private_information",
        "地址",
        "個資",
    ]

    def get_required_datasets(self, user_input):
        text = user_input.lower()
        required = []

        if any(keyword in text for keyword in self.ACCOUNT_KEYWORDS):
            required.append("accounts")

        if any(keyword in text for keyword in self.USER_KEYWORDS):
            required.append("users")

        if any(keyword in text for keyword in self.SENSITIVE_KEYWORDS):
            required.append("sensitive_data")

        if "資料" in text and not required:
            required.append("users")

        return required

    def get_completed_datasets(self, tool_history):
        completed = []

        for record in tool_history:
            if record.get("tool") != "database":
                continue

            if not record.get("success"):
                continue

            query = record.get("input", "")
            dataset = query.split("|", 1)[0].strip().lower()

            if dataset not in completed:
                completed.append(dataset)

        return completed

    def get_missing_datasets(self, required_datasets, completed_datasets):
        return [
            dataset
            for dataset in required_datasets
            if dataset not in completed_datasets
        ]
