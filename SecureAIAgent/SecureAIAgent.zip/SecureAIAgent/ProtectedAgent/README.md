# ProtectedAgent v1.0.2

ProtectedAgent is the independently runnable AI Agent in the SecureAIAgent project.
It does not import or depend on SecurityArchitecture.

## Default LLM backend

v1.0.2 uses **llama.cpp only** as its built-in LLM backend through llama.cpp's OpenAI-compatible HTTP server.

Start llama.cpp first, then run:

```bat
python ProtectedAgent\main.py
```

See `docs/LLAMA_CPP_SETUP.md` for the Windows setup and model examples.

## v1.0.2 changes

- Fixed `(25 + 75) / 4` being incorrectly extracted as `25 + 75`.
- `LlamaCppLLM` is the only built-in LLM provider.
- Removed the previous alternate local-provider implementation and its compatibility exports.
- Added T01/T03 regression coverage.
- Full regression status: **18/18 PASS**.

## Runtime environment

- Python 3.14.x
- Windows / Visual Studio Code supported
- Local LLM backend: `LlamaCppLLM` connected to llama.cpp (`http://127.0.0.1:8080/v1` by default)
- Persistent memory: Python standard-library SQLite

## Quick start

From the `SecureAIAgent` project root:

```bat
python ProtectedAgent\main.py
```

Full regression suite:

```bat
python ProtectedAgent\tests\run_all_tests.py
```

## Stable v1 public API

Prefer package-level imports for integrations:

```python
from ProtectedAgent import (
    Agent,
    ToolManager,
    ToolDefinition,
    RuntimeLimits,
    BaseToolExecutionHook,
    ToolHookDecision,
)
```

The stable integration surfaces are:

- `Agent` / `create_agent()`
- `ToolManager`
- `ToolRegistry` / `ToolDefinition`
- `RuntimeLimits`
- `MemoryPolicy`
- Trace observers (`Agent.add_trace_observer`)
- Tool execution hooks (`ToolManager.add_hook`)

Planner, replanner, internal state models, and memory implementation classes are internal implementation details and are not part of the v1 compatibility promise.

## High-level architecture

```text
User
  |
  v
Agent Core
  |-- Context Retrieval / Memory
  |-- Task Planner / Generic Planner / Goal Decomposer
  |-- Task Plan + Replanning
  |-- Goal Completion Evaluation
  |
  v
ToolManager  <---- generic before/after Tool Hooks
  |
  v
ToolRegistry
  |
  v
Registered Tools

Agent Core ----> Execution Trace ----> generic Trace Observers
```

The two generic extension points (`Tool Hook` and `Trace Observer`) have no dependency on `SecurityArchitecture`.

## Built-in tools

- `calculator`: read-only arithmetic
- `database`: read-only demo data query
- legacy `file` / `recovery` placeholders remain registered but are not exposed to the planner

New tools should be registered with `ToolDefinition` and include input/output schemas, capabilities, side effects, and planner metadata.

See `docs/PUBLIC_API.md` and `docs/ARCHITECTURE.md` for details.
