import json
import re

try:
    from .models import PlanStep, TaskPlan
except ImportError:
    from models import PlanStep, TaskPlan


class GoalDecomposer:
    """LLM-assisted decomposition for compound goals not covered by rules.

    The existing deterministic planner remains authoritative for database and
    calculator requests it already understands. This component is only used
    for compound/open-ended requests where a multi-step plan can add value.
    """

    COMPOUND_MARKERS = (
        "先", "再", "然後", "接著", "最後", "並且", "同時", "之後",
        "and then", " then ", "after that", "finally",
    )

    MAX_STEPS = 8

    def __init__(self, llm, planner, tool_manager):
        self.llm = llm
        self.planner = planner
        self.tool_manager = tool_manager

    def should_decompose(self, user_input, deterministic_plan=None):
        text = str(user_input).strip().lower()
        tool_names = self.tool_manager.available_tool_names(exposed_only=True)
        named_tools = [name for name in tool_names if name.lower() in text]
        has_compound_marker = any(marker in text for marker in self.COMPOUND_MARKERS)
        mentions_non_core_tool = any(
            name not in {"calculator", "database"} for name in named_tools
        )

        # If the deterministic planner already fully understands the request,
        # keep it. LLM decomposition is mainly for open-ended/custom-tool goals.
        if deterministic_plan is not None and not mentions_non_core_tool:
            return False

        if len(named_tools) >= 2:
            return True

        if has_compound_marker and (
            deterministic_plan is None or mentions_non_core_tool
        ):
            return True

        return False

    def decompose(self, user_input, memory_context="(empty)"):
        self.planner.set_valid_tools(
            self.tool_manager.available_tool_names(exposed_only=True)
        )

        tool_catalog = self.tool_manager.prompt_catalog()
        prompt = f"""
You are the goal-decomposition component of an autonomous AI assistant.
Break the user's compound goal into a SMALL ordered list of executable tool steps.

Return ONLY one valid JSON object. No Markdown. No explanations.

Schema:
{{
  "goal": "short goal summary",
  "steps": [
    {{
      "description": "what this step accomplishes",
      "tool": "registered_tool_name",
      "arguments": {{}},
      "depends_on": [],
      "include_in_answer": true
    }}
  ]
}}

AVAILABLE TOOLS:
{tool_catalog}

DATABASE DATASETS:
- users: filters user_id, name
- accounts: filters account_id, username
- sensitive_data: filter user_id

REFERENCE SYNTAX FOR LATER STEPS:
If a later tool argument depends on an earlier result, use an exact reference like:
{{{{step:1.result.name}}}}
{{{{step:1.result.0.user_id}}}}
The referenced step must be earlier than the current step.

RULES:
1. Use only tools listed in AVAILABLE TOOLS.
2. Create at most {self.MAX_STEPS} steps.
3. Do not invent facts or tool results.
4. Do not create a step for ordinary final wording; final response generation happens after tools finish.
5. Use include_in_answer=false for supporting/intermediate steps whose raw result should not be shown directly.
6. If the request does not actually need multiple tool steps, return an empty steps list.
7. Keep arguments consistent with the tool input schema.
8. For database, query only one dataset per step and never use SQL.

USER REQUEST:
{user_input}

SESSION MEMORY:
{memory_context}
"""
        raw = self.llm.generate(prompt)
        return self.parse_plan(raw, fallback_goal=str(user_input))

    def parse_plan(self, raw_output, fallback_goal=""):
        payload = self._extract_json_object(raw_output)
        if not isinstance(payload, dict):
            return None

        steps_data = payload.get("steps")
        if not isinstance(steps_data, list) or not steps_data:
            return None

        valid_tools = set(
            self.tool_manager.available_tool_names(exposed_only=True)
        )
        steps = []

        for index, item in enumerate(steps_data[: self.MAX_STEPS], start=1):
            if not isinstance(item, dict):
                return None

            tool = str(item.get("tool", "")).strip().lower()
            if tool not in valid_tools:
                return None

            arguments = item.get("arguments", {})
            if not isinstance(arguments, dict):
                return None

            if tool == "database":
                dataset = str(arguments.get("dataset", "")).strip().lower()
                if dataset not in self.planner.VALID_DATASETS:
                    return None

            depends_on = item.get("depends_on", [])
            if not isinstance(depends_on, list):
                depends_on = []

            normalized_dependencies = []
            for dependency in depends_on:
                try:
                    dependency_id = int(dependency)
                except (TypeError, ValueError):
                    return None
                if dependency_id < 1 or dependency_id >= index:
                    return None
                if dependency_id not in normalized_dependencies:
                    normalized_dependencies.append(dependency_id)

            description = str(
                item.get("description") or f"執行 {tool}"
            ).strip()

            steps.append(
                PlanStep(
                    step_id=index,
                    description=description,
                    tool=tool,
                    arguments=dict(arguments),
                    include_in_answer=bool(item.get("include_in_answer", True)),
                    origin="llm_decomposition",
                    depends_on=normalized_dependencies,
                )
            )

        if not steps:
            return None

        goal = str(payload.get("goal") or fallback_goal).strip()
        return TaskPlan(
            goal=goal,
            steps=steps,
            source="llm_decomposition",
        )

    def _extract_json_object(self, raw_output):
        if raw_output is None:
            return None

        text = str(raw_output).strip()
        if not text:
            return None

        if text.startswith("```"):
            text = re.sub(r"^```(?:json)?\s*", "", text, flags=re.I)
            text = re.sub(r"\s*```$", "", text)

        decoder = json.JSONDecoder()
        for index, char in enumerate(text):
            if char != "{":
                continue
            try:
                value, _ = decoder.raw_decode(text[index:])
            except json.JSONDecodeError:
                continue
            if isinstance(value, dict):
                return value
        return None
