# ProtectedAgent Release Notes

## v1.0.2

### Changed

- Simplified the LLM layer to llama.cpp only.
- `LlamaCppLLM` is now the sole built-in LLM provider and public LLM provider export.
- Removed the previous alternate provider implementation and compatibility alias.
- Kept the v1.0.1 parenthesized-arithmetic fix and T01/T03 regression coverage.

### Validation

- Full regression suite: 18/18 test files passed.

## v1.0.0

- First frozen ProtectedAgent v1 public interface.
- Structured actions, planning, replanning, memory, persistent memory,
  context retrieval, generic tool planning, execution trace, runtime guards,
  Tool Hooks and Trace Observers.
