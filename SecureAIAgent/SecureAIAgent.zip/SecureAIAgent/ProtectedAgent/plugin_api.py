from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Protocol, runtime_checkable


@dataclass
class ToolExecutionRequest:
    """Normalized request exposed to generic tool-execution hooks.

    The request intentionally contains only ProtectedAgent concepts. External
    plugins may inspect or transform the request without Agent Core importing
    or depending on the plugin implementation.
    """

    tool_name: str
    arguments: Any
    metadata: dict[str, Any] = field(default_factory=dict)
    context: dict[str, Any] = field(default_factory=dict)

    def to_dict(self):
        return {
            "tool_name": self.tool_name,
            "arguments": self.arguments,
            "metadata": dict(self.metadata),
            "context": dict(self.context),
        }


@dataclass
class ToolHookDecision:
    """Decision returned by a hook before a tool handler is invoked."""

    proceed: bool = True
    arguments: Any = None
    reason: str | None = None


@dataclass
class ToolExecutionOutcome:
    """Normalized result delivered to hooks after execution or interception."""

    success: bool
    result: Any
    blocked: bool = False
    reason: str | None = None

    def to_dict(self):
        return {
            "success": self.success,
            "result": self.result,
            "blocked": self.blocked,
            "reason": self.reason,
        }


@runtime_checkable
class ToolExecutionHook(Protocol):
    """Public v1 hook contract for external tool-boundary plugins.

    Implement either or both methods. Hook exceptions are isolated by
    ToolManager and cannot crash normal Agent execution.
    """

    def before_tool(self, request: ToolExecutionRequest) -> ToolHookDecision | None:
        ...

    def after_tool(
        self,
        request: ToolExecutionRequest,
        outcome: ToolExecutionOutcome,
    ) -> None:
        ...


class BaseToolExecutionHook:
    """Convenience base class for plugins that only need one hook method."""

    def before_tool(self, request):
        return None

    def after_tool(self, request, outcome):
        return None


__all__ = [
    "ToolExecutionRequest",
    "ToolHookDecision",
    "ToolExecutionOutcome",
    "ToolExecutionHook",
    "BaseToolExecutionHook",
]
