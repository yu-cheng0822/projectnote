"""ProtectedAgent v1.0 public API.

External integrations should prefer importing from this module (or directly
from the ``ProtectedAgent`` package) instead of importing internal planner,
memory, or replanning modules.
"""

from .agent import Agent
from .llm import LLMProviderError, LlamaCppLLM
from .memory_policy import MemoryPolicy
from .plugin_api import (
    BaseToolExecutionHook,
    ToolExecutionHook,
    ToolExecutionOutcome,
    ToolExecutionRequest,
    ToolHookDecision,
)
from .robustness import RuntimeLimits
from .tool_manager import ToolManager
from .tool_registry import ToolDefinition, ToolRegistry
from .trace import ExecutionTrace, TraceEvent
from .version import __version__


def create_agent(**kwargs):
    """Create a ProtectedAgent using the stable v1 Agent constructor."""

    return Agent(**kwargs)


__all__ = [
    "Agent",
    "LlamaCppLLM",
    "LLMProviderError",
    "create_agent",
    "ToolManager",
    "ToolRegistry",
    "ToolDefinition",
    "RuntimeLimits",
    "MemoryPolicy",
    "ToolExecutionRequest",
    "ToolHookDecision",
    "ToolExecutionOutcome",
    "ToolExecutionHook",
    "BaseToolExecutionHook",
    "ExecutionTrace",
    "TraceEvent",
    "__version__",
]
