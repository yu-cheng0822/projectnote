# ProtectedAgent v1.0.1 Architecture

## Responsibility boundary

ProtectedAgent owns:

- goal/task understanding
- structured Agent actions
- task planning and decomposition
- tool discovery and tool use
- session/entity/working/persistent memory
- context retrieval
- failure recovery and alternative replanning
- goal-completion evaluation
- runtime limits
- execution trace

ProtectedAgent does **not** own:

- identity authentication
- authorization/permission decisions
- dynamic trust
- security risk policy
- Security Gateway enforcement

## Main execution path

```text
User Request
    |
    v
Context Retrieval
    |
    v
Task Planning
  deterministic / generic / LLM decomposition
    |
    v
TaskPlan
    |
    v
Action Selection
    |
    v
ToolManager -------------------- Tool Hooks
    |
    v
Schema Validation
    |
    v
ToolRegistry -> Tool Handler
    |
    v
Observation
    |
    +--> Failure? -> Replanner -> retry / new args / prerequisite / abort
    |
    v
Goal Completion Evaluation
    |
    +--> incomplete -> append validated steps -> continue
    |
    v
Final Answer
```

Every important transition is also written to `ExecutionTrace`. External trace observers can subscribe without becoming a dependency of Agent Core.

## Plugin boundary

The v1 tool boundary is intentionally generic:

```text
Agent
  |
  | ToolExecutionRequest
  v
ToolManager
  |---- before_tool(request) ----> External Hook(s)
  |
  | Tool handler
  |
  |---- after_tool(request, outcome) -> External Hook(s)
```

A future SecurityArchitecture adapter may implement this hook contract, but the contract is not security-specific and ProtectedAgent imports no SecurityArchitecture module.

## Compatibility

`tool.py` / `ToolExecutor` remains as a legacy compatibility facade. New code should use `ToolManager`.

The v1 package supports both:

```python
from ProtectedAgent import Agent
```

and the existing script mode:

```bat
python ProtectedAgent\main.py
```
