# llama.cpp Setup for ProtectedAgent v1.0.1

ProtectedAgent v1.0.1 uses llama.cpp as its default LLM provider.
The Agent talks to llama.cpp through its local OpenAI-compatible HTTP API.

## 1. Install llama.cpp on Windows

Open Windows Terminal / CMD / PowerShell:

```bat
winget install llama.cpp
```

If you prefer the prebuilt release package, download the Windows x64 package
from the official llama.cpp GitHub Releases page and place `llama-server.exe`
in a directory of your choice.

## 2. Recommended first model for this project

For the current development machine (8 GB RAM), start with a quantized small
model rather than a large 7B+ model.

Recommended first attempt:

```text
Qwen/Qwen3-4B-GGUF:Q4_K_M
```

A lighter fallback is:

```text
Qwen/Qwen3-1.7B-GGUF:Q8_0
```

## 3. Start the llama.cpp server

If installed through the current llama.cpp launcher:

```bat
llama serve -hf Qwen/Qwen3-4B-GGUF:Q4_K_M -c 8192
```

The default server address is expected to be:

```text
http://127.0.0.1:8080
```

ProtectedAgent calls:

```text
GET  http://127.0.0.1:8080/v1/models
POST http://127.0.0.1:8080/v1/chat/completions
```

If you use the prebuilt server executable instead, the equivalent pattern is:

```bat
llama-server.exe -hf Qwen/Qwen3-4B-GGUF:Q4_K_M -c 8192
```

Keep this terminal open while ProtectedAgent is running.

## 4. Optional endpoint/model overrides

ProtectedAgent automatically discovers the loaded model from `/v1/models`, so
normally you do not need to configure a model id.

If your llama.cpp server is elsewhere:

```bat
set LLAMA_CPP_BASE_URL=http://127.0.0.1:8080/v1
```

Optional explicit model id / alias:

```bat
set LLAMA_CPP_MODEL=my-local-model
```

Optional API key if your local reverse proxy requires one:

```bat
set LLAMA_CPP_API_KEY=my-key
```

The default local API key sent by ProtectedAgent is `no-key`.

## 5. Start ProtectedAgent

From the SecureAIAgent project root:

```bat
python ProtectedAgent\main.py
```

At startup you should see:

```text
LLM Provider: llama.cpp
LLM Endpoint: http://127.0.0.1:8080/v1
```

## 6. Validation inputs

General conversation:

```text
你好，請簡單說明你可以做什麼
```

Parenthesized arithmetic regression test:

```text
(25 + 75) / 4 是多少？
```

Expected arithmetic result:

```text
25.0
```

Full automated regression:

```bat
python ProtectedAgent\tests\run_all_tests.py
```

Expected v1.0.1 result:

```text
Result: 18/18 test files passed
ALL PROTECTEDAGENT REGRESSION TESTS PASSED
```

## 7. ProtectedAgent backend

ProtectedAgent v1.0.2 uses llama.cpp only. Start `llama-server` / `llama serve` first, then run:

```bat
python ProtectedAgent\main.py
```
