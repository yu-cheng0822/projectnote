# ProtectedAgent v1.0.1 Public API

## 1. Agent

```python
from ProtectedAgent import Agent

agent = Agent(agent_id="agent_001", session_id="session_001")
result = agent.run("123 * 456 是多少？")
print(result["answer"])
```

Important stable constructor injection points:

- `llm`
- `tool_manager`
- `session_id`
- `trace_observers`
- `persistent_memory_path` / `persistent_store`
- `memory_policy`
- `runtime_limits`

The legacy `tool_executor` constructor argument is retained for compatibility but new integrations should use `tool_manager`.

## 2. Tool registration

```python
from ProtectedAgent import ToolDefinition, ToolManager

manager = ToolManager()
manager.register_tool(
    ToolDefinition(
        name="echo",
        description="Return supplied text.",
        input_schema={
            "type": "object",
            "properties": {"text": {"type": "string"}},
            "required": ["text"],
            "additionalProperties": False,
        },
        output_schema={"type": "string"},
        capabilities=["text.echo"],
        side_effects=[],
        handler=lambda arguments: arguments["text"],
        exposed_to_agent=True,
        strict_input_validation=True,
        strict_output_validation=True,
        metadata={"planner_keywords": ["echo", "回傳"]},
    )
)
```

## 3. Tool execution hooks

A hook can inspect, transform, or stop a tool call at the generic tool boundary.
ProtectedAgent assigns no security meaning to the hook.

```python
from ProtectedAgent import BaseToolExecutionHook, ToolHookDecision

class ExampleHook(BaseToolExecutionHook):
    def before_tool(self, request):
        print(request.tool_name, request.arguments, request.context)
        return ToolHookDecision(proceed=True)

    def after_tool(self, request, outcome):
        print(outcome.success, outcome.result)

manager.add_hook(ExampleHook())
```

The hook request context can include:

- `agent_id`
- `session_id`
- `trace_id`
- `run_step`
- `plan_step_id`
- `user_request`

Hook exceptions are isolated and do not crash Agent execution.

## 4. Trace observers

```python
def observer(event):
    print(event["event_type"])

agent.add_trace_observer(observer)
```

Observers are read-only observation callbacks. Observer exceptions are isolated.

## 5. Runtime limits

```python
from ProtectedAgent import RuntimeLimits

limits = RuntimeLimits(
    max_tool_calls=20,
    max_plan_steps=12,
    max_action_repeats=3,
    llm_timeout_seconds=30,
)
agent = Agent(runtime_limits=limits)
```

These are operational limits, not authorization/security policy.

## 6. Memory

`Agent.reset_memory()` clears session/entity/working memory. Persistent memory is intentionally separate:

- `remember_persistent_fact`
- `forget_persistent_fact`
- `list_persistent_memory`
- `clear_persistent_memory`

Memory Policy blocks configured sensitive fields from automatic persistent storage.
