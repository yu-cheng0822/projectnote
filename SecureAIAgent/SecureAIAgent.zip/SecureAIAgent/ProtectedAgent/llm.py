"""LLM providers for ProtectedAgent.

ProtectedAgent only requires one small interface from an LLM provider::

    generate(prompt: str) -> str

v1.0.2 uses llama.cpp as the only built-in LLM backend through its OpenAI-compatible local HTTP server.
"""

from __future__ import annotations

import os
import re
from typing import Optional

import requests


class LLMProviderError(RuntimeError):
    """Normalized error raised by local LLM providers."""


class LlamaCppLLM:
    """Use a local llama.cpp OpenAI-compatible HTTP server.

    Default endpoint: ``http://127.0.0.1:8080/v1``.

    If ``model`` is omitted, the provider resolves the first loaded model from
    ``GET /v1/models`` and caches its id.  This avoids coupling ProtectedAgent
    to a particular GGUF filename or llama.cpp ``--alias`` value.
    """

    provider_name = "llama.cpp"

    def __init__(
        self,
        base_url: Optional[str] = None,
        model: Optional[str] = None,
        api_key: Optional[str] = None,
        timeout_seconds: float = 30.0,
        temperature: float = 0.2,
        max_tokens: int = 1024,
        http_client=None,
    ):
        self.base_url = (
            base_url
            or os.getenv("LLAMA_CPP_BASE_URL")
            or "http://127.0.0.1:8080/v1"
        ).rstrip("/")
        self.model = model or os.getenv("LLAMA_CPP_MODEL") or None
        self.api_key = api_key or os.getenv("LLAMA_CPP_API_KEY") or "no-key"
        self.timeout_seconds = float(timeout_seconds)
        self.temperature = float(temperature)
        self.max_tokens = int(max_tokens)
        self.http = http_client or requests
        self._resolved_model = self.model

    @property
    def endpoint(self):
        return f"{self.base_url}/chat/completions"

    @property
    def models_endpoint(self):
        return f"{self.base_url}/models"

    def _headers(self):
        return {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self.api_key}",
        }

    def resolve_model(self, force=False):
        if self._resolved_model and not force:
            return self._resolved_model

        try:
            response = self.http.get(
                self.models_endpoint,
                headers=self._headers(),
                timeout=min(self.timeout_seconds, 5.0),
            )
            response.raise_for_status()
        except requests.Timeout as exc:
            raise LLMProviderError("llm_timeout") from exc
        except requests.RequestException as exc:
            raise LLMProviderError(f"llm_request_error:{exc}") from exc
        except Exception as exc:
            # Test doubles and other HTTP clients may not derive their errors
            # from requests.RequestException. Normalize them at this boundary.
            raise LLMProviderError(f"llm_request_error:{exc}") from exc

        try:
            data = response.json()
            models = data.get("data") or []
            model_id = models[0].get("id") if models else None
        except (ValueError, TypeError, AttributeError, IndexError) as exc:
            raise LLMProviderError("llm_invalid_models_response") from exc

        if not model_id:
            raise LLMProviderError("llm_no_loaded_model")

        self._resolved_model = str(model_id)
        return self._resolved_model

    def healthcheck(self):
        """Return a compact status object without raising to the caller."""

        try:
            model = self.resolve_model(force=True)
            return {
                "ok": True,
                "provider": self.provider_name,
                "base_url": self.base_url,
                "model": model,
            }
        except Exception as exc:
            return {
                "ok": False,
                "provider": self.provider_name,
                "base_url": self.base_url,
                "model": self._resolved_model,
                "error": str(exc),
            }

    @staticmethod
    def _clean_content(content):
        """Normalize llama.cpp chat content and remove leaked thinking blocks."""

        if content is None:
            return None

        if isinstance(content, list):
            pieces = []
            for item in content:
                if isinstance(item, dict):
                    text = item.get("text") or item.get("content")
                    if text:
                        pieces.append(str(text))
                elif item is not None:
                    pieces.append(str(item))
            content = "".join(pieces)

        text = str(content).strip()
        # Some reasoning-capable GGUF templates can expose <think> blocks even
        # when non-thinking mode is requested.  ProtectedAgent only wants the
        # final answer / structured JSON at this boundary.
        text = re.sub(r"<think>.*?</think>", "", text, flags=re.I | re.S).strip()
        return text

    def generate(self, prompt):
        model = self.resolve_model()
        payload = {
            "model": model,
            "messages": [
                {
                    "role": "system",
                    "content": (
                        "You are the local language-model backend for an AI "
                        "agent. Follow the supplied instructions exactly. "
                        "When JSON is requested, output only valid JSON."
                    ),
                },
                {"role": "user", "content": str(prompt)},
            ],
            "temperature": self.temperature,
            "max_tokens": self.max_tokens,
            "stream": False,
            # Current llama.cpp understands the OpenAI-style reasoning control.
            # Older builds that ignore it still work; leaked <think> blocks are
            # removed by _clean_content as a compatibility fallback.
            "reasoning_effort": "none",
        }

        try:
            response = self.http.post(
                self.endpoint,
                headers=self._headers(),
                json=payload,
                timeout=self.timeout_seconds,
            )
            response.raise_for_status()
        except requests.Timeout as exc:
            raise LLMProviderError("llm_timeout") from exc
        except requests.RequestException as exc:
            raise LLMProviderError(f"llm_request_error:{exc}") from exc
        except Exception as exc:
            raise LLMProviderError(f"llm_request_error:{exc}") from exc

        try:
            data = response.json()
            choices = data.get("choices") or []
            message = choices[0].get("message") if choices else None
            generated = message.get("content") if isinstance(message, dict) else None
        except (ValueError, TypeError, AttributeError, IndexError) as exc:
            raise LLMProviderError("llm_invalid_response_json") from exc

        generated = self._clean_content(generated)
        if not generated:
            raise LLMProviderError("llm_missing_response")
        return generated


__all__ = [
    "LLMProviderError",
    "LlamaCppLLM",
]
