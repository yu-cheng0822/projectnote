"""Backward-compatible ToolExecutor facade.

New Agent Core code uses ToolManager. This module remains so older tests or
scripts importing ``ToolExecutor`` continue to work during the migration.
"""

try:
    from .tool_manager import ToolManager
except ImportError:
    from tool_manager import ToolManager


class ToolExecutor(ToolManager):
    def __init__(self, registry=None):
        super().__init__(registry=registry)

        database_definition = self.registry.get("database")
        database_handler = database_definition.handler if database_definition else None
        self.database = getattr(database_handler, "database", None)

        # Historical public mapping retained for compatibility.
        self.tools = {
            "calculator": self.calculator,
            "recovery": self.recovery,
            "file": self.file,
            "database": self.database_tool,
        }

    def calculator(self, expression):
        definition = self.registry.get("calculator")
        return definition.handler(expression)

    def recovery(self, data=None):
        definition = self.registry.get("recovery")
        return definition.handler(data)

    def file(self, data=None):
        definition = self.registry.get("file")
        return definition.handler(data)

    def database_tool(self, query=None):
        definition = self.registry.get("database")
        return definition.handler(query)


if __name__ == "__main__":
    executor = ToolExecutor()

    print("===== Tool Executor Compatibility Test =====")

    cases = [
        ("calculator", "123 * 456"),
        ("calculator", "python main.py"),
        ("recovery", None),
        ("database", "users"),
        ("database", "users | name=Alice"),
        ("database", "accounts | username=alice"),
        ("database", "sensitive_data | user_id=U001"),
        ("unknown", None),
    ]

    for name, arguments in cases:
        success, result = executor.execute(name, arguments)
        print(f"\n{name}:")
        print("Success:", success)
        print("Result:", result)
