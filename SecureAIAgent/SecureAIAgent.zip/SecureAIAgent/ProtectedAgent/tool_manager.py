try:
    from .tool_registry import ToolDefinition, build_default_tool_registry
    from .plugin_api import (
        ToolExecutionRequest,
        ToolExecutionOutcome,
        ToolHookDecision,
    )
except ImportError:  # Script-mode compatibility
    from tool_registry import ToolDefinition, build_default_tool_registry
    from plugin_api import (
        ToolExecutionRequest,
        ToolExecutionOutcome,
        ToolHookDecision,
    )


class ToolManager:
    """Single generic execution boundary between Agent Core and tools.

    Phase 14 standardizes tool schemas/capabilities at this boundary. It still
    contains no SecurityArchitecture dependency; future adapters can consume
    the same public metadata without Agent Core importing a security system.
    """

    def __init__(self, registry=None, hooks=None):
        self.registry = registry if registry is not None else build_default_tool_registry()
        self._hooks = list(hooks or [])

    def add_hook(self, hook):
        """Register a generic v1 tool-boundary plugin hook."""
        if hook is not None and hook not in self._hooks:
            self._hooks.append(hook)
        return hook

    def remove_hook(self, hook):
        try:
            self._hooks.remove(hook)
            return True
        except ValueError:
            return False

    def clear_hooks(self):
        self._hooks.clear()

    def hooks(self):
        return tuple(self._hooks)

    def register_tool(self, definition, replace=False):
        return self.registry.register(definition, replace=replace)

    def unregister_tool(self, name):
        return self.registry.unregister(name)

    def has_tool(self, name, exposed_only=False):
        return self.registry.has(name, exposed_only=exposed_only)

    def available_tool_names(self, exposed_only=True):
        return self.registry.names(exposed_only=exposed_only)

    def tool_catalog(self):
        return self.registry.public_catalog()

    def get_tool_metadata(self, name):
        definition = self.registry.get(name)
        if definition is None:
            return None
        return definition.public_metadata()

    def tools_with_capability(self, capability, exposed_only=True):
        return [
            definition.public_metadata()
            for definition in self.registry.find_by_capability(
                capability,
                exposed_only=exposed_only,
            )
        ]

    def prompt_catalog(self):
        return self.registry.to_prompt_text()

    def relevant_tools(self, query, limit=6):
        return [
            definition.public_metadata()
            for definition in self.registry.search_relevant(
                query,
                exposed_only=True,
                limit=limit,
            )
        ]

    def planning_catalog(self, query=None, names=None, limit=6):
        if names is None and query is not None:
            names = [
                item["name"]
                for item in self.relevant_tools(query, limit=limit)
            ]
        return self.registry.to_prompt_text(names=names)

    def normalize_input(self, tool_name, arguments=None):
        definition = self.registry.get(tool_name)
        if definition is None:
            return arguments

        handler = definition.handler
        serializer = getattr(handler, "to_history_input", None)
        if callable(serializer):
            return serializer(arguments)

        if isinstance(arguments, dict) and set(arguments) == {"expression"}:
            return arguments.get("expression")

        return arguments

    def prepare_arguments(self, tool_name, arguments=None):
        """Convert legacy tool inputs to the canonical structured shape."""
        definition = self.registry.get(tool_name)
        if definition is None:
            return arguments

        if isinstance(arguments, dict) or arguments is None:
            return arguments

        handler_normalizer = getattr(definition.handler, "normalize_arguments", None)
        if callable(handler_normalizer):
            return handler_normalizer(arguments)

        schema = definition.input_schema or {}
        if schema.get("type") == "object":
            required = schema.get("required", [])
            properties = schema.get("properties", {})
            if isinstance(required, list) and len(required) == 1 and required[0] in properties:
                return {required[0]: arguments}

        return arguments

    def validate_arguments(self, tool_name, arguments=None):
        definition = self.registry.get(tool_name)
        if definition is None:
            return False, "unknown_tool"
        if not definition.strict_input_validation:
            return True, None
        return self._validate_schema(arguments, definition.input_schema, path="arguments")

    def validate_output(self, tool_name, output):
        definition = self.registry.get(tool_name)
        if definition is None:
            return False, "unknown_tool"
        if not definition.strict_output_validation or definition.output_schema is None:
            return True, None
        return self._validate_schema(output, definition.output_schema, path="result")

    def execute(self, tool_name, arguments=None, context=None):
        definition = self.registry.get(tool_name)
        if definition is None:
            return False, "unknown_tool"

        prepared_arguments = self.prepare_arguments(tool_name, arguments)
        request = ToolExecutionRequest(
            tool_name=str(tool_name).strip().lower(),
            arguments=prepared_arguments,
            metadata=definition.public_metadata(),
            context=dict(context or {}),
        )

        # Public v1 plugin boundary. Each hook is isolated so diagnostics or
        # external integrations cannot crash Agent Core. A hook may optionally
        # transform arguments or stop execution before the handler is invoked.
        for hook in list(self._hooks):
            callback = getattr(hook, "before_tool", None)
            if not callable(callback):
                continue
            try:
                decision = callback(request)
            except Exception:
                continue

            if decision is None:
                continue
            if isinstance(decision, dict):
                decision = ToolHookDecision(**decision)
            if not isinstance(decision, ToolHookDecision):
                continue

            if decision.arguments is not None:
                request.arguments = decision.arguments

            if not decision.proceed:
                reason = str(decision.reason or "blocked_by_tool_hook")
                outcome = ToolExecutionOutcome(
                    success=False,
                    result=f"tool_hook_blocked:{reason}",
                    blocked=True,
                    reason=reason,
                )
                self._notify_after_hooks(request, outcome)
                return outcome.success, outcome.result

        # Revalidate after hooks in case a plugin transformed arguments.
        valid, validation_error = self.validate_arguments(
            tool_name, request.arguments
        )
        if not valid:
            outcome = ToolExecutionOutcome(
                success=False,
                result=f"invalid_tool_arguments:{validation_error}",
                reason="invalid_tool_arguments",
            )
            self._notify_after_hooks(request, outcome)
            return outcome.success, outcome.result

        try:
            result = definition.handler(request.arguments)
        except Exception as exc:
            outcome = ToolExecutionOutcome(
                success=False,
                result=str(exc),
                reason="tool_exception",
            )
            self._notify_after_hooks(request, outcome)
            return outcome.success, outcome.result

        if isinstance(result, str) and result in definition.error_results:
            outcome = ToolExecutionOutcome(
                success=False,
                result=result,
                reason="tool_error_result",
            )
            self._notify_after_hooks(request, outcome)
            return outcome.success, outcome.result

        output_valid, output_error = self.validate_output(tool_name, result)
        if not output_valid:
            outcome = ToolExecutionOutcome(
                success=False,
                result=f"invalid_tool_output:{output_error}",
                reason="invalid_tool_output",
            )
            self._notify_after_hooks(request, outcome)
            return outcome.success, outcome.result

        outcome = ToolExecutionOutcome(success=True, result=result)
        self._notify_after_hooks(request, outcome)
        return outcome.success, outcome.result

    def _notify_after_hooks(self, request, outcome):
        for hook in list(self._hooks):
            callback = getattr(hook, "after_tool", None)
            if not callable(callback):
                continue
            try:
                callback(request, outcome)
            except Exception:
                continue

    def _validate_schema(self, value, schema, path="value"):
        """Validate the small JSON-Schema subset used by Agent tools.

        Supported keywords are intentionally small and dependency-free:
        type, enum, properties, required, additionalProperties, items,
        minLength, minItems, maxItems and anyOf.
        """

        if schema is None:
            return True, None
        if not isinstance(schema, dict):
            return True, None

        any_of = schema.get("anyOf")
        if isinstance(any_of, list) and any_of:
            failures = []
            for option in any_of:
                ok, error = self._validate_schema(value, option, path=path)
                if ok:
                    return True, None
                failures.append(error)
            return False, f"{path} does not match any allowed schema"

        expected_type = schema.get("type")
        if expected_type:
            if not self._matches_type(value, expected_type):
                return False, f"{path} must be {expected_type}"

        if "enum" in schema and value not in schema.get("enum", []):
            return False, f"{path} must be one of {schema.get('enum')}"

        if expected_type == "string" and isinstance(value, str):
            min_length = schema.get("minLength")
            if isinstance(min_length, int) and len(value) < min_length:
                return False, f"{path} must contain at least {min_length} characters"

        if expected_type == "object" and isinstance(value, dict):
            properties = schema.get("properties", {})
            if not isinstance(properties, dict):
                properties = {}

            required = schema.get("required", [])
            if not isinstance(required, list):
                required = []
            for key in required:
                if key not in value:
                    return False, f"{path}.{key} is required"

            if schema.get("additionalProperties") is False:
                unknown = [key for key in value if key not in properties]
                if unknown:
                    return False, f"{path} contains unsupported field: {unknown[0]}"

            for key, child_value in value.items():
                child_schema = properties.get(key)
                if child_schema is None:
                    continue
                ok, error = self._validate_schema(
                    child_value,
                    child_schema,
                    path=f"{path}.{key}",
                )
                if not ok:
                    return False, error

        if expected_type == "array" and isinstance(value, list):
            min_items = schema.get("minItems")
            max_items = schema.get("maxItems")
            if isinstance(min_items, int) and len(value) < min_items:
                return False, f"{path} must contain at least {min_items} items"
            if isinstance(max_items, int) and len(value) > max_items:
                return False, f"{path} must contain at most {max_items} items"

            item_schema = schema.get("items")
            if isinstance(item_schema, dict):
                for index, item in enumerate(value):
                    ok, error = self._validate_schema(
                        item,
                        item_schema,
                        path=f"{path}[{index}]",
                    )
                    if not ok:
                        return False, error

        return True, None

    def _matches_type(self, value, expected_type):
        if isinstance(expected_type, list):
            return any(self._matches_type(value, item) for item in expected_type)

        mapping = {
            "object": lambda item: isinstance(item, dict),
            "array": lambda item: isinstance(item, list),
            "string": lambda item: isinstance(item, str),
            "integer": lambda item: isinstance(item, int) and not isinstance(item, bool),
            "number": lambda item: isinstance(item, (int, float)) and not isinstance(item, bool),
            "boolean": lambda item: isinstance(item, bool),
            "null": lambda item: item is None,
        }
        checker = mapping.get(str(expected_type).strip().lower())
        if checker is None:
            return True
        return checker(value)


__all__ = ["ToolManager", "ToolDefinition"]
