import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[2]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from ProtectedAgent import (
    Agent,
    BaseToolExecutionHook,
    RuntimeLimits,
    ToolDefinition,
    ToolHookDecision,
    ToolManager,
    __version__,
    create_agent,
)


class NoCallLLM:
    def generate(self, prompt):
        raise AssertionError("deterministic contract test must not call LLM")


class RecordingHook(BaseToolExecutionHook):
    def __init__(self):
        self.before = []
        self.after = []

    def before_tool(self, request):
        self.before.append(request.to_dict())
        return None

    def after_tool(self, request, outcome):
        self.after.append((request.to_dict(), outcome.to_dict()))


class RewriteHook(BaseToolExecutionHook):
    def before_tool(self, request):
        if request.tool_name == "calculator":
            return ToolHookDecision(
                proceed=True,
                arguments={"expression": "2 + 3"},
            )
        return None


class BlockHook(BaseToolExecutionHook):
    def before_tool(self, request):
        return ToolHookDecision(proceed=False, reason="demo_block")


class BrokenHook(BaseToolExecutionHook):
    def before_tool(self, request):
        raise RuntimeError("observer/plugin failure must be isolated")

    def after_tool(self, request, outcome):
        raise RuntimeError("observer/plugin failure must be isolated")


def test_package_public_api_and_version():
    assert __version__ == "1.0.2"
    agent = create_agent(llm=NoCallLLM())
    assert isinstance(agent, Agent)
    assert isinstance(agent.tool_manager, ToolManager)
    assert isinstance(agent.runtime_limits, RuntimeLimits)


def test_tool_hook_can_observe_and_receive_agent_context():
    manager = ToolManager()
    hook = RecordingHook()
    manager.add_hook(hook)
    agent = Agent(
        agent_id="contract_agent",
        session_id="contract_session",
        llm=NoCallLLM(),
        tool_manager=manager,
    )

    result = agent.run("2 + 3 是多少？")

    assert result["answer"] == "計算結果：5"
    assert len(hook.before) == 1
    assert len(hook.after) == 1
    context = hook.before[0]["context"]
    assert context["agent_id"] == "contract_agent"
    assert context["session_id"] == "contract_session"
    assert context["trace_id"]
    assert context["run_step"] == 1
    assert context["user_request"] == "2 + 3 是多少？"


def test_hook_can_transform_arguments_and_revalidation_occurs():
    manager = ToolManager(hooks=[RewriteHook()])
    success, result = manager.execute(
        "calculator",
        {"expression": "100 + 100"},
    )
    assert success is True
    assert result == 5


def test_hook_can_stop_execution_without_calling_handler():
    called = {"value": False}

    def side_effect_tool(arguments):
        called["value"] = True
        return "should_not_run"

    manager = ToolManager(hooks=[BlockHook()])
    manager.register_tool(
        ToolDefinition(
            name="demo_write",
            description="Demo side-effect tool.",
            input_schema={
                "type": "object",
                "properties": {},
                "required": [],
                "additionalProperties": False,
            },
            output_schema={"type": "string"},
            capabilities=["demo.write"],
            side_effects=["demo_write"],
            handler=side_effect_tool,
            exposed_to_agent=True,
            strict_input_validation=True,
            strict_output_validation=True,
        )
    )

    success, result = manager.execute("demo_write", {})
    assert success is False
    assert result == "tool_hook_blocked:demo_block"
    assert called["value"] is False


def test_hook_failure_is_isolated():
    manager = ToolManager(hooks=[BrokenHook()])
    success, result = manager.execute(
        "calculator",
        {"expression": "2 + 3"},
    )
    assert success is True
    assert result == 5


def test_trace_observer_contract_still_works():
    events = []
    agent = Agent(llm=NoCallLLM(), trace_observers=[events.append])
    result = agent.run("2 + 3 是多少？")

    assert result["answer"] == "計算結果：5"
    assert events
    assert events[0]["event_type"] == "RUN_STARTED"
    assert events[-1]["event_type"] == "RUN_FINISHED"


def main():
    test_package_public_api_and_version()
    test_tool_hook_can_observe_and_receive_agent_context()
    test_hook_can_transform_arguments_and_revalidation_occurs()
    test_hook_can_stop_execution_without_calling_handler()
    test_hook_failure_is_isolated()
    test_trace_observer_contract_still_works()
    print("ProtectedAgent v1.0 Phase 18 contract tests passed.")


if __name__ == "__main__":
    main()
