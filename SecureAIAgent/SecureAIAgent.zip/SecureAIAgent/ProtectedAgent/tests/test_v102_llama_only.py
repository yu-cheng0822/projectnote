import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[2]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from ProtectedAgent import Agent, LlamaCppLLM, __version__
from ProtectedAgent.planner import TaskPlanner


class FakeResponse:
    def __init__(self, payload):
        self.payload = payload

    def raise_for_status(self):
        return None

    def json(self):
        return self.payload


class FakeHTTP:
    def __init__(self, generated_content):
        self.generated_content = generated_content
        self.get_calls = []
        self.post_calls = []

    def get(self, url, **kwargs):
        self.get_calls.append((url, kwargs))
        return FakeResponse({"data": [{"id": "demo.gguf"}]})

    def post(self, url, **kwargs):
        self.post_calls.append((url, kwargs))
        return FakeResponse({
            "choices": [
                {
                    "message": {
                        "role": "assistant",
                        "content": self.generated_content,
                    }
                }
            ]
        })


class NoCallLLM:
    def generate(self, prompt):
        raise AssertionError("deterministic arithmetic must not call the LLM")


def test_version_and_public_provider_exports():
    assert __version__ == "1.0.2"
    assert LlamaCppLLM is not None


def test_llama_cpp_resolves_loaded_model_and_uses_chat_completions():
    fake_http = FakeHTTP('{"action":"final","answer":"你好！"}')
    llm = LlamaCppLLM(http_client=fake_http)

    result = llm.generate("Return JSON")

    assert result == '{"action":"final","answer":"你好！"}'
    assert fake_http.get_calls[0][0].endswith("/v1/models")
    post_url, post_kwargs = fake_http.post_calls[0]
    assert post_url.endswithwith("/v1/chat/completions") if False else post_url.endswith("/v1/chat/completions")
    payload = post_kwargs["json"]
    assert payload["model"] == "demo.gguf"
    assert payload["messages"][1]["content"] == "Return JSON"
    assert payload["reasoning_effort"] == "none"


def test_llama_cpp_strips_thinking_block():
    fake_http = FakeHTTP(
        '<think>internal reasoning that Agent Core must not receive</think>\n'
        '{"action":"final","answer":"你好！"}'
    )
    llm = LlamaCppLLM(http_client=fake_http)
    result = llm.generate("Return JSON")
    assert result == '{"action":"final","answer":"你好！"}'


def test_t01_general_conversation_through_llama_cpp_provider():
    fake_http = FakeHTTP(
        '{"action":"final","tool":null,"arguments":{},'
        '"answer":"你好！我可以協助你進行計算、資料查詢與一般問題回答。"}'
    )
    llm = LlamaCppLLM(http_client=fake_http)
    agent = Agent(llm=llm)

    result = agent.run("你好，請簡單說明你可以做什麼")

    assert result["tool_history"] == []
    assert "計算" in result["answer"]
    assert "資料查詢" in result["answer"]


def test_t03_parenthesized_arithmetic_extraction_and_execution():
    planner = TaskPlanner()
    assert planner.extract_arithmetic_expression("(25 + 75) / 4 是多少？") == "(25 + 75) / 4"

    agent = Agent(llm=NoCallLLM())
    result = agent.run("(25 + 75) / 4 是多少？")

    assert result["tool_history"][0]["input"] == "(25 + 75) / 4"
    assert result["tool_history"][0]["result"] == 25
    assert result["answer"] in {"計算結果：25", "計算結果：25.0"}


def main():
    test_version_and_public_provider_exports()
    test_llama_cpp_resolves_loaded_model_and_uses_chat_completions()
    test_llama_cpp_strips_thinking_block()
    test_t01_general_conversation_through_llama_cpp_provider()
    test_t03_parenthesized_arithmetic_extraction_and_execution()
    print("ProtectedAgent v1.0.2 llama.cpp-only + T01/T03 tests passed.")


if __name__ == "__main__":
    main()
