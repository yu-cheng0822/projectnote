try:
    from ..data.database import Database
except ImportError:
    from data.database import Database


class DatabaseTool:
    """Structured wrapper around the demo database used by ProtectedAgent."""

    VALID_DATASETS = {"users", "accounts", "sensitive_data"}

    def __init__(self, database=None):
        self.database = database if database is not None else Database()

    def __call__(self, arguments=None):
        normalized = self.normalize_arguments(arguments)
        dataset = normalized["dataset"]
        filters = normalized["filters"]

        print("\n[DEBUG] Database Query:")
        print(repr(self.to_history_input(arguments)))

        if not dataset:
            return "missing_database_query"

        if dataset == "users":
            return self.database.get_users(
                user_id=filters.get("user_id"),
                name=filters.get("name"),
            )

        if dataset == "accounts":
            return self.database.get_accounts(
                account_id=filters.get("account_id"),
                username=filters.get("username"),
            )

        if dataset == "sensitive_data":
            return self.database.get_sensitive_data(
                user_id=filters.get("user_id"),
            )

        return "unknown_database_query"

    def to_history_input(self, arguments=None):
        normalized = self.normalize_arguments(arguments)
        dataset = normalized["dataset"]
        filters = normalized["filters"]
        if not dataset:
            return ""

        parts = [dataset]
        for key, value in filters.items():
            if value is None:
                continue
            parts.append(f"{key}={value}")

        return " | ".join(parts)


    def normalize_arguments(self, arguments=None):
        """Return the canonical structured input used by ToolManager."""
        dataset, filters = self._normalize_arguments(arguments)
        return {"dataset": dataset, "filters": filters}

    def _normalize_arguments(self, arguments):
        if arguments is None:
            return "", {}

        if isinstance(arguments, dict):
            dataset = str(arguments.get("dataset", "")).strip().lower()
            filters = arguments.get("filters", {})
            if not isinstance(filters, dict):
                filters = {}

            normalized_filters = {}
            for key, value in filters.items():
                if value is None:
                    continue
                normalized_filters[str(key).strip().lower()] = str(value).strip()

            return dataset, normalized_filters

        parts = [part.strip() for part in str(arguments).split("|")]
        dataset = parts[0].lower() if parts else ""
        filters = {}

        for part in parts[1:]:
            if "=" not in part:
                continue
            key, value = part.split("=", 1)
            filters[key.strip().lower()] = value.strip()

        return dataset, filters
